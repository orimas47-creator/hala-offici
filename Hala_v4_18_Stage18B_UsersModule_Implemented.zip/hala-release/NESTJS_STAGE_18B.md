# Hala v4.18 — Stage 18B: NestJS Foundation

تم إنشاء أساس NestJS فعلي فوق نسخة v4.17 مع إبقاء منطق `.mjs` الحالي مؤقتًا كطبقة انتقالية، وعدم حذف `server.mjs` قبل اكتمال Route Parity.

## Added
- NestFactory + AppModule
- Health/readiness controllers
- Auth controller/service boundary
- Global ValidationPipe
- Helmet
- CORS allow-list
- Throttler baseline
- Request-ID interceptor
- Central exception filter
- Auth guard boundary
- Jest/Supertest E2E foundation
- Route parity extraction
- Nest build/start scripts

## Important
هذه ليست شهادة إطلاق. في البيئة الحالية لا يوجد PostgreSQL/Docker، ولم يتم تشغيل `npm install` أو `nest build` أو E2E الحقيقي ضد قاعدة بيانات فعلية. لذلك الحالة الحالية: **Foundation created; runtime certification pending**.

## Next gate
TypeORM/PostgreSQL DataSource → Users/Providers/Markets/Catalog → Bookings/Inventory → Payments/Escrow/Ledger → Webhooks/Workers → full route parity → real DB concurrency/E2E → retire legacy dispatcher.
