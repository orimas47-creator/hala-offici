# Hala v4.18 — UsersModule Stage 18B

Implemented the v4.17 user-profile routes in NestJS without exposing role/activation/credential mutation through the customer profile API.

## Routes
- GET /api/v1/users/:id
- PATCH /api/v1/users/:id

## Security rules
- Requires HalaAuthGuard + RequireActorGuard.
- Self read/update is allowed.
- Cross-user access requires admin/super_admin/administrator role.
- The module does not allow changing roles, active state, phone, credentials, or balances.

## Verification
- Static structure check: passed.
- Relative TypeScript import target check: passed.
- Full `tsc`/Jest runtime check: blocked by missing installed dependencies in the current environment (`node_modules` absent). No runtime success is claimed.
