import fs from 'node:fs';
const src=fs.readFileSync(new URL('../src/server.mjs', import.meta.url),'utf8');
const routes=[];
for(const line of src.split('\n')){
  const m=line.match(/if\(req\.method==='(GET|POST|PATCH|DELETE|OPTIONS)' && path==='([^']+)'\)/);
  if(m) routes.push({method:m[1],path:m[2]});
  else if(line.includes("if(req.method===") && line.includes("path.match")) routes.push({method:'PATTERN',source:line.trim()});
}
fs.writeFileSync(new URL('../openapi/nest-route-parity.json', import.meta.url), JSON.stringify({generatedAt:new Date().toISOString(),source:'src/server.mjs',routes},null,2)+'\n');
console.log(`Extracted ${routes.length} route entries`);
