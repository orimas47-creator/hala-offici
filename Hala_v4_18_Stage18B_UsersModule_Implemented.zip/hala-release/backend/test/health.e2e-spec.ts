import { Test } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module.js';

describe('NestJS foundation', () => {
  let app: INestApplication;
  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    await app.init();
  });
  afterAll(async () => { await app.close(); });
  it('GET /health exposes NestJS runtime', async () => {
    const res = await request(app.getHttpServer()).get('/health').expect(200);
    expect(res.body.ok).toBe(true);
    expect(res.body.framework).toBe('nestjs');
    expect(res.headers['x-request-id']).toBeTruthy();
  });
  it('rejects unknown DTO properties', async () => {
    await request(app.getHttpServer()).post('/api/v1/auth/request-otp').send({ phone: '+967771234567', purpose: 'login', unexpected: true }).expect(400);
  });
});
