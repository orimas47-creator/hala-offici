import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..','..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('production compose is not seeded with pilot data and binds UIs to loopback',()=>{
 const c=read('infra/docker/docker-compose.yml');
 assert.doesNotMatch(c,/003_pilot_seed\.sql/);
 assert.match(c,/127\.0\.0\.1:8088:80/);
 assert.match(c,/127\.0\.0\.1:8089:80/);
 assert.match(c,/no-new-privileges:true/);
 assert.match(c,/cap_drop: \["ALL"\]/);
});

test('pilot seed is explicitly separated from production compose',()=>{
 const c=read('infra/docker/docker-compose.pilot.yml');
 assert.match(c,/003_pilot_seed\.sql/);
 assert.match(c,/HALA_ALLOW_DEV_ACTOR_HEADER: "true"/);
 assert.match(c,/HALA_DEV_OTP: "true"/);
});

test('booking access does not disclose existence and provider can access own booking',()=>{
 const s=read('backend/src/modules/bookings/service.mjs');
 assert.match(s,/pr\.provider_user_id=\$2/);
 assert.match(s,/b\.id=\$1[\s\S]*AND \(b\.customer_id=\$2 OR pr\.provider_user_id=\$2/);
 assert.match(s,/if\(!actor\) throw .*ACTOR_REQUIRED/);
});

test('portal provider ads require an active provider membership in the target market',()=>{
 const s=read('backend/src/modules/global-portal/service.mjs');
 assert.match(s,/PROVIDER_NOT_ACTIVE_IN_MARKET/);
 assert.match(s,/market_provider_memberships/);
 assert.match(s,/mm\.status='ACTIVE'/);
});

test('central AI guard cannot directly mutate money or roles',()=>{
 const s=read('database/008_v4_7_supervisor_security_portal.sql');
 assert.match(s,/can_directly_edit_money":false/);
 assert.match(s,/can_directly_change_roles":false/);
});
