import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v4.10 has real services for previously README-only sensitive domains',()=>{
 for(const x of ['admin','providers','users','escrow','ledger'])assert.ok(fs.existsSync(path.join(root,'backend/src/modules',x,'service.mjs')),x);
});
test('booking lifecycle contract is declared centrally and used by booking/payment/dispute services',()=>{
 const b=read('backend/src/modules/bookings/service.mjs'); const p=read('backend/src/modules/payments/service.mjs'); const d=read('backend/src/modules/disputes/service.mjs'); const db=read('database/002_v4_2.sql');
 for(const x of ['DRAFT','PAYMENT_PENDING','PROVIDER_PENDING','CONFIRMED','IN_PROGRESS','RETURN_PENDING','INSPECTION','COMPLETED','CANCELLED','FAILED','DISPUTED']) assert.match(db,new RegExp(`'${x}'`),x);
 assert.match(b,/lifecycle_status/); assert.match(p,/lifecycle_status/); assert.match(d,/lifecycle_status/);
 assert.ok(!d.includes("['CONFIRMED','IN_PROGRESS']"));
});
test('reference market uniqueness is enforced at database level',()=>assert.match(read('database/009_v4_9_operational_hardening.sql'),/ux_markets_active_reference_template/));
test('reference market change audit action is accepted by database constraint',()=>assert.match(read('database/009_v4_9_operational_hardening.sql'),/SET_REFERENCE/));
test('admin frontend does not directly target localhost backend',()=>assert.doesNotMatch(read('apps/admin/index.html'),/http:\/\/localhost:8080\/api\/v1/));
test('production compose disables demo identity and OTP bypass',()=>{const s=read('infra/docker/docker-compose.yml');assert.match(s,/NODE_ENV: production/);assert.match(s,/HALA_ALLOW_DEV_ACTOR_HEADER: "false"/);assert.match(s,/HALA_DEV_OTP: "false"/);});
test('webhook endpoint uses signed inbox design',()=>{assert.ok(read('backend/src/server.mjs').includes('webhooks'));assert.match(read('backend/src/modules/payments/webhook.mjs'),/timingSafeEqual/);});
test('central supervisor is attached to listing and payment flows',()=>{const u=read('backend/src/modules/universal-market/service.mjs');const p=read('backend/src/modules/payments/service.mjs');assert.match(u,/superviseInTransaction/);assert.match(p,/superviseInTransaction/);});
