import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const project=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..','..');
const read=(p)=>fs.readFileSync(path.join(project,p),'utf8');

test('v4.10 exposes DB readiness separately from process health',()=>{
 const s=read('backend/src/server.mjs'); assert.match(s,/path==='\/ready'/); assert.match(s,/await pingDb\(\)/);
});
test('payment webhooks perform a real settlement path for signed verified/failed events',()=>{
 const w=read('backend/src/workers/payment-webhook-worker.mjs'); const p=read('backend/src/modules/payments/service.mjs');
 assert.match(w,/settlePaymentInTransaction/); assert.match(w,/payment\.verified.*payment\.captured/); assert.match(p,/export async function settlePaymentInTransaction/); assert.match(p,/PAYMENT_VERIFIED/);
});
test('OTP uses both phone throttling and IP throttling with cooldown',()=>{
 const a=read('backend/src/modules/auth/service.mjs'); const m=read('database/010_v4_10_integration_hardening.sql');
 assert.match(a,/ip_address/); assert.match(a,/OTP_IP_RATE_LIMITED/); assert.match(a,/OTP_COOLDOWN/); assert.match(m,/ALTER TABLE otp_events ADD COLUMN IF NOT EXISTS ip_address INET/);
});
test('logout revokes the authenticated bearer session',()=>{
 const s=read('backend/src/server.mjs'); const a=read('backend/src/modules/auth/service.mjs'); assert.match(s,/auth\/logout/); assert.match(s,/revokeSession/); assert.match(a,/SET revoked_at=now\(\)/);
});
test('production dependency is pinned to the reviewed pg major/minor release',()=>{
 const p=JSON.parse(read('backend/package.json')); assert.equal(p.dependencies.pg,'8.23.0');
});

test('provider registration requires an application and explicit admin approval',()=>{
 const s=read('backend/src/server.mjs'); const p=read('backend/src/modules/providers/service.mjs'); const db=read('database/010_v4_10_integration_hardening.sql');
 assert.match(s,/provider-applications/); assert.doesNotMatch(s,/providers\/me/); assert.match(p,/requestProviderApplication/); assert.match(p,/approveProviderApplication/); assert.match(p,/INSERT INTO hala\.providers/); assert.match(db,/CREATE TABLE IF NOT EXISTS provider_applications/);
});
test('canonical schema includes v4.10 migration and has balanced transactions',()=>{
 const s=read('database/schema.sql'); const begin=(s.match(/\bBEGIN;\b/g)||[]).length; const commit=(s.match(/\bCOMMIT;\b/g)||[]).length; assert.equal(begin,commit); assert.match(s,/Hala v4\.10 integration hardening/); assert.match(s,/provider_applications/);
});

test('docker backend runs as non-root and database readiness gates the service',()=>{
 const d=read('backend/Dockerfile'); const c=read('infra/docker/docker-compose.yml');
 assert.match(d,/USER hala/); assert.match(c,/http:\/\/127\.0\.0\.1:8080\/ready/); assert.match(c,/condition: service_healthy/);
});
