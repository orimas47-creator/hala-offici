import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

test('required backend modules exist', () => {
  const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
  for (const f of ['src/server.mjs','src/modules/bookings/service.mjs','src/modules/payments/service.mjs','src/modules/auth/service.mjs']) {
    assert.equal(fs.existsSync(path.join(root,f)), true, f);
  }
});

test('unified database migration contains canonical lifecycle and timers', () => {
  const sql = fs.readFileSync(path.resolve(path.dirname(new URL(import.meta.url).pathname),'../../database/schema.sql'),'utf8');
  assert.match(sql, /booking_lifecycle_status/);
  assert.match(sql, /booking_timers/);
  assert.match(sql, /webhook_inbox/);
  assert.match(sql, /idempotency_records/);
});

test('AI gateway has governance fallback', () => {
  const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
  const ai = fs.readFileSync(path.join(root, 'src/modules/ai/service.mjs'), 'utf8');
  assert.match(ai, /domain services remain the only/);
  assert.match(ai, /AI_PROVIDER_UNAVAILABLE/);
});
