import test from 'node:test'; import assert from 'node:assert/strict'; import {assertTransition} from '../src/common/state-machine.mjs';
test('valid booking transition',()=>assert.doesNotThrow(()=>assertTransition('DRAFT','PAYMENT_PENDING')));
test('reject skipping provider pending',()=>assert.throws(()=>assertTransition('PAYMENT_PENDING','CONFIRMED'),/INVALID_BOOKING_TRANSITION/));
test('reject completed rollback',()=>assert.throws(()=>assertTransition('COMPLETED','DRAFT'),/INVALID_BOOKING_TRANSITION/));
