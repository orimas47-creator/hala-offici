import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..','..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v4.15 inventory reservation schema is canonical and source-exclusive',()=>{
  const s=read('database/014_v4_15_universal_inventory_reservations.sql');
  assert.match(s,/CREATE TABLE IF NOT EXISTS inventory_reservations/);
  assert.match(s,/\(\(listing_id IS NOT NULL\) <> \(service_offer_id IS NOT NULL\)\)/);
  assert.match(s,/\(\(listing_unit_id IS NOT NULL\) <> \(service_unit_id IS NOT NULL\)\)/);
  assert.match(s,/operation_type VARCHAR\(20\) NOT NULL CHECK\(operation_type IN \('BUY','RENT'\)\)/);
});

test('v4.15 universal reservations serialize by source and allocate capacity',()=>{
  const s=read('backend/src/modules/availability/service.mjs');
  assert.match(s,/pg_advisory_xact_lock/);
  assert.match(s,/FOR UPDATE/);
  assert.match(s,/INSUFFICIENT_INVENTORY/);
  assert.match(s,/inventory_reservations/);
});

test('v4.15 booking payment path reserves before moving to payment pending',()=>{
  const s=read('backend/src/modules/payments/service.mjs');
  const reserve=s.indexOf('await reserveBookingInventory');
  const transition=s.indexOf("lifecycle_status='PAYMENT_PENDING'");
  assert.ok(reserve>=0 && transition>=0 && reserve<transition,'inventory must be reserved before payment-pending transition');
});

test('v4.15 booking lifecycle releases or activates inventory consistently',()=>{
  const s=read('backend/src/modules/bookings/service.mjs');
  assert.match(s,/to==='PAYMENT_PENDING'.*reserveBookingInventory/s);
  assert.match(s,/to==='PROVIDER_PENDING'.*activateBookingInventory/s);
  assert.match(s,/releaseBookingInventory\(client,id,to\)/);
});

test('v4.15 public universal availability route is exposed',()=>{
  const s=read('backend/src/server.mjs');
  assert.ok(s.includes('universalAvailability(id,url.searchParams.get(\'start\')'));
  assert.match(s,/universalAvailability/);
});

test('v4.15 timer worker expires held inventory and fails unpaid bookings',()=>{
  const s=read('backend/src/workers/booking-timer-worker.mjs');
  assert.match(s,/expireInventoryReservations/);
  assert.match(s,/inventory\.hold\.expired/);
  assert.match(s,/lifecycle_status='FAILED'/);
  assert.match(s,/DELETE FROM hala\.payment_locks/);
});
