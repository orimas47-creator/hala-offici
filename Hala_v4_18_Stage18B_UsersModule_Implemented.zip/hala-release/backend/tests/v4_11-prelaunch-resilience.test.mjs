import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..','..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v4.12 resilience schema is canonical and included',()=>{
 const s=read('database/schema.sql');
 assert.match(s,/Hala v4\.11 prelaunch resilience/);
 assert.match(s,/platform_health_snapshots/);
 assert.match(s,/attempt_count INTEGER NOT NULL DEFAULT 0/);
 assert.match(s,/next_attempt_at TIMESTAMPTZ/);
});

test('webhook worker retries poison events with bounded exponential backoff',()=>{
 const s=read('backend/src/workers/payment-webhook-worker.mjs');
 assert.match(s,/HALA_WEBHOOK_MAX_ATTEMPTS/);
 assert.match(s,/attempts>=max/);
 assert.match(s,/2\*\*Math\.min/);
 assert.match(s,/status='QUEUED'/);
 assert.match(s,/status='REVIEW'/);
});

test('central supervisor records platform health telemetry',()=>{
 const s=read('backend/src/workers/supervisor-worker.mjs');
 assert.match(s,/platform_health_snapshots/);
 assert.match(s,/markets_active/);
 assert.match(s,/webhook_backlog/);
 assert.match(s,/failed_otp_24h/);
});
