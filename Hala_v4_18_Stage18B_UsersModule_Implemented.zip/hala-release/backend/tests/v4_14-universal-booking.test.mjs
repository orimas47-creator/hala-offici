import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..','..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v4.14 universal booking bridge is in canonical schema',()=>{
 const s=read('database/schema.sql');
 assert.match(s,/Hala v4\.14 Universal Booking Bridge/);
 assert.match(s,/ALTER TABLE bookings ALTER COLUMN service_id DROP NOT NULL/);
 assert.match(s,/universal_listing_id UUID REFERENCES universal_listings/);
 assert.match(s,/ALTER TABLE booking_wishes ALTER COLUMN offer_id DROP NOT NULL/);
 assert.match(s,/listing_id UUID REFERENCES universal_listings/);
 assert.match(s,/chk_booking_source/);
});

test('booking service accepts universal listings and server-calculates pricing',()=>{
 const s=read('backend/src/modules/bookings/service.mjs');
 assert.match(s,/const universalMode=!!body\.listingId/);
 assert.match(s,/FROM hala\.universal_listings ul/);
 assert.match(s,/FROM hala\.listing_prices/);
 assert.match(s,/subtotal=Number\(rental\.amount\)\*quantity\*days/);
 assert.match(s,/INSERT INTO hala\.bookings\(customer_id,service_id,market_id,universal_listing_id,operation_type/);
});

test('booking access resolves provider from either legacy or universal listing',()=>{
 const s=read('backend/src/modules/bookings/service.mjs');
 assert.match(s,/LEFT JOIN hala\.universal_listings ul/);
 assert.match(s,/COALESCE\(p1\.user_id,p2\.user_id\)/);
 assert.match(s,/p\.user_id=\$2/);
});

test('system ledger accounts are not publicly readable',()=>{
 const s=read('backend/src/modules/ledger/service.mjs');
 assert.match(s,/if\(!own\.rows\[0\]\.owner_user_id\)/);
 assert.match(s,/lower\(r\.name\) IN \('admin','finance'\)/);
});

test('market UI carries listing identifiers for real booking submission',()=>{
 const s=read('frontend/market.html');
 assert.match(s,/universalListingId:String\(x\.id\)/);
 assert.match(s,/listingId:p\.universalListingId/);
});
