import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dbRoot = path.resolve(root, '../database');

test('v4.6 market builder module and routes are present', () => {
  assert.equal(fs.existsSync(path.join(root, 'src/modules/market-builder/service.mjs')), true);
  assert.equal(fs.existsSync(path.join(root, 'src/modules/universal-market/service.mjs')), true);
  const server = fs.readFileSync(path.join(root, 'src/server.mjs'), 'utf8');
  for (const x of ['/api/v1/admin/markets', '/api/v1/listings', '/api/v1/demands', 'getPublicMarketConfig']) {
    assert.ok(server.includes(x), x);
  }
});

test('canonical migration chain has no duplicate CREATE TABLE definitions', () => {
  const files = ['001_base.sql', '002_v4_2.sql', '004_v4_3_dynamic_markets_ai.sql', '005_v4_4_universal_market.sql', '006_v4_5_hardening.sql', '007_v4_6_market_builder.sql'];
  const seen = new Map();
  const re = /CREATE TABLE(?: IF NOT EXISTS)?\s+([a-zA-Z0-9_]+)/gi;
  for (const f of files) {
    const sql = fs.readFileSync(path.join(dbRoot, f), 'utf8');
    for (const m of sql.matchAll(re)) {
      const t = m[1].toLowerCase();
      const arr = seen.get(t) || [];
      arr.push(f);
      seen.set(t, arr);
    }
  }
  const dup = [...seen.entries()].filter(([, v]) => v.length > 1);
  assert.deepEqual(dup, []);
});

test('v4.6 migration normalizes legacy market statuses before applying the new check', () => {
  const sql = fs.readFileSync(path.join(dbRoot, '007_v4_6_market_builder.sql'), 'utf8');
  assert.match(sql, /UPDATE markets\s+SET status = CASE lower\(status\)/);
  assert.match(sql, /DROP CONSTRAINT IF EXISTS markets_status_check/);
  assert.match(sql, /CHECK \(status IN \('DRAFT','ACTIVE','PAUSED','ARCHIVED'\)\)/);
  assert.match(sql, /CREATE TABLE IF NOT EXISTS role_permissions/);
});

test('financial immutability and shared UI policies exist', () => {
  const sql = fs.readFileSync(path.join(dbRoot, '007_v4_6_market_builder.sql'), 'utf8');
  assert.match(sql, /market\.builder\.shared_ui/);
  assert.match(sql, /market\.builder\.financial_immutability/);
  assert.match(sql, /market\.builder\.demand_simple_flow/);
});

test('listing price rules require sale price for sale and rental price plus insurance for rental', () => {
  const s = fs.readFileSync(path.join(root, 'src/modules/universal-market/service.mjs'), 'utf8');
  assert.match(s, /SALE_PRICE_REQUIRED/);
  assert.match(s, /RENTAL_PRICE_REQUIRED/);
  assert.match(s, /RENTAL_INSURANCE_REQUIRED/);
  assert.match(s, /PROVIDER_NOT_ACTIVE_IN_MARKET/);
  assert.match(s, /OPERATION_NOT_ENABLED/);
});

test('v4.7 security and control-plane migration exists', () => {
  const sql = fs.readFileSync(path.join(dbRoot, '008_v4_7_supervisor_security_portal.sql'), 'utf8');
  for (const x of ['auth_sessions','global_portal_rails','global_portal_ads','ai_supervisor_configs','ai_market_bindings','ai_supervisor_events','ai_supervisor_actions']) assert.match(sql, new RegExp('CREATE TABLE IF NOT EXISTS ' + x));
  assert.match(sql,/security.require_bearer_auth/);
  assert.match(sql,/ai.platform_supervisor_hierarchy/);
});

test('production code no longer accepts X-Actor-Id unless explicitly enabled outside production', () => {
  const s=fs.readFileSync(path.join(root,'src/modules/auth/service.mjs'),'utf8');
  assert.match(s,/HALA_ALLOW_DEV_ACTOR_HEADER/);
  const server=fs.readFileSync(path.join(root,'src/server.mjs'),'utf8');
  assert.match(server,/NODE_ENV==='production'/);
});

test('payment verification is privileged', () => {
  const server=fs.readFileSync(path.join(root,'src/server.mjs'),'utf8');
  assert.match(server,/requireRoles\(ctx\.actorId,\['admin','finance'\]\)/);
});

test('provider identity is derived from authenticated user', () => {
  const s=fs.readFileSync(path.join(root,'src/modules/universal-market/service.mjs'),'utf8');
  assert.match(s,/providers WHERE user_id=\$1/);
});
