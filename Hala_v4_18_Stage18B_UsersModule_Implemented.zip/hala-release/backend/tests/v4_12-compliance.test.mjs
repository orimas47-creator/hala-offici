import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('..',import.meta.url).pathname;

test('provider self-update cannot change compliance or activation fields without admin authorization',()=>{
 const s=fs.readFileSync(root+'src/modules/providers/service.mjs','utf8');
 assert.match(s,/subscriptionStartedAt!==undefined/);
 assert.match(s,/subscriptionExpiresAt!==undefined/);
 assert.match(s,/insuranceConfirmed!==undefined/);
 assert.match(s,/status!==undefined/);
 assert.match(s,/await admin\(c,actorId\)/);
});

test('listing creation requires active market membership plus insurance confirmation and valid subscription',()=>{
 const s=fs.readFileSync(root+'src/modules/universal-market/service.mjs','utf8');
 assert.match(s,/p\.insurance_confirmed=true/);
 assert.match(s,/p\.subscription_expires_at IS NOT NULL/);
 assert.match(s,/p\.subscription_expires_at>now\(\)/);
 assert.match(s,/mm\.status='ACTIVE'/);
});

test('global portal does not expose member provider_id to public clients',()=>{
 const s=fs.readFileSync(root+'src/modules/global-portal/service.mjs','utf8');
 assert.doesNotMatch(s,/SELECT a\.id,a\.market_id,a\.provider_id,a\.advertiser_name/);
 assert.match(s,/CASE WHEN a\.provider_id IS NULL THEN a\.advertiser_name ELSE NULL END/);
});


test('v4.13 central observability migration and telemetry coverage are present',()=>{
  const root=new URL('..',import.meta.url).pathname;
  const schema=fs.readFileSync(root+'../database/schema.sql','utf8');
  assert.match(schema,/ai\.platform_supervisor\.observe_auth/);
  assert.match(schema,/ai\.platform_supervisor\.observe_bookings/);
  assert.match(schema,/ai\.platform_supervisor\.observe_providers/);
  assert.match(schema,/ai\.platform_supervisor\.observe_demands/);
  assert.match(schema,/ai\.platform_supervisor\.observe_disputes/);
  assert.match(fs.readFileSync(root+'src/modules/ai/telemetry.mjs','utf8'),/export async function emitPlatformEvent/);
});

test('public DB health endpoint is not exposed',()=>{
  const server=fs.readFileSync(root+'src/server.mjs','utf8');
  assert.doesNotMatch(server,/path===['"]\/health\/db['"]/);
});

test('booking telemetry references only in-scope variables on create and transition paths',()=>{
  const s=fs.readFileSync(root+'src/modules/bookings/service.mjs','utf8');
  assert.match(s,/eventKey:'booking\.created'.*resourceId:out\.id,actorId:actor/);
  assert.match(s,/eventKey:'booking\.transitioned'.*resourceId:id,actorId:actor/);
  assert.doesNotMatch(s,/booking\.created'.*bookingId,actorId,payload:\{toStatus:to/);
});
