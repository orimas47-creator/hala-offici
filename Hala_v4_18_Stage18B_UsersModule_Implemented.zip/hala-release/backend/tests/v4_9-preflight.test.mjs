import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dbRoot = path.resolve(root, '../database');
const read=(p)=>fs.readFileSync(p,'utf8');

test('v4.10 canonical schema includes migration 009 guardrails',()=>{
  const s=read(path.join(dbRoot,'schema.sql'));
  for(const key of ['security.production_require_tls','security.external_urls_https_only','security.ai_prompt_injection_guard','finance.no_direct_balance_edit','market.ai_central_supervisor_required']) assert.match(s,new RegExp(key.replaceAll('.','\\.')));
  assert.match(s,/Hala v4\.9 operational hardening/);
});

test('every active market is bound to the platform supervisor by migration',()=>{
  const s=read(path.join(dbRoot,'009_v4_9_operational_hardening.sql'));
  assert.match(s,/INSERT INTO ai_market_bindings/);
  assert.match(s,/supervisor_key='platform_supervisor'/);
  assert.match(s,/INHERIT_AND_RESTRICT/);
});

test('payment verification cannot be executed as a customer self-approval outcome',()=>{
  const s=read(path.join(root,'src/modules/payments/service.mjs'));
  assert.doesNotMatch(s,/customer_id=\$3/);
  assert.match(s,/PAYMENT_ALREADY_FINAL/);
  assert.match(s,/status='pending'/);
  assert.doesNotMatch(s,/outcome.*refunded/);
});

test('demand matching is protected by ownership or privileged role',()=>{
  const s=read(path.join(root,'src/modules/universal-market/service.mjs'));
  assert.match(s,/matchDemand\(actorUserId,demandId\)/);
  assert.match(s,/FORBIDDEN_DEMAND_MATCH/);
  assert.match(s,/admin.*super_admin.*administrator.*agent/);
});

test('external portal URLs are constrained',()=>{
  const s=read(path.join(root,'src/modules/global-portal/service.mjs'));
  assert.match(s,/UNSAFE_EXTERNAL_URL/);
  assert.match(s,/HTTPS_URL_REQUIRED/);
  assert.match(s,/INVALID_TARGET_PATH/);
});

test('public market listings have a real API route and service',()=>{
  const server=read(path.join(root,'src/server.mjs'));
  const service=read(path.join(root,'src/modules/universal-market/service.mjs'));
  assert.match(server,/listMarketListings/);
  assert.match(service,/export async function listMarketListings/);
});

test('reference market can be set only when active and only one is retained',()=>{
  const s=read(path.join(root,'src/modules/market-builder/service.mjs'));
  assert.match(s,/setReferenceTemplate/);
  assert.match(s,/REFERENCE_MARKET_MUST_BE_ACTIVE/);
  assert.match(s,/is_reference_template=false WHERE is_reference_template=true/);
});

test('frontend is no longer hard-coded to localhost API by default',()=>{
  for(const p of [path.join(root,'../frontend/hala-api.js'),path.join(root,'../apps/admin/hala-api.js')]){
    const s=read(p); assert.doesNotMatch(s,/HALA_API_BASE\|\|['"]http:\/\/localhost:8080/);
    assert.match(s,/HALA_API_BASE\|\|['"]\/api\/v1/);
  }
});

test('production dev OTP and actor bypass are explicitly forbidden by startup policy',()=>{
  const server=read(path.join(root,'src/server.mjs')); const auth=read(path.join(root,'src/modules/auth/service.mjs'));
  assert.match(server,/HALA_ALLOW_DEV_ACTOR_HEADER/);
  assert.match(auth,/NODE_ENV!=='production'/);
  assert.match(auth,/HALA_DEV_OTP/);
  assert.match(server,/version:'4.17.0'/);
});

test('server import graph points to implemented v4.10 services',()=>{
  const s=read(path.join(root,'src/server.mjs'));
  for(const x of ['global-portal/service.mjs','market-builder/service.mjs','universal-market/service.mjs','payments/service.mjs','auth/service.mjs']) assert.match(s,new RegExp(x.replaceAll('/','\\/')));
});
