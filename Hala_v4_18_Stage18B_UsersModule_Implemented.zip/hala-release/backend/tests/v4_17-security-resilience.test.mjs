import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..','..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('webhook replay protection supports timestamped HMAC and strict production mode',()=>{
 const s=read('backend/src/modules/payments/webhook.mjs');
 assert.match(s,/x-hala-timestamp/);
 assert.match(s,/STALE_WEBHOOK_TIMESTAMP/);
 assert.match(s,/timestamp \? `\$\{timestamp\}\.\$\{raw\}` : raw/);
 const c=read('infra/docker/docker-compose.yml');
 assert.match(c,/HALA_WEBHOOK_REQUIRE_TIMESTAMP: "true"/);
});

test('central AI telemetry degrades safely without becoming a payment failure point',()=>{
 const s=read('backend/src/modules/ai/supervisor.mjs');
 assert.match(s,/HALA_AI_TELEMETRY_FAIL_OPEN/);
 assert.match(s,/degraded:true/);
 const c=read('infra/docker/docker-compose.yml');
 assert.match(c,/HALA_AI_TELEMETRY_FAIL_OPEN: "true"/);
});

test('v4.17 migration is in canonical schema',()=>{
 const s=read('database/schema.sql');
 assert.match(s,/Hala v4\.17 Security/);
 assert.match(s,/security\.webhook_require_timestamp/);
});

test('production version is 4.17 across runtime metadata',()=>{
 const pkg=JSON.parse(read('backend/package.json'));
 assert.equal(pkg.version,'4.17.0');
 assert.match(read('backend/src/server.mjs'),/version:'4\.17\.0'/);
 assert.match(read('backend/openapi/openapi.yaml'),/4\.17\.0/);
});
