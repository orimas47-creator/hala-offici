import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..','..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v4.16 financial migration creates market agent routing and settlement ledger',()=>{
 const s=read('database/015_v4_16_financial_settlement.sql');
 assert.match(s,/CREATE TABLE IF NOT EXISTS market_agent_assignments/);
 assert.match(s,/CREATE TABLE IF NOT EXISTS financial_settlements/);
 assert.match(s,/uq_financial_settlement_idempotency/);
 assert.match(s,/uq_wallet_owner_currency/);
});

test('escrow party resolution supports universal listings and legacy offers',()=>{
 const s=read('backend/src/modules/escrow/service.mjs');
 assert.match(s,/universal_listings ul/);
 assert.match(s,/COALESCE\(ul\.provider_id,svc\.provider_id\)/);
 assert.match(s,/AGENT_ASSIGNMENT_REQUIRED/);
});

test('escrow release is blocked until booking is fully funded and uses commission split',()=>{
 const s=read('backend/src/modules/escrow/service.mjs');
 assert.match(s,/ESCROW_NOT_FULLY_FUNDED/);
 assert.match(s,/platformAmount/);
 assert.match(s,/agentAmount/);
 assert.match(s,/providerAmount/);
 assert.match(s,/HALA_PLATFORM_REVENUE/);
 assert.match(s,/AGENT_PAYABLE/);
});

test('financial settlement ledger is balanced conceptually',()=>{
 const s=read('backend/src/modules/escrow/service.mjs');
 assert.match(s,/escrowAcc,'debit'/);
 assert.match(s,/providerPayable,'credit'/);
 assert.match(s,/platformRevenue,'credit'/);
 assert.match(s,/agentPayable,'credit'/);
});

test('payment idempotency is checked before payment lock',()=>{
 const s=read('backend/src/modules/payments/service.mjs');
 const idem=s.indexOf('idempotency_records');
 const lock=s.indexOf('payment_locks');
 assert.ok(idem>=0 && lock>=0 && idem<lock);
});

test('wallet endpoint is currency aware',()=>{
 const s=read('backend/src/modules/wallet/service.mjs');
 assert.match(s,/currency/);
});

test('commission arithmetic keeps total distribution equal to gross',()=>{
 const p=0.10,a=0.05,g=1000; const platform=Math.round(g*p*100)/100; const agent=Math.round(g*a*100)/100; const provider=Math.round((g-platform-agent)*100)/100;
 assert.equal(platform+agent+provider,g);
});

test('payment schema carries currency end to end',()=>{
 const s=read('database/015_v4_16_financial_settlement.sql');
 assert.match(s,/ALTER TABLE payments ADD COLUMN IF NOT EXISTS currency_code/);
 assert.match(s,/ALTER TABLE payment_transactions ADD COLUMN IF NOT EXISTS currency_code/);
 const p=read('backend/src/modules/payments/service.mjs');
 assert.match(p,/payment_currency/);
 assert.match(p,/transaction_currency/);
});
