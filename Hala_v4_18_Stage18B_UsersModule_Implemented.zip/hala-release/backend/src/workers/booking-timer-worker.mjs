import { getDb } from '../common/db.mjs';
import { expireInventoryReservations } from '../modules/availability/service.mjs';
import { emitPlatformEvent } from '../modules/ai/telemetry.mjs';
const intervalMs=Number(process.env.HALA_WORKER_INTERVAL_MS||5000);
async function tick(){
 const db=await getDb(); const c=await db.connect(); try{await c.query('BEGIN');
  const expired=await expireInventoryReservations(c);
  for(const e of expired){
    const u=await c.query(`UPDATE hala.bookings SET lifecycle_status='FAILED',lifecycle_version=lifecycle_version+1,updated_at=now() WHERE id=$1 AND lifecycle_status='PAYMENT_PENDING' RETURNING id`,[e.booking_id]);
    if(u.rowCount){
      await c.query(`INSERT INTO hala.booking_lifecycle_history(booking_id,from_status,to_status,actor_user_id,request_id,reason) VALUES($1,'PAYMENT_PENDING','FAILED',NULL,NULL,'inventory.hold.expired')`,[e.booking_id]);
      await c.query(`DELETE FROM hala.payment_locks WHERE booking_id=$1`,[e.booking_id]);
      await c.query(`INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,before_data,after_data,request_id,result) VALUES(NULL,'INVENTORY_RESERVATION_EXPIRED','booking',$1,$2::jsonb,$3::jsonb,NULL,'SUCCESS')`,[e.booking_id,JSON.stringify({lifecycle_status:'PAYMENT_PENDING'}),JSON.stringify({lifecycle_status:'FAILED'})]);
    }
  }
  const due=await c.query(`SELECT id,booking_id,timer_type FROM hala.booking_timers WHERE processed=false AND scheduled_at<=now() ORDER BY scheduled_at FOR UPDATE SKIP LOCKED LIMIT 50`);
  for(const t of due.rows){
    await c.query(`UPDATE hala.booking_timers SET processed=true,processed_at=now(),status='DONE',updated_at=now() WHERE id=$1`,[t.id]);
    await c.query(`INSERT INTO hala.notifications(user_id,title,body,type,reference_type,reference_id) SELECT b.customer_id,$2,$3,'booking_timer','booking',b.id FROM hala.bookings b WHERE b.id=$1`,[t.booking_id,'تنبيه حجز هلا',`تم تنفيذ المؤقت ${t.timer_type}`]);
  }
  await c.query('COMMIT');
  for(const e of expired){ await emitPlatformEvent({eventKey:'inventory.hold.expired',resourceType:'booking',resourceId:e.booking_id,actorId:null,payload:{bookingId:e.booking_id}}); }
  return due.rowCount+expired.length;
 }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
async function loop(){try{await tick()}catch(e){console.error('timer-worker',e)}setTimeout(loop,intervalMs)} loop();
