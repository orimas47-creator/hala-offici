import { getDb } from '../common/db.mjs';
import { settlePaymentInTransaction } from '../modules/payments/service.mjs';
const intervalMs=Number(process.env.HALA_WORKER_INTERVAL_MS||3000);
async function processOnce(){
 const db=await getDb(); const c=await db.connect();
 try{await c.query('BEGIN');
   const q=await c.query(`SELECT id,provider_name,external_event_id,event_type,payload,attempt_count
     FROM hala.webhook_inbox
     WHERE status='QUEUED' AND (next_attempt_at IS NULL OR next_attempt_at<=now())
     ORDER BY received_at FOR UPDATE SKIP LOCKED LIMIT 20`);
   for(const e of q.rows){
     const eventType=String(e.event_type).toLowerCase(); const p=e.payload||{};
     const bookingId=p.bookingId||p.booking_id||null; const transactionId=p.transactionId||p.transaction_id||null;
     const outcome=eventType==='payment.failed'?'failed':(eventType==='payment.verified'||eventType==='payment.captured'?'verified':null);
     try {
       if(outcome && bookingId && transactionId){
         await settlePaymentInTransaction(c,null,bookingId,transactionId,outcome,{requestId:null});
         await c.query(`UPDATE hala.webhook_inbox SET status='PROCESSED',processed_at=now(),failure_reason=NULL,locked_at=NULL WHERE id=$1`,[e.id]);
       } else {
         await c.query(`UPDATE hala.webhook_inbox SET status='REVIEW',failure_reason=$2,locked_at=NULL WHERE id=$1`,[e.id,'EVENT_REQUIRES_RECONCILIATION_OR_REFUND_ADAPTER']);
       }
     } catch(err) {
       const attempts=Number(e.attempt_count||0)+1;
       const max=Number(process.env.HALA_WEBHOOK_MAX_ATTEMPTS||8);
       const terminal=attempts>=max;
       const delay=Math.min(3600,Math.max(5,2**Math.min(attempts,10)));
       await c.query(`UPDATE hala.webhook_inbox SET status=$2,attempt_count=$3,next_attempt_at=CASE WHEN $2='QUEUED' THEN now()+make_interval(secs=>$4) ELSE NULL END,failure_reason=$5,locked_at=NULL WHERE id=$1`,[e.id,terminal?'REVIEW':'QUEUED',attempts,delay,String(err?.code||err?.message||'WEBHOOK_PROCESSING_FAILED').slice(0,500)]);
     }
   }
   await c.query('COMMIT'); return q.rowCount;
 }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}
async function loop(){try{await processOnce()}catch(e){console.error('webhook-worker',e)}setTimeout(loop,intervalMs)}
loop();
