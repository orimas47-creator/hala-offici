import { getDb } from '../common/db.mjs';
const intervalMs=Number(process.env.HALA_WORKER_INTERVAL_MS||4000);
let lastHealthAt=0;
async function snapshot(c){
 const now=Date.now(); if(now-lastHealthAt<30000)return; lastHealthAt=now;
 const q=await c.query(`SELECT
  (SELECT count(*)::int FROM hala.markets WHERE status='ACTIVE' AND is_deleted=false) markets_active,
  (SELECT count(*)::int FROM hala.universal_listings WHERE listing_status='PUBLISHED') listings_published,
  (SELECT count(*)::int FROM hala.payments WHERE status='pending') pending_payments,
  (SELECT count(*)::int FROM hala.webhook_inbox WHERE status='QUEUED') webhook_backlog,
  (SELECT count(*)::int FROM hala.ai_supervisor_incidents WHERE status IN ('OPEN','ACKNOWLEDGED','MITIGATING')) open_incidents,
  (SELECT count(*)::int FROM hala.otp_events WHERE created_at>now()-interval '24 hours' AND attempt_count>0) failed_otp_24h`);
 const r=q.rows[0];
 await c.query(`INSERT INTO hala.platform_health_snapshots(markets_active,listings_published,pending_payments,webhook_backlog,open_incidents,failed_otp_24h,metadata) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)`,[r.markets_active,r.listings_published,r.pending_payments,r.webhook_backlog,r.open_incidents,r.failed_otp_24h,JSON.stringify({source:'supervisor-worker',mode:'rules-telemetry'})]);
}
async function tick(){const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');
 const q=await c.query(`SELECT e.id FROM hala.ai_supervisor_events e WHERE e.status IN ('OBSERVED','QUEUED') ORDER BY e.created_at FOR UPDATE SKIP LOCKED LIMIT 50`);
 for(const e of q.rows){await c.query(`UPDATE hala.ai_supervisor_events SET status='REVIEWED',processed_at=now() WHERE id=$1`,[e.id]);}
 await snapshot(c);
 await c.query("DELETE FROM hala.platform_health_snapshots WHERE observed_at<now()-interval '30 days'");
 await c.query('COMMIT');return q.rowCount;}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
async function loop(){try{await tick()}catch(e){console.error('supervisor-worker',e)}setTimeout(loop,intervalMs)}
loop();
