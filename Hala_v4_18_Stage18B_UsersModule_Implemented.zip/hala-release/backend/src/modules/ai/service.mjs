import crypto from 'node:crypto';

/** Provider-agnostic AI gateway.
 * AI may observe, score, classify and recommend; domain services remain the only
 * authority for money, permissions, lifecycle transitions and final enforcement.
 */
export class AIGateway {
  constructor({ db, logger = console, adapter = null }) {
    this.db = db;
    this.logger = logger;
    this.adapter = adapter;
  }

  async emitEvent(input) {
    const eventKey = String(input.eventKey || 'unknown');
    const payload = input.payload ?? {};
    const eventId = crypto.randomUUID();
    await this.db.query(
      `INSERT INTO ai_events(event_key, source_module, resource_type, resource_id, actor_id, payload_json)
       VALUES($1,$2,$3,$4,$5,$6::jsonb)`,
      [eventKey, input.sourceModule || 'unknown', input.resourceType || null, input.resourceId ? String(input.resourceId) : null, input.actorId || null, JSON.stringify({ eventId, ...payload })],
    );
    return { eventId };
  }

  async analyze(input) {
    const base = { riskScore: 0, findings: [], recommendations: [], engine: 'rules-fallback' };
    try {
      if (this.adapter?.analyze) {
        const result = await this.adapter.analyze(input);
        return { ...base, ...result, engine: this.adapter.name || 'external-ai' };
      }
    } catch (error) {
      this.logger.error?.('AI adapter failure', error);
      return { ...base, findings: [{ type: 'AI_PROVIDER_UNAVAILABLE', severity: 'medium' }] };
    }

    // Deterministic safe fallback for local/offline pilot.
    const text = JSON.stringify(input.payload || {}).toLowerCase();
    if (text.includes('http://') || text.includes('javascript:')) {
      base.riskScore = 0.72;
      base.findings.push({ type: 'SUSPICIOUS_CONTENT', severity: 'high' });
      base.recommendations.push('إيقاف النشر الآلي وإرسال العنصر للمراجعة البشرية.');
    }
    return base;
  }
}
