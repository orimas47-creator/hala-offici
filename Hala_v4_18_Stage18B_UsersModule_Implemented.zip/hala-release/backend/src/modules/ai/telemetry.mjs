import { supervise } from './supervisor.mjs';

export async function emitPlatformEvent(event, fallback={}) {
  try {
    return await supervise({...fallback,...event});
  } catch (err) {
    console.error('platform-telemetry', err?.code || err?.message || err);
    return { observed:false };
  }
}
