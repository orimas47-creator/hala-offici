import { getDb } from '../../common/db.mjs';
const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});

export async function ensureSupervisor(client){
  const r=await client.query(`SELECT * FROM hala.ai_supervisor_configs WHERE supervisor_key='platform_supervisor' AND enabled=true LIMIT 1`);
  if(!r.rowCount) throw fail('PLATFORM_AI_SUPERVISOR_UNAVAILABLE',503); return r.rows[0];
}
function scoreEvent(event){
  const p=event.payload||{}; let score=0; const findings=[]; const text=JSON.stringify(p);
  if(/javascript:|<script|data:text\/html|union\s+select|onerror\s*=|onload\s*=/i.test(text)){score=Math.max(score,.98);findings.push({type:'MALICIOUS_CONTENT',severity:'CRITICAL'});}
  if(Number(p.amount)>Number(process.env.HALA_AI_HIGH_PAYMENT_THRESHOLD||100000000)){score=Math.max(score,.85);findings.push({type:'HIGH_VALUE_PAYMENT',severity:'HIGH'});}
  if(p.riskScore!=null)score=Math.max(score,Math.min(1,Number(p.riskScore)||0));
  return {score,findings};
}

export async function superviseInTransaction(client,event){
  let supervisor;
  try { supervisor=await ensureSupervisor(client); } catch(err) {
    if(String(process.env.HALA_AI_TELEMETRY_FAIL_OPEN||'true').toLowerCase()==='true') return {observed:false,riskScore:0,findings:[],degraded:true,reason:err?.code||'SUPERVISOR_UNAVAILABLE'};
    throw err;
  }
  const scored=scoreEvent(event);
  const e=await client.query(`INSERT INTO hala.ai_supervisor_events(supervisor_id,market_id,event_key,resource_type,resource_id,severity,risk_score,source_ai_agent_id,payload,status) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,'REVIEWED') RETURNING id`,[
    supervisor.id,event.marketId||null,event.eventKey||'UNKNOWN',event.resourceType||null,event.resourceId||null,scored.score>=.9?'CRITICAL':scored.score>=.75?'HIGH':scored.score>=.45?'MEDIUM':scored.score>=.2?'LOW':'INFO',scored.score,event.sourceAiAgentId||null,JSON.stringify(event.payload||{})]);
  for(const f of scored.findings){
    const inc=await client.query(`INSERT INTO hala.ai_supervisor_incidents(market_id,supervisor_event_id,incident_type,severity,status,summary,evidence_json) VALUES($1,$2,$3,$4,'OPEN',$5,$6::jsonb) RETURNING id`,[event.marketId||null,e.rows[0].id,f.type,f.severity,`Platform supervisor detected ${f.type}`,JSON.stringify(event.payload||{})]);
    if(f.type==='MALICIOUS_CONTENT' && event.resourceType==='universal_listing' && event.resourceId){
      await client.query(`INSERT INTO hala.ai_supervisor_actions(supervisor_event_id,action_code,action_scope,proposed_json,execution_status,executed_by_rule,executed_at) VALUES($1,'QUARANTINE_LISTING','LISTING',$2::jsonb,'EXECUTED',true,now())`,[e.rows[0].id,JSON.stringify({listingId:event.resourceId,incidentId:inc.rows[0].id})]);
      await client.query(`UPDATE hala.universal_listings SET listing_status='SUSPENDED',updated_at=now() WHERE id=$1 AND listing_status IN ('DRAFT','AI_REVIEW','HUMAN_REVIEW','APPROVED','PUBLISHED')`,[event.resourceId]);
    } else if(f.severity==='HIGH'||f.severity==='CRITICAL') await client.query(`INSERT INTO hala.ai_supervisor_actions(supervisor_event_id,action_code,action_scope,proposed_json,execution_status) VALUES($1,'ESCALATE_TO_HUMAN','PLATFORM',$2::jsonb,'PROPOSED')`,[e.rows[0].id,JSON.stringify({reason:f.type})]);
  }
  return {eventId:e.rows[0].id,riskScore:scored.score,findings:scored.findings};
}
export async function supervise(event){const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');const r=await superviseInTransaction(c,event);await c.query('COMMIT');return r}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function globalAiStatus(){
 const db=await getDb();const r=await db.query(`SELECT c.*, (SELECT COUNT(*) FROM hala.ai_supervisor_incidents i WHERE i.status IN ('OPEN','ACKNOWLEDGED','MITIGATING'))::int open_incidents, (SELECT COUNT(*) FROM hala.ai_supervisor_events e WHERE e.created_at>now()-interval '24 hours')::int events_24h FROM hala.ai_supervisor_configs c WHERE c.supervisor_key='platform_supervisor' LIMIT 1`);return r.rows[0]||null;
}
