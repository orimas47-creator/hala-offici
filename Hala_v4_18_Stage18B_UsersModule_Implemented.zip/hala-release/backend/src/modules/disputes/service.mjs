import {getDb} from '../../common/db.mjs';
export async function openDispute(actorId,bookingId,reason){
  if(!reason) throw Object.assign(new Error('DISPUTE_REASON_REQUIRED'),{status:400});
  const db=await getDb(); const c=await db.connect();
  try { await c.query('BEGIN');
    const b=await c.query(`SELECT b.lifecycle_status,b.customer_id,p.user_id AS provider_user_id FROM hala.bookings b LEFT JOIN hala.booking_wishes bw ON bw.booking_id=b.id AND bw.wish_rank=1 LEFT JOIN hala.service_offers so ON so.id=bw.offer_id LEFT JOIN hala.providers p ON p.id=so.provider_id WHERE b.id=$1 FOR UPDATE`,[bookingId]);
    if(!b.rowCount) throw Object.assign(new Error('BOOKING_NOT_FOUND'),{status:404});
    const participant=actorId===b.rows[0].customer_id || actorId===b.rows[0].provider_user_id; if(!participant){const a=await c.query(`SELECT 1 FROM hala.user_roles ur JOIN hala.roles r ON r.id=ur.role_id WHERE ur.user_id=$1 AND lower(r.name) IN ('admin','agent','finance')`,[actorId]);if(!a.rowCount) throw Object.assign(new Error('FORBIDDEN_DISPUTE'),{status:403});}
    if(!['CONFIRMED','IN_PROGRESS','RETURN_PENDING','INSPECTION'].includes(b.rows[0].lifecycle_status)) throw Object.assign(new Error('DISPUTE_NOT_ALLOWED'),{status:409});
    const d=await c.query(`INSERT INTO hala.disputes(booking_id,opened_by,status,reason) VALUES($1,$2,'open',$3) RETURNING *`,[bookingId,actorId,reason]);
    await c.query(`UPDATE hala.bookings SET lifecycle_status='DISPUTED',lifecycle_version=lifecycle_version+1,updated_at=now() WHERE id=$1`,[bookingId]);
    await c.query(`INSERT INTO hala.booking_lifecycle_history(booking_id,from_status,to_status,actor_user_id,reason) VALUES($1,$2,'DISPUTED',$3,$4)`,[bookingId,b.rows[0].lifecycle_status,actorId,'dispute.opened']);
    await c.query('COMMIT'); return d.rows[0];
  } catch(e){await c.query('ROLLBACK'); throw e} finally{c.release()}
}
