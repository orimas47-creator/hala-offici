import { Controller, Get } from '@nestjs/common';
import { DatabaseService } from '../../database/database.service.js';

@Controller()
export class HealthController {
  constructor(private readonly db: DatabaseService) {}

  @Get('health') health() { return { ok: true, service: 'hala-backend', version: '4.18.0', framework: 'nestjs' }; }
  @Get('ready') async ready() { await this.db.ping(); return { ok: true, ready: true, database: true, framework: 'nestjs' }; }
}
