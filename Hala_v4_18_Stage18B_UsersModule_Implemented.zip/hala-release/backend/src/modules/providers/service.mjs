import { getDb } from '../../common/db.mjs';
import { emitPlatformEvent } from '../ai/telemetry.mjs';
const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});
const uuidRx=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const uuid=v=>uuidRx.test(String(v||''));
async function admin(c,actorId){const q=await c.query(`SELECT 1 FROM hala.user_roles ur JOIN hala.roles r ON r.id=ur.role_id WHERE ur.user_id=$1 AND lower(r.name) IN ('admin','super_admin','administrator')`,[actorId]);if(!q.rowCount)throw fail('FORBIDDEN',403)}
async function ensureUser(c,userId){const q=await c.query(`SELECT id FROM hala.users WHERE id=$1 AND is_active=true`,[userId]);if(!q.rowCount)throw fail('USER_NOT_FOUND',404)}
export async function getProvider(actorId,providerId){
 const db=await getDb(); const q=await db.query(`SELECT p.*,u.phone,u.full_name FROM hala.providers p JOIN hala.users u ON u.id=p.user_id WHERE p.id=$1`,[providerId]); if(!q.rowCount)throw fail('PROVIDER_NOT_FOUND',404);
 const own=q.rows[0].user_id===actorId; const a=await db.query(`SELECT 1 FROM hala.user_roles ur JOIN hala.roles r ON r.id=ur.role_id WHERE ur.user_id=$1 AND lower(r.name) IN ('admin','super_admin','administrator','agent')`,[actorId]); if(!own&&!a.rowCount)throw fail('FORBIDDEN',403); return q.rows[0];
}
export async function requestProviderApplication(actorId,body={}){
 if(!actorId)throw fail('ACTOR_REQUIRED',401); const marketId=body.marketId; if(marketId&&!uuid(marketId))throw fail('INVALID_MARKET_ID');
 const db=await getDb(); const c=await db.connect(); try{await c.query('BEGIN'); await ensureUser(c,actorId);
   const existing=await c.query(`SELECT id,status FROM hala.provider_applications WHERE user_id=$1 AND status IN ('PENDING','UNDER_REVIEW') ORDER BY created_at DESC LIMIT 1`,[actorId]); if(existing.rowCount){await c.query('COMMIT');return existing.rows[0];}
   if(marketId){const m=await c.query(`SELECT id FROM hala.markets WHERE id=$1 AND status='ACTIVE' AND is_deleted=false`,[marketId]);if(!m.rowCount)throw fail('MARKET_NOT_ACTIVE',409);}
   const r=await c.query(`INSERT INTO hala.provider_applications(user_id,market_id,business_name,application_data,status) VALUES($1,$2,$3,$4::jsonb,'PENDING') RETURNING *`,[actorId,marketId||null,body.businessName?String(body.businessName).trim():null,JSON.stringify(body.applicationData||{})]);
   await c.query('COMMIT'); return r.rows[0];
 }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}
export async function listProviderApplications(actorId,filters={}){const db=await getDb();await admin(db,actorId);const status=filters.status?String(filters.status).toUpperCase():null;return (await db.query(`SELECT pa.*,u.phone,u.full_name,m.name_ar market_name FROM hala.provider_applications pa JOIN hala.users u ON u.id=pa.user_id LEFT JOIN hala.markets m ON m.id=pa.market_id WHERE ($1::text IS NULL OR pa.status=$1) ORDER BY pa.created_at DESC LIMIT 200`,[status])).rows;}
export async function approveProviderApplication(actorId,applicationId,body={}){
 if(!uuid(applicationId))throw fail('INVALID_APPLICATION_ID'); const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await admin(c,actorId);
   const a=await c.query(`SELECT * FROM hala.provider_applications WHERE id=$1 FOR UPDATE`,[applicationId]);if(!a.rowCount)throw fail('APPLICATION_NOT_FOUND',404);const app=a.rows[0];if(app.status==='APPROVED')throw fail('APPLICATION_ALREADY_APPROVED',409);if(['REJECTED','CANCELLED'].includes(app.status))throw fail('APPLICATION_NOT_APPROVABLE',409);
   const existing=await c.query(`SELECT * FROM hala.providers WHERE user_id=$1 FOR UPDATE`,[app.user_id]);let provider;
   if(existing.rowCount){provider=existing.rows[0]; await c.query(`UPDATE hala.providers SET business_name=COALESCE($2,business_name),status='active',insurance_confirmed=$3 WHERE id=$1`,[provider.id,app.business_name||null,body.insuranceConfirmed===true]);}
   else {const r=await c.query(`INSERT INTO hala.providers(user_id,business_name,status,insurance_confirmed) VALUES($1,$2,'active',$3) RETURNING *`,[app.user_id,app.business_name||null,body.insuranceConfirmed===true]);provider=r.rows[0];}
   if(app.market_id){await c.query(`INSERT INTO hala.market_provider_memberships(market_id,provider_id,status) VALUES($1,$2,'ACTIVE') ON CONFLICT(market_id,provider_id) DO UPDATE SET status='ACTIVE',updated_at=now()`,[app.market_id,provider.id]);}
   await c.query(`UPDATE hala.provider_applications SET status='APPROVED',reviewed_by=$2,reviewed_at=now(),provider_id=$3 WHERE id=$1`,[applicationId,actorId,provider.id]);
   await c.query(`INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,after_data,result) VALUES($1,'PROVIDER_APPLICATION_APPROVED','provider_application',$2,$3::jsonb,'SUCCESS')`,[actorId,applicationId,JSON.stringify({providerId:provider.id,marketId:app.market_id})]);
   await c.query('COMMIT'); await emitPlatformEvent({eventKey:'provider.application_approved',resourceType:'provider',resourceId:provider.id,actorId,payload:{marketId:app.market_id}}); return provider;
 }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function rejectProviderApplication(actorId,applicationId,reason=null){if(!uuid(applicationId))throw fail('INVALID_APPLICATION_ID');const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await admin(c,actorId);const r=await c.query(`UPDATE hala.provider_applications SET status='REJECTED',reviewed_by=$2,reviewed_at=now(),review_reason=$3 WHERE id=$1 AND status IN ('PENDING','UNDER_REVIEW') RETURNING *`,[applicationId,actorId,reason]);if(!r.rowCount)throw fail('APPLICATION_NOT_REJECTABLE',409);await c.query('COMMIT');return r.rows[0]}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function updateProvider(actorId,providerId,body={}){
 if(!uuid(providerId))throw fail('INVALID_PROVIDER_ID'); const db=await getDb(); const c=await db.connect(); try{await c.query('BEGIN'); const q=await c.query('SELECT * FROM hala.providers WHERE id=$1 FOR UPDATE',[providerId]); if(!q.rowCount)throw fail('PROVIDER_NOT_FOUND',404); const own=q.rows[0].user_id===actorId; if(!own)await admin(c,actorId);
   if(body.subscriptionStartedAt!==undefined || body.subscriptionExpiresAt!==undefined || body.insuranceConfirmed!==undefined || body.status!==undefined){
     await admin(c,actorId);
   }
   const r=await c.query(`UPDATE hala.providers SET business_name=COALESCE($2,business_name),subscription_started_at=CASE WHEN $3::timestamptz IS NULL THEN subscription_started_at ELSE $3 END,subscription_expires_at=CASE WHEN $4::timestamptz IS NULL THEN subscription_expires_at ELSE $4 END,insurance_confirmed=CASE WHEN $5::boolean IS NULL THEN insurance_confirmed ELSE $5 END WHERE id=$1 RETURNING *`,[providerId,body.businessName==null?null:String(body.businessName).trim()||null,body.subscriptionStartedAt||null,body.subscriptionExpiresAt||null,body.insuranceConfirmed==null?null:!!body.insuranceConfirmed]);
   if(body.status!==undefined){ const allowed=['pending','active','suspended','closed']; if(!allowed.includes(String(body.status)))throw fail('INVALID_PROVIDER_STATUS'); await c.query('UPDATE hala.providers SET status=$2 WHERE id=$1',[providerId,String(body.status)]);}
   await c.query('COMMIT'); const result=(await c.query('SELECT * FROM hala.providers WHERE id=$1',[providerId])).rows[0]; await emitPlatformEvent({eventKey:'provider.updated',resourceType:'provider',resourceId:providerId,actorId,payload:{fields:Object.keys(body)}}); return result;
 }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}
