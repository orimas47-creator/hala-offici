import { getDb } from '../../common/db.mjs';

const fail=(code,status=409)=>Object.assign(new Error(code),{status,code});
const ACTIVE_RES="status IN ('HELD','ACTIVE','SOLD')";

async function lockInventory(c, key){
  await c.query(`SELECT pg_advisory_xact_lock(hashtextextended($1,0))`,[String(key)]);
}

async function availableCapacity(c,{source, sourceId, startsAt, endsAt, operationType}){
  const isUniversal=source==='listing';
  const units=await c.query(isUniversal
    ? `SELECT lu.id,lu.quantity FROM hala.listing_units lu
       JOIN hala.universal_listings ul ON ul.id=lu.listing_id
       WHERE lu.listing_id=$1 AND lu.status='AVAILABLE' AND lu.quantity>0 ORDER BY lu.id FOR UPDATE`
    : `SELECT su.id,su.quantity FROM hala.service_units su
       JOIN hala.service_offers so ON so.id=su.offer_id
       WHERE su.offer_id=$1 AND su.unit_status='available' AND su.quantity>0 ORDER BY su.id FOR UPDATE`,[sourceId]);
  return {units:units.rows,isUniversal};
}

async function unitReserved(c,{unit,isUniversal,startsAt,endsAt,operationType}){
  const col=isUniversal?'listing_unit_id':'service_unit_id';
  const q=await c.query(`SELECT COALESCE(SUM(quantity),0)::numeric reserved
    FROM hala.inventory_reservations
    WHERE ${col}=$1 AND ${ACTIVE_RES}
      AND (operation_type='BUY' OR $3='BUY' OR (starts_at < $2 AND ends_at > $4))`,
    [unit.id, endsAt, operationType, startsAt]);
  return Number(q.rows[0].reserved||0);
}

export async function reserveBookingInventory(client, bookingId, opts={}){
  const c=client;
  const b=opts.booking || (await c.query('SELECT * FROM hala.bookings WHERE id=$1 FOR UPDATE',[bookingId])).rows[0];
  if(!b) throw fail('BOOKING_NOT_FOUND',404);
  const source=b.universal_listing_id?'listing':'service';
  const sourceId=b.universal_listing_id||null;
  const serviceId=b.service_id||null;
  const operation=String(b.operation_type||'RENT').toUpperCase();
  if(!['BUY','RENT'].includes(operation)) return {reserved:false,reason:'NON_INVENTORY_OPERATION'};
  const key=source==='listing'?`listing:${sourceId}`:`offer:${serviceId}`;
  await lockInventory(c,key);
  const existing=await c.query(`SELECT * FROM hala.inventory_reservations WHERE booking_id=$1 AND ${source==='listing'?'listing_id=$2':'service_offer_id=$2'} AND status IN ('HELD','ACTIVE','SOLD') LIMIT 1`,[bookingId,source==='listing'?sourceId:serviceId]);
  if(existing.rowCount) return {reserved:true,existing:true,reservations:existing.rows};

  const {units,isUniversal}=await availableCapacity(c,{source,sourceId:source==='listing'?sourceId:serviceId,startsAt:b.event_start,endsAt:b.event_end,operationType:operation});
  if(!units.length) throw fail(isUniversal?'LISTING_INVENTORY_NOT_CONFIGURED':'SERVICE_INVENTORY_NOT_CONFIGURED');
  let remaining=Number(b.quantity||1);
  const allocations=[];
  for(const unit of units){
    if(remaining<=0) break;
    if(isUniversal===false){
      const maintenance=await c.query(`SELECT 1 FROM hala.maintenance_blocks WHERE unit_id=$1 AND start_at<$3 AND end_at>$2 LIMIT 1`,[unit.id,b.event_start,b.event_end]);
      if(maintenance.rowCount) continue;
    }
    const reserved=await unitReserved(c,{unit,isUniversal,startsAt:b.event_start,endsAt:b.event_end,operationType:operation});
    const free=Math.max(0,Number(unit.quantity)-reserved);
    if(free<=0) continue;
    const take=Math.min(free,remaining);
    allocations.push({unitId:unit.id,quantity:take});
    remaining-=take;
  }
  if(remaining>0) throw fail('INSUFFICIENT_INVENTORY',409);
  for(const a of allocations){
    await c.query(`INSERT INTO hala.inventory_reservations(booking_id,listing_id,service_offer_id,listing_unit_id,service_unit_id,quantity,operation_type,starts_at,ends_at,status,expires_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'HELD',now()+interval '15 minutes')`,[
      bookingId, source==='listing'?sourceId:null, source==='service'?serviceId:null,
      source==='listing'?a.unitId:null, source==='service'?a.unitId:null,
      a.quantity,operation,b.event_start,b.event_end
    ]);
  }
  return {reserved:true,existing:false,reservations:allocations};
}

export async function activateBookingInventory(client, bookingId){
  await client.query(`UPDATE hala.inventory_reservations SET status='ACTIVE',expires_at=NULL,updated_at=now() WHERE booking_id=$1 AND status='HELD'`,[bookingId]);
}

export async function releaseBookingInventory(client, bookingId, finalStatus){
  const sale=String(finalStatus||'').toUpperCase()==='COMPLETED';
  const q=await client.query(`SELECT DISTINCT operation_type FROM hala.inventory_reservations WHERE booking_id=$1 AND status IN ('HELD','ACTIVE')`,[bookingId]);
  for(const r of q.rows){
    if(sale && r.operation_type==='BUY'){
      await client.query(`UPDATE hala.inventory_reservations SET status='SOLD',expires_at=NULL,updated_at=now() WHERE booking_id=$1 AND operation_type='BUY' AND status IN ('HELD','ACTIVE')`,[bookingId]);
    } else {
      await client.query(`UPDATE hala.inventory_reservations SET status='RELEASED',expires_at=NULL,updated_at=now() WHERE booking_id=$1 AND status IN ('HELD','ACTIVE')`,[bookingId]);
    }
  }
}

export async function expireInventoryReservations(client){
  const r=await client.query(`UPDATE hala.inventory_reservations SET status='EXPIRED',updated_at=now() WHERE status='HELD' AND expires_at IS NOT NULL AND expires_at<=now() RETURNING id,booking_id`);
  return r.rows;
}

export async function availability(offerId,start,end){
 const db=await getDb();
 const r=await db.query(`SELECT u.id,u.unit_code,u.quantity FROM hala.service_units u
 JOIN hala.service_offers o ON o.id=u.offer_id
 WHERE o.id=$1 AND o.status='published' AND u.unit_status='available'
 AND NOT EXISTS (SELECT 1 FROM hala.maintenance_blocks m WHERE m.unit_id=u.id AND m.start_at < $3 AND m.end_at > $2)
 AND NOT EXISTS (SELECT 1 FROM hala.holds h WHERE h.unit_id=u.id AND h.status='active' AND h.start_at < $3 AND h.end_at > $2 AND h.expires_at > now())
 AND NOT EXISTS (SELECT 1 FROM hala.inventory_reservations ir WHERE ir.service_unit_id=u.id AND ${ACTIVE_RES}
   AND (ir.operation_type='BUY' OR (ir.starts_at < $3 AND ir.ends_at > $2)))
 AND NOT EXISTS (SELECT 1 FROM hala.bookings b JOIN hala.booking_wishes w ON w.booking_id=b.id WHERE w.unit_id=u.id AND w.status IN ('pending','active','confirmed') AND b.event_start < $3 AND b.event_end > $2 AND b.lifecycle_status NOT IN ('CANCELLED','FAILED','COMPLETED'))
 ORDER BY u.unit_code`,[offerId,start,end]);
 return r.rows;
}

export async function universalAvailability(listingId,start,end,operationType='RENT'){
 const db=await getDb();
 const op=String(operationType||'RENT').toUpperCase();
 if(!['BUY','RENT'].includes(op)) throw fail('UNSUPPORTED_BOOKING_OPERATION',400);
 const q=await db.query(`SELECT lu.id,lu.unit_code,lu.quantity,lu.unit_type,lu.status,
   GREATEST(lu.quantity-COALESCE((SELECT SUM(ir.quantity) FROM hala.inventory_reservations ir
      WHERE ir.listing_unit_id=lu.id AND ${ACTIVE_RES}
      AND (ir.operation_type='BUY' OR $4='BUY' OR (ir.starts_at<$3 AND ir.ends_at>$2))),0),0)::numeric available_quantity
   FROM hala.listing_units lu JOIN hala.universal_listings ul ON ul.id=lu.listing_id
   JOIN hala.markets m ON m.id=ul.market_id
   WHERE lu.listing_id=$1 AND ul.listing_status='PUBLISHED' AND m.status='ACTIVE' AND m.is_deleted=false AND lu.status='AVAILABLE'
   ORDER BY lu.id`,[listingId,start,end,op]);
 return q.rows.filter(x=>Number(x.available_quantity)>0);
}
