export interface AuthRequestContext {
  requestId: string;
  actorId: string | null;
  authType: 'none' | 'bearer' | 'dev-header' | string;
  authorization?: string;
  origin?: string | null;
  ip?: string | null;
  userAgent?: string | null;
  legacyActorId?: string | null;
}
