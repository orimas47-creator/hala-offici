import { Body, Controller, Headers, Post, UnauthorizedException, UseGuards } from '@nestjs/common';
import { ActorContext } from '../../common/decorators/actor.decorator.js';
import { RequireActorGuard } from '../../common/guards/hala-auth.guard.js';
import { AuthService } from './auth.service.js';
import { RequestOtpDto, VerifyOtpDto } from './dto/auth.dto.js';
import type { AuthRequestContext } from './auth.types.js';

@Controller('api/v1/auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Post('request-otp')
  requestOtp(@Body() dto: RequestOtpDto, @ActorContext() ctx: AuthRequestContext) {
    return this.auth.requestOtp(dto, ctx);
  }

  @Post('verify-otp')
  verifyOtp(@Body() dto: VerifyOtpDto, @ActorContext() ctx: AuthRequestContext) {
    return this.auth.verifyOtp(dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('logout')
  async logout(
    @ActorContext() ctx: AuthRequestContext,
    @Headers('authorization') authorization?: string,
  ) {
    const token = authorization?.match(/^Bearer\s+([A-Za-z0-9._~-]{40,160})$/i)?.[1];
    if (!ctx.actorId || !token) throw new UnauthorizedException('ACTOR_REQUIRED');
    await this.auth.revokeSession(ctx.actorId, token);
    return { loggedOut: true };
  }
}
