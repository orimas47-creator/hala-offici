import { AuthModule } from './auth.module.js';

describe('AuthModule', () => {
  it('is a NestJS module class', () => {
    expect(AuthModule).toBeDefined();
    expect(typeof AuthModule).toBe('function');
  });
});
