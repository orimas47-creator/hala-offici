import crypto from 'node:crypto';
import { getDb } from '../../common/db.mjs';
import { emitPlatformEvent } from '../ai/telemetry.mjs';

const hash = (x) => crypto.createHash('sha256').update(String(x)).digest('hex');
const OTP_WINDOW_MINUTES = Number(process.env.HALA_OTP_WINDOW_MINUTES || 10);
const OTP_MAX_REQUESTS = Number(process.env.HALA_OTP_MAX_REQUESTS || 3);
const OTP_MAX_ATTEMPTS = Number(process.env.HALA_OTP_MAX_ATTEMPTS || 5);
const SESSION_HOURS = Number(process.env.HALA_SESSION_HOURS || 8);
const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});
const phoneRx=/^\+?[0-9]{7,20}$/;

async function findUser(db, phone){ return db.query('SELECT id FROM hala.users WHERE phone=$1',[phone]); }

export async function requestOtp(phone, purpose='login', meta={}) {
  if (!phoneRx.test(String(phone||''))) throw fail('INVALID_PHONE');
  const db = await getDb();
  const recent = await db.query(`SELECT COUNT(*)::int AS n FROM hala.otp_events WHERE phone=$1 AND purpose=$2 AND created_at > now()-make_interval(mins=>$3)`,[phone,purpose,OTP_WINDOW_MINUTES]);
  if (Number(recent.rows[0].n) >= OTP_MAX_REQUESTS) throw fail('OTP_RATE_LIMITED',429);
  if(meta.ip){ const ipRecent=await db.query(`SELECT COUNT(*)::int AS n FROM hala.otp_events WHERE ip_address=$1::inet AND created_at > now()-make_interval(mins=>$2)`,[meta.ip,OTP_WINDOW_MINUTES]); if(Number(ipRecent.rows[0].n)>=OTP_MAX_REQUESTS*5) throw fail('OTP_IP_RATE_LIMITED',429); }
  const cooldown=await db.query(`SELECT 1 FROM hala.otp_events WHERE phone=$1 AND purpose=$2 AND created_at > now()-interval '30 seconds' LIMIT 1`,[phone,purpose]);
  if(cooldown.rowCount) throw fail('OTP_COOLDOWN',429);
  let user = await findUser(db,phone);
  if (!user.rowCount) user = await db.query(`INSERT INTO hala.users(phone,full_name,account_type) VALUES($1,$2,'personal') RETURNING id`,[phone,'مستخدم جديد']);
  const code = String(crypto.randomInt(100000,1000000));
  await db.query(`INSERT INTO hala.otp_events(user_id,phone,purpose,code_hash,expires_at,attempt_count,last_attempt_at,ip_address) VALUES($1,$2,$3,$4,now()+interval '5 minutes',0,now(),$5)`,[user.rows[0].id,phone,purpose,hash(code),meta.ip||null]);
  return {accepted:true, ...(process.env.HALA_DEV_OTP==='true' && process.env.NODE_ENV!=='production' ? {devCode:code} : {})};
}

function issueToken(){ return crypto.randomBytes(48).toString('base64url'); }

export async function verifyOtp(phone, code, purpose='login', meta={}) {
  if (!phoneRx.test(String(phone||'')) || !/^\d{6}$/.test(String(code||''))) throw fail('INVALID_OR_EXPIRED_OTP',401);
  const db = await getDb(); const c=await db.connect();
  try {
    await c.query('BEGIN');
    const r=await c.query(`SELECT * FROM hala.otp_events WHERE phone=$1 AND purpose=$2 AND consumed_at IS NULL AND expires_at>now() ORDER BY created_at DESC LIMIT 1 FOR UPDATE`,[phone,purpose]);
    if(!r.rowCount || r.rows[0].attempt_count >= OTP_MAX_ATTEMPTS) throw fail('INVALID_OR_EXPIRED_OTP',401);
    const row=r.rows[0]; const ok=crypto.timingSafeEqual(Buffer.from(row.code_hash),Buffer.from(hash(code)));
    await c.query('UPDATE hala.otp_events SET attempt_count=attempt_count+1,last_attempt_at=now() WHERE id=$1',[row.id]);
    if(!ok){ await c.query('COMMIT'); await emitPlatformEvent({eventKey:'auth.otp_failed',resourceType:'user',resourceId:row.user_id,actorId:row.user_id,payload:{phoneSuffix:String(phone).slice(-3),purpose}}); throw fail('INVALID_OR_EXPIRED_OTP',401); }
    await c.query('UPDATE hala.otp_events SET consumed_at=now() WHERE id=$1',[row.id]);
    const token=issueToken(); const tokenHash=hash(token);
    await c.query(`INSERT INTO hala.auth_sessions(user_id,token_hash,expires_at,ip_address,user_agent) VALUES($1,$2,now()+make_interval(hours=>$3),$4,$5)`,[row.user_id,tokenHash,SESSION_HOURS,meta.ip||null,meta.userAgent||null]);
    await c.query(`UPDATE hala.users SET updated_at=now() WHERE id=$1`,[row.user_id]);
    await c.query('COMMIT');
    await emitPlatformEvent({eventKey:'auth.login_verified',resourceType:'user',resourceId:row.user_id,actorId:row.user_id,payload:{purpose}});
    return {verified:true,accessToken:token,expiresInSeconds:SESSION_HOURS*3600};
  }catch(e){ await c.query('ROLLBACK'); throw e; } finally { c.release(); }
}

export async function authenticate(ctx){
  const auth=String(ctx.authorization||'');
  const bearer=auth.match(/^Bearer\s+([A-Za-z0-9._~-]{40,160})$/i)?.[1] || null;
  const allowLegacy=process.env.NODE_ENV!=='production' && process.env.HALA_ALLOW_DEV_ACTOR_HEADER==='true';
  if(!bearer){
    if(allowLegacy && ctx.legacyActorId) return {...ctx,actorId:ctx.legacyActorId,authType:'dev-header'};
    return {...ctx,actorId:null,authType:'none'};
  }
  const db=await getDb();
  const tokenHash=hash(bearer);
  const r=await db.query(`SELECT s.user_id FROM hala.auth_sessions s JOIN hala.users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>now() AND u.is_active=true`,[tokenHash]);
  if(!r.rowCount) throw fail('INVALID_SESSION',401);
  await db.query(`UPDATE hala.auth_sessions SET last_seen_at=now() WHERE token_hash=$1`,[tokenHash]);
  return {...ctx,actorId:r.rows[0].user_id,authType:'bearer'};
}

export async function requireRoles(actorId, roles){
  const db=await getDb();
  if(!actorId) throw fail('ACTOR_REQUIRED',401);
  const names=roles.map(r=>String(r).toLowerCase());
  const q=await db.query(`SELECT 1 FROM hala.user_roles ur JOIN hala.roles r ON r.id=ur.role_id WHERE ur.user_id=$1 AND lower(r.name)=ANY($2::text[]) LIMIT 1`,[actorId,names]);
  if(!q.rowCount) throw fail('FORBIDDEN',403);
}

export async function revokeSession(actorId, token){
  const db=await getDb(); if(!actorId || !token) return;
  await db.query('UPDATE hala.auth_sessions SET revoked_at=now() WHERE user_id=$1 AND token_hash=$2',[actorId,hash(token)]);
}
