import {
  Injectable,
  TooManyRequestsException,
  UnauthorizedException,
} from '@nestjs/common';
import { DataSource, QueryRunner } from 'typeorm';
import { createHash, createHmac, randomBytes, randomInt, timingSafeEqual } from 'node:crypto';
import { AuthRequestContext } from './auth.types.js';

const PHONE_RX = /^\+?[0-9]{7,20}$/;
const TOKEN_RX = /^[A-Za-z0-9._~-]{40,160}$/;
const DEFAULT_OTP_WINDOW_MINUTES = 10;
const DEFAULT_OTP_MAX_REQUESTS = 3;
const DEFAULT_OTP_MAX_ATTEMPTS = 5;
const DEFAULT_OTP_EXPIRY_MINUTES = 5;
const DEFAULT_SESSION_HOURS = 8;

function asPositiveInt(name: string, fallback: number): number {
  const raw = Number(process.env[name] ?? fallback);
  return Number.isInteger(raw) && raw > 0 ? raw : fallback;
}

function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}

function makeCodeHash(code: string): string {
  return sha256(code);
}

function newAccessToken(): string {
  return randomBytes(48).toString('base64url');
}

function appError(code: string, status: number): Error & { code: string; status: number } {
  const error = Object.assign(new Error(code), { code, status });
  return error;
}

function normalizePhone(phone: string): string {
  return String(phone ?? '').trim();
}

@Injectable()
export class AuthService {
  constructor(private readonly dataSource: DataSource) {}

  async requestOtp(
    dto: { phone: string; purpose?: string },
    ctx: AuthRequestContext,
  ): Promise<{ accepted: true; devCode?: string }> {
    const phone = normalizePhone(dto.phone);
    const purpose = String(dto.purpose || 'login').trim();
    if (!PHONE_RX.test(phone)) throw appError('INVALID_PHONE', 400);

    const windowMinutes = asPositiveInt('HALA_OTP_WINDOW_MINUTES', DEFAULT_OTP_WINDOW_MINUTES);
    const maxRequests = asPositiveInt('HALA_OTP_MAX_REQUESTS', DEFAULT_OTP_MAX_REQUESTS);
    const db = this.dataSource;

    const recent = await db.query(
      `SELECT COUNT(*)::int AS n
         FROM hala.otp_events
        WHERE phone=$1
          AND purpose=$2
          AND created_at > now()-make_interval(mins=>$3)`,
      [phone, purpose, windowMinutes],
    );
    if (Number(recent[0]?.n ?? 0) >= maxRequests) {
      throw new TooManyRequestsException('OTP_RATE_LIMITED');
    }

    if (ctx.ip) {
      const ipRecent = await db.query(
        `SELECT COUNT(*)::int AS n
           FROM hala.otp_events
          WHERE ip_address=$1::inet
            AND created_at > now()-make_interval(mins=>$2)`,
        [ctx.ip, windowMinutes],
      );
      if (Number(ipRecent[0]?.n ?? 0) >= maxRequests * 5) {
        throw new TooManyRequestsException('OTP_IP_RATE_LIMITED');
      }
    }

    const cooldown = await db.query(
      `SELECT 1
         FROM hala.otp_events
        WHERE phone=$1
          AND purpose=$2
          AND created_at > now()-interval '30 seconds'
        LIMIT 1`,
      [phone, purpose],
    );
    if (cooldown.length > 0) throw new TooManyRequestsException('OTP_COOLDOWN');

    const userResult = await db.query(
      `SELECT id FROM hala.users WHERE phone=$1 LIMIT 1`,
      [phone],
    );

    let userId: string;
    if (userResult.length > 0) {
      userId = String(userResult[0].id);
    } else {
      const created = await db.query(
        `INSERT INTO hala.users(phone,full_name,account_type)
         VALUES($1,$2,'personal') RETURNING id`,
        [phone, 'مستخدم جديد'],
      );
      userId = String(created[0].id);
    }

    const code = String(randomInt(100000, 1000000));
    const expiryMinutes = asPositiveInt('HALA_OTP_EXPIRY_MINUTES', DEFAULT_OTP_EXPIRY_MINUTES);

    await db.query(
      `INSERT INTO hala.otp_events
        (user_id,phone,purpose,code_hash,expires_at,attempt_count,last_attempt_at,ip_address)
       VALUES($1,$2,$3,$4,now()+make_interval(mins=>$5),0,now(),$6::inet)`,
      [userId, phone, purpose, makeCodeHash(code), expiryMinutes, ctx.ip || null],
    );

    const devOtpEnabled =
      process.env.HALA_DEV_OTP === 'true' && process.env.NODE_ENV !== 'production';
    return devOtpEnabled ? { accepted: true, devCode: code } : { accepted: true };
  }

  async verifyOtp(
    dto: { phone: string; code: string; purpose?: string },
    ctx: AuthRequestContext,
  ): Promise<{ verified: true; accessToken: string; expiresInSeconds: number }> {
    const phone = normalizePhone(dto.phone);
    const code = String(dto.code ?? '').trim();
    const purpose = String(dto.purpose || 'login').trim();
    if (!PHONE_RX.test(phone) || !/^\d{6}$/.test(code)) {
      throw new UnauthorizedException('INVALID_OR_EXPIRED_OTP');
    }

    const maxAttempts = asPositiveInt('HALA_OTP_MAX_ATTEMPTS', DEFAULT_OTP_MAX_ATTEMPTS);
    const sessionHours = asPositiveInt('HALA_SESSION_HOURS', DEFAULT_SESSION_HOURS);
    const runner = this.dataSource.createQueryRunner();

    await runner.connect();
    await runner.startTransaction();
    try {
      const rows = await runner.query(
        `SELECT *
           FROM hala.otp_events
          WHERE phone=$1
            AND purpose=$2
            AND consumed_at IS NULL
            AND expires_at>now()
          ORDER BY created_at DESC
          LIMIT 1
          FOR UPDATE`,
        [phone, purpose],
      );

      if (rows.length === 0 || Number(rows[0].attempt_count) >= maxAttempts) {
        throw new UnauthorizedException('INVALID_OR_EXPIRED_OTP');
      }

      const row = rows[0];
      const expected = Buffer.from(String(row.code_hash), 'utf8');
      const received = Buffer.from(makeCodeHash(code), 'utf8');
      const ok = expected.length === received.length && timingSafeEqual(expected, received);

      await runner.query(
        `UPDATE hala.otp_events
            SET attempt_count=attempt_count+1,last_attempt_at=now()
          WHERE id=$1`,
        [row.id],
      );

      if (!ok) {
        await runner.commitTransaction();
        throw new UnauthorizedException('INVALID_OR_EXPIRED_OTP');
      }

      await runner.query(`UPDATE hala.otp_events SET consumed_at=now() WHERE id=$1`, [row.id]);
      const token = newAccessToken();
      const tokenHash = sha256(token);

      await runner.query(
        `INSERT INTO hala.auth_sessions(user_id,token_hash,expires_at,ip_address,user_agent)
         VALUES($1,$2,now()+make_interval(hours=>$3),$4::inet,$5)`,
        [row.user_id, tokenHash, sessionHours, ctx.ip || null, ctx.userAgent || null],
      );

      await runner.query(`UPDATE hala.users SET updated_at=now() WHERE id=$1`, [row.user_id]);
      await runner.commitTransaction();

      return {
        verified: true,
        accessToken: token,
        expiresInSeconds: sessionHours * 3600,
      };
    } catch (error) {
      if (runner.isTransactionActive) await runner.rollbackTransaction();
      throw error;
    } finally {
      await runner.release();
    }
  }

  async authenticate(ctx: AuthRequestContext): Promise<AuthRequestContext> {
    const auth = String(ctx.authorization ?? '');
    const bearer = auth.match(/^Bearer\s+([A-Za-z0-9._~-]{40,160})$/i)?.[1] ?? null;
    const allowLegacy =
      process.env.NODE_ENV !== 'production' && process.env.HALA_ALLOW_DEV_ACTOR_HEADER === 'true';

    if (!bearer) {
      if (allowLegacy && ctx.legacyActorId) {
        return { ...ctx, actorId: ctx.legacyActorId, authType: 'dev-header' };
      }
      return { ...ctx, actorId: null, authType: 'none' };
    }

    if (!TOKEN_RX.test(bearer)) throw new UnauthorizedException('INVALID_SESSION');

    const tokenHash = sha256(bearer);
    const rows = await this.dataSource.query(
      `SELECT s.user_id
         FROM hala.auth_sessions s
         JOIN hala.users u ON u.id=s.user_id
        WHERE s.token_hash=$1
          AND s.revoked_at IS NULL
          AND s.expires_at>now()
          AND u.is_active=true
        LIMIT 1`,
      [tokenHash],
    );
    if (rows.length === 0) throw new UnauthorizedException('INVALID_SESSION');

    await this.dataSource.query(
      `UPDATE hala.auth_sessions SET last_seen_at=now() WHERE token_hash=$1`,
      [tokenHash],
    );

    return { ...ctx, actorId: String(rows[0].user_id), authType: 'bearer' };
  }

  async requireRoles(actorId: string | null, roles: string[]): Promise<void> {
    if (!actorId) throw new UnauthorizedException('ACTOR_REQUIRED');
    const names = roles.map((role) => String(role).toLowerCase());
    const rows = await this.dataSource.query(
      `SELECT 1
         FROM hala.user_roles ur
         JOIN hala.roles r ON r.id=ur.role_id
        WHERE ur.user_id=$1
          AND lower(r.name)=ANY($2::text[])
        LIMIT 1`,
      [actorId, names],
    );
    if (rows.length === 0) throw appError('FORBIDDEN', 403);
  }

  async revokeSession(actorId: string, token: string): Promise<void> {
    if (!actorId || !token) return;
    await this.dataSource.query(
      `UPDATE hala.auth_sessions SET revoked_at=now()
        WHERE user_id=$1 AND token_hash=$2`,
      [actorId, sha256(token)],
    );
  }
}
