import { UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service.js';

describe('AuthService security invariants', () => {
  const dataSource = {
    query: jest.fn(),
    createQueryRunner: jest.fn(),
  } as any;

  beforeEach(() => jest.clearAllMocks());

  it('rejects malformed bearer tokens before querying the database', async () => {
    const service = new AuthService(dataSource);
    await expect(
      service.authenticate({
        requestId: 'r1', actorId: null, authType: 'none', authorization: 'Bearer too-short',
      }),
    ).rejects.toBeInstanceOf(UnauthorizedException);
    expect(dataSource.query).not.toHaveBeenCalled();
  });

  it('accepts anonymous requests without a bearer token', async () => {
    const service = new AuthService(dataSource);
    const result = await service.authenticate({
      requestId: 'r2', actorId: null, authType: 'none',
    });
    expect(result.actorId).toBeNull();
    expect(result.authType).toBe('none');
    expect(dataSource.query).not.toHaveBeenCalled();
  });
});
