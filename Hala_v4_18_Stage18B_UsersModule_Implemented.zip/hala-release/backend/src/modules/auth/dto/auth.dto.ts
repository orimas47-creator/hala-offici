import { IsNotEmpty, IsOptional, IsString, Length, Matches } from 'class-validator';

export class RequestOtpDto {
  @IsString()
  @IsNotEmpty()
  @Matches(/^\+?[0-9]{7,20}$/)
  phone!: string;

  @IsOptional()
  @IsString()
  @Length(2, 40)
  purpose = 'login';
}

export class VerifyOtpDto {
  @IsString()
  @IsNotEmpty()
  @Matches(/^\+?[0-9]{7,20}$/)
  phone!: string;

  @IsString()
  @IsNotEmpty()
  @Matches(/^\d{6}$/)
  code!: string;

  @IsOptional()
  @IsString()
  @Length(2, 40)
  purpose = 'login';
}
