import { getDb } from '../../common/db.mjs';
import { superviseInTransaction } from '../ai/supervisor.mjs';
import { emitPlatformEvent } from '../ai/telemetry.mjs';

const OPS = new Set(['BUY','RENT','BUY_OR_RENT','SERVICE','QUOTE']);
const KINDS = {BUY:'SALE',RENT:'RENTAL',BUY_OR_RENT:'SALE_RENTAL',SERVICE:'SERVICE',QUOTE:'SERVICE'};
const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});
const idRx=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const uuid=(v,code)=>{if(!idRx.test(String(v||'')))throw fail(code||'INVALID_UUID');return v};
const num=(v,code)=>{const n=Number(v);if(!Number.isFinite(n))throw fail(code);return n};
const IDEM_ROUTE_LISTING='POST /api/v1/listings';
const IDEM_ROUTE_DEMAND='POST /api/v1/demands';

async function activeProvider(client,providerId,marketId){
  const r=await client.query(`SELECT p.id
    FROM hala.providers p
    JOIN hala.market_provider_memberships mm ON mm.provider_id=p.id
    WHERE p.id=$1
      AND p.status='active'
      AND p.insurance_confirmed=true
      AND p.subscription_expires_at IS NOT NULL
      AND p.subscription_expires_at>now()
      AND mm.market_id=$2
      AND mm.status='ACTIVE'`,[providerId,marketId]);
  if(!r.rowCount)throw fail('PROVIDER_NOT_ACTIVE_IN_MARKET',403);
}
async function marketOperation(client,marketId,op){
  const r=await client.query(`SELECT operation_code FROM hala.market_operation_configs WHERE market_id=$1 AND operation_code=$2 AND enabled=true ORDER BY version DESC LIMIT 1`,[marketId,op]);
  if(!r.rowCount)throw fail('OPERATION_NOT_ENABLED',409);
}

export async function createListing(actorUserId, body, ctx={}){
  uuid(actorUserId,'ACTOR_REQUIRED'); if(!body||typeof body!=='object')throw fail('INVALID_LISTING_PAYLOAD');
  uuid(body.marketId,'MARKET_REQUIRED'); const op=String(body.operationType||'').toUpperCase(); if(!OPS.has(op))throw fail('INVALID_OPERATION_TYPE');
  const title=String(body.title||'').trim();if(!title)throw fail('LISTING_TITLE_REQUIRED');
  const db=await getDb();const c=await db.connect();
  try{await c.query('BEGIN');
    if(ctx.idempotencyKey){const old=await c.query('SELECT response_body FROM hala.idempotency_records WHERE actor_user_id=$1 AND idempotency_key=$2 AND route=$3',[actorUserId,ctx.idempotencyKey,IDEM_ROUTE_LISTING]);if(old.rowCount){await c.query('COMMIT');return old.rows[0].response_body;}}
    const m=await c.query(`SELECT id,status,is_deleted FROM hala.markets WHERE id=$1 AND status='ACTIVE' AND is_deleted=false`,[body.marketId]);if(!m.rowCount)throw fail('MARKET_NOT_ACTIVE',409);
    const owner=await c.query(`SELECT id FROM hala.providers WHERE user_id=$1 AND status='active' LIMIT 1`,[actorUserId]); if(!owner.rowCount) throw fail('PROVIDER_NOT_ACTIVE',403); const providerId=owner.rows[0].id;
    await activeProvider(c,providerId,body.marketId);await marketOperation(c,body.marketId,op);
    if(body.sectionId){const q=await c.query('SELECT 1 FROM hala.market_sections WHERE id=$1 AND market_id=$2 AND is_active=true',[body.sectionId,body.marketId]);if(!q.rowCount)throw fail('INVALID_LISTING_SECTION',400);}
    if(body.categoryId){const q=await c.query('SELECT 1 FROM hala.categories WHERE id=$1 AND market_id=$2 AND is_active=true',[body.categoryId,body.marketId]);if(!q.rowCount)throw fail('INVALID_LISTING_CATEGORY',400);}
    if(['BUY','BUY_OR_RENT'].includes(op) && !(Number(body.salePrice)>0)) throw fail('SALE_PRICE_REQUIRED');
    if(['RENT','BUY_OR_RENT'].includes(op) && !(Number(body.rentalPrice)>0)) throw fail('RENTAL_PRICE_REQUIRED');
    if(['RENT','BUY_OR_RENT'].includes(op) && !(Number(body.insurancePrice)>=0)) throw fail('RENTAL_INSURANCE_REQUIRED');
    const listing=await c.query(`INSERT INTO hala.universal_listings
      (market_id,section_id,category_id,provider_id,title,short_description,long_description,listing_kind,listing_status,brand,manufacturer_name,model_name,model_year,condition_code,country_of_origin,quantity,unit_code,min_order_quantity,max_order_quantity,base_currency,base_price,pricing_model,searchable_text,tags,attributes,specifications,usage_constraints,service_capabilities,compatibility,source_type,version)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,'AI_REVIEW',$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24::jsonb,$25::jsonb,$26::jsonb,$27::jsonb,$28::jsonb,$29,1) RETURNING *`,[
      body.marketId,body.sectionId||null,body.categoryId||null,providerId,title,body.shortDescription||null,body.longDescription||null,KINDS[op],op==='RENT'?body.rentalPrice:(op==='BUY'?body.salePrice:(body.salePrice||body.rentalPrice)),body.brand||null,body.manufacturerName||null,body.modelName||null,body.modelYear??null,body.conditionCode||null,body.countryOfOrigin ? String(body.countryOfOrigin).slice(0,3).toUpperCase() : null,body.quantity??1,body.unitCode||null,body.minOrderQuantity??null,body.maxOrderQuantity??null,body.currencyCode||'YER',body.basePrice??(body.salePrice||body.rentalPrice||null),body.pricingModel||op, [title,body.description||''].join(' '),body.tags||[],body.attributes||{},body.specifications||{},body.usageConstraints||{},body.serviceCapabilities||{},body.compatibility||{},'PROVIDER'
    ]);
    const l=listing.rows[0];
    const prices=[];
    if(['BUY','BUY_OR_RENT'].includes(op)) prices.push(['SALE',body.currencyCode||'YER',num(body.salePrice,'INVALID_SALE_PRICE'),body.billingUnit||'UNIT',null]);
    if(['RENT','BUY_OR_RENT'].includes(op)) prices.push(['RENTAL',body.currencyCode||'YER',num(body.rentalPrice,'INVALID_RENTAL_PRICE'),body.billingUnit||'DAY',body.minimumDuration??1]);
    if(['RENT','BUY_OR_RENT'].includes(op)) prices.push(['INSURANCE',body.currencyCode||'YER',num(body.insurancePrice,'INVALID_INSURANCE_PRICE'),'PER_BOOKING',null]);
    for(const [type,currency,amount,billing,minDur] of prices) await c.query(`INSERT INTO hala.listing_prices(listing_id,price_type,currency_code,amount,billing_unit,minimum_duration,duration_unit,enabled,version) VALUES($1,$2,$3,$4,$5,$6,$7,true,1)`,[l.id,type,currency,amount,billing,minDur, op.includes('RENT')?'DAY':null]);
    await c.query(`INSERT INTO hala.universal_listing_versions(listing_id,version,snapshot,change_reason,actor_user_id,request_id) VALUES($1,1,$2::jsonb,'listing.created',$3,$4)`,[l.id,JSON.stringify({...l,operationType:op,salePrice:body.salePrice??null,rentalPrice:body.rentalPrice??null,insurancePrice:body.insurancePrice??null}),actorUserId,ctx.requestId||null]);
    for(const asset of (Array.isArray(body.assets)?body.assets:[])){ if(!asset.storageKey) throw fail('ASSET_STORAGE_KEY_REQUIRED'); const sk=String(asset.storageKey); if(sk.includes('..')||sk.startsWith('/')||sk.includes('\\')) throw fail('INVALID_ASSET_STORAGE_KEY'); await c.query(`INSERT INTO hala.listing_assets(listing_id,asset_type,storage_key,mime_type,file_size_bytes,content_hash,language_code,title,metadata,moderation_status) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,'PENDING')`,[l.id,String(asset.assetType||'IMAGE').toUpperCase(),String(asset.storageKey),asset.mimeType||null,asset.fileSizeBytes??null,asset.contentHash||null,asset.languageCode||'ar',asset.title||null,JSON.stringify(asset.metadata||{})]); }
    await c.query('INSERT INTO hala.universal_listing_history(listing_id,old_status,new_status,reason,actor_user_id,request_id) VALUES($1,NULL,\'AI_REVIEW\',\'provider.submitted\',$2,$3)',[l.id,actorUserId,ctx.requestId||null]);
    await superviseInTransaction(c,{eventKey:'listing.created',marketId:body.marketId,resourceType:'universal_listing',resourceId:l.id,actorId:actorUserId,payload:{content:[title,body.shortDescription||'',body.longDescription||'',JSON.stringify(body.attributes||{})].join(' '),amount:body.salePrice||body.rentalPrice||0}});
    if(ctx.idempotencyKey) await c.query('INSERT INTO hala.idempotency_records(actor_user_id,idempotency_key,route,request_hash,response_status,response_body) VALUES($1,$2,$3,$4,201,$5::jsonb)',[actorUserId,ctx.idempotencyKey,IDEM_ROUTE_LISTING,'not-computed',JSON.stringify(l)]);
    await c.query('COMMIT'); return l;
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}


export async function listMarketListings(marketKey, filters={}){
  const key=String(marketKey||'').trim().toLowerCase(); if(!/^[a-z0-9][a-z0-9_-]{1,119}$/.test(key)) throw fail('INVALID_MARKET_KEY');
  const db=await getDb();
  const limit=Math.min(100,Math.max(1,Number(filters.limit||60)));
  const params=[key,limit];
  const r=await db.query(`SELECT ul.id,ul.market_id,ul.section_id,ul.category_id,ul.title,ul.short_description,ul.listing_kind,
    ul.quantity,ul.unit_code,ul.base_currency,ul.base_price,ul.attributes,ul.created_at,
    m.market_key,m.name_ar AS market_name,
    ms.name_ar AS section_name,
    COALESCE((SELECT AVG(cf.rating) FROM hala.customer_feedback cf WHERE cf.offer_id=ul.offer_id),0) AS rating,
    COALESCE((SELECT lp.amount FROM hala.listing_prices lp WHERE lp.listing_id=ul.id AND lp.enabled=true AND lp.price_type='RENTAL' ORDER BY lp.amount LIMIT 1),0) AS rental_price,
    COALESCE((SELECT lp.amount FROM hala.listing_prices lp WHERE lp.listing_id=ul.id AND lp.enabled=true AND lp.price_type='SALE' ORDER BY lp.amount LIMIT 1),0) AS sale_price,
    COALESCE((SELECT lp.amount FROM hala.listing_prices lp WHERE lp.listing_id=ul.id AND lp.enabled=true AND lp.price_type='INSURANCE' ORDER BY lp.amount LIMIT 1),0) AS insurance_price,
    COALESCE((SELECT json_agg(json_build_object('assetType',la.asset_type,'storageKey',la.storage_key,'mimeType',la.mime_type,'title',la.title) ORDER BY la.created_at) FROM hala.listing_assets la WHERE la.listing_id=ul.id AND la.moderation_status IN ('APPROVED','PUBLISHED')), '[]'::json) AS assets
    FROM hala.universal_listings ul JOIN hala.markets m ON m.id=ul.market_id
    LEFT JOIN hala.market_sections ms ON ms.id=ul.section_id
    WHERE m.market_key=$1 AND m.status='ACTIVE' AND m.is_deleted=false AND ul.listing_status='PUBLISHED'
    ORDER BY ul.created_at DESC LIMIT $2`,params);
  return r.rows;
}

export async function createDemand(customerId, body, ctx={}){
  uuid(customerId,'CUSTOMER_REQUIRED');if(!body||typeof body!=='object')throw fail('INVALID_DEMAND_PAYLOAD');uuid(body.marketId,'MARKET_REQUIRED');const op=String(body.operationType||'').toUpperCase();if(!OPS.has(op))throw fail('INVALID_OPERATION_TYPE');const title=String(body.title||'').trim();if(!title)throw fail('DEMAND_TITLE_REQUIRED');
  const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');if(ctx.idempotencyKey){const old=await c.query('SELECT response_body FROM hala.idempotency_records WHERE actor_user_id=$1 AND idempotency_key=$2 AND route=$3',[customerId,ctx.idempotencyKey,IDEM_ROUTE_DEMAND]);if(old.rowCount){await c.query('COMMIT');return old.rows[0].response_body;}}const m=await c.query("SELECT id FROM hala.markets WHERE id=$1 AND status='ACTIVE' AND is_deleted=false",[body.marketId]);if(!m.rowCount)throw fail('MARKET_NOT_ACTIVE',409);
    const r=await c.query(`INSERT INTO hala.demand_requests(customer_id,market_id,section_id,category_id,operation_type,title,description,requested_attributes,quantity,unit_code,budget_min,budget_max,currency_code,needed_from,needed_to,location_id,location_requirements,status,visibility,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11,$12,$13,$14,$15,$16,$17,'OPEN',$18,$19) RETURNING *`,[customerId,body.marketId,body.sectionId||null,body.categoryId||null,op,title,body.description||null,JSON.stringify(body.requestedAttributes||{}),body.quantity??null,body.unitCode||null,body.budgetMin??null,body.budgetMax??null,body.currencyCode||'YER',body.neededFrom||null,body.neededTo||null,body.locationId||null,JSON.stringify(body.locationRequirements||{}),body.visibility||'MATCHED_PROVIDERS',body.expiresAt||null]);await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}

export async function matchDemand(actorUserId,demandId){
  uuid(actorUserId,'ACTOR_REQUIRED');
  uuid(demandId,'INVALID_DEMAND_ID');const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');const d=await c.query(`SELECT d.*, EXISTS(SELECT 1 FROM hala.user_roles ur JOIN hala.roles rr ON rr.id=ur.role_id WHERE ur.user_id=$2 AND lower(rr.name) IN ('admin','super_admin','administrator','agent')) AS is_privileged FROM hala.demand_requests d WHERE d.id=$1 FOR UPDATE`,[demandId,actorUserId]);
    if(!d.rowCount) throw fail('DEMAND_NOT_FOUND',404);
    if(d.rows[0].customer_id!==actorUserId && !d.rows[0].is_privileged) throw fail('FORBIDDEN_DEMAND_MATCH',403);if(!d.rowCount)throw fail('DEMAND_NOT_FOUND',404);const x=d.rows[0];if(['CANCELLED','EXPIRED','FULFILLED'].includes(x.status))throw fail('DEMAND_NOT_MATCHABLE',409);
    const listings=await c.query(`SELECT ul.id,ul.market_id,ul.section_id,ul.category_id,ul.title,ul.short_description,ul.provider_id,ul.listing_kind,ul.listing_status,ul.attributes,ul.specifications,ul.quantity FROM hala.universal_listings ul JOIN hala.market_provider_memberships mm ON mm.market_id=ul.market_id AND mm.provider_id=ul.provider_id AND mm.status='ACTIVE' WHERE ul.market_id=$1 AND ul.listing_status='PUBLISHED' AND mm.status='ACTIVE' AND (ul.category_id IS NOT DISTINCT FROM $2 OR $2 IS NULL) AND ul.listing_kind IN ('SALE','RENTAL','SALE_RENTAL','SERVICE')`,[x.market_id,x.category_id]);
    const rows=[];for(const l of listings.rows){let score=0,factors={market:true};const compatible= x.operation_type==='BUY'?['SALE','SALE_RENTAL'].includes(l.listing_kind):x.operation_type==='RENT'?['RENTAL','SALE_RENTAL'].includes(l.listing_kind):x.operation_type==='BUY_OR_RENT'?['SALE','RENTAL','SALE_RENTAL'].includes(l.listing_kind):true;if(!compatible)continue;score+=0.4;factors.operation=true;if(x.requested_attributes&&Object.keys(x.requested_attributes).length){const subset=await c.query('SELECT $1::jsonb <@ $2::jsonb AS ok',[JSON.stringify(x.requested_attributes),JSON.stringify(l.attributes||{})]);if(subset.rows[0].ok){score+=0.35;factors.attributes=true}else factors.attributes=false;}else score+=0.15;if(x.budget_max!=null){const p=await c.query(`SELECT min(amount) amount FROM hala.listing_prices WHERE listing_id=$1 AND enabled=true AND price_type IN ('SALE','RENTAL')`,[l.id]);if(p.rows[0].amount!=null && Number(p.rows[0].amount)<=Number(x.budget_max)){score+=0.15;factors.budget=true}else factors.budget=false;}else score+=0.1;rows.push({listing:l,score,factors});}
    for(const m of rows){await c.query(`INSERT INTO hala.supply_demand_matches(demand_request_id,listing_id,match_method,score,matched_factors,status) VALUES($1,$2,'RULES',$3,$4::jsonb,'PROPOSED') ON CONFLICT(demand_request_id,listing_id) DO UPDATE SET score=EXCLUDED.score,matched_factors=EXCLUDED.matched_factors,status='PROPOSED'`,[demandId,m.listing.id,m.score,JSON.stringify(m.factors)]);}
    await c.query("UPDATE hala.demand_requests SET status=CASE WHEN $2::int>0 THEN 'OFFERED' ELSE 'MATCHING' END,updated_at=now() WHERE id=$1",[demandId,rows.length]);
    await c.query(`INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,after_data,request_id,result,metadata) VALUES($1,'DEMAND_MATCHED','demand_request',$2,$3::jsonb,NULL,'SUCCESS',$4::jsonb)`,[x.customer_id,demandId,JSON.stringify({matchCount:rows.length}),JSON.stringify({matchCount:rows.length})]);
    await c.query('COMMIT');return rows.sort((a,b)=>b.score-a.score).slice(0,50);
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}

export async function getDemandMatches(customerId,demandId){uuid(customerId,'CUSTOMER_REQUIRED');uuid(demandId,'INVALID_DEMAND_ID');const db=await getDb();const r=await db.query(`SELECT sdm.*,ul.title,ul.short_description,ul.listing_kind FROM hala.supply_demand_matches sdm JOIN hala.demand_requests d ON d.id=sdm.demand_request_id JOIN hala.universal_listings ul ON ul.id=sdm.listing_id WHERE sdm.demand_request_id=$1 AND d.customer_id=$2 ORDER BY sdm.score DESC,sdm.created_at DESC`,[demandId,customerId]);return r.rows;}
