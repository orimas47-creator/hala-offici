import { getDb } from '../../common/db.mjs';
import { emitPlatformEvent } from '../ai/telemetry.mjs';
import { assertTransition } from '../../common/state-machine.mjs';
import { reserveBookingInventory, activateBookingInventory, releaseBookingInventory } from '../availability/service.mjs';

export async function getBooking(actor,id){
  if(!actor) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401});
  const db=await getDb();
  const r=await db.query(`
    SELECT b.*
    FROM hala.bookings b
    LEFT JOIN LATERAL (
      SELECT COALESCE(p1.user_id,p2.user_id) AS provider_user_id
      FROM hala.booking_wishes bw
      LEFT JOIN hala.service_offers so ON so.id=bw.offer_id
      LEFT JOIN hala.universal_listings ul ON ul.id=bw.listing_id
      LEFT JOIN hala.providers p1 ON p1.id=so.provider_id
      LEFT JOIN hala.providers p2 ON p2.id=ul.provider_id
      WHERE bw.booking_id=b.id
      ORDER BY bw.wish_rank LIMIT 1
    ) pr ON true
    WHERE b.id=$1
      AND (b.customer_id=$2 OR pr.provider_user_id=$2 OR EXISTS(
        SELECT 1 FROM hala.user_roles ur
        JOIN hala.roles rr ON rr.id=ur.role_id
        WHERE ur.user_id=$2 AND lower(rr.name) IN ('admin','finance','agent')
      ))`,[id,actor]);
  if(!r.rowCount) throw Object.assign(new Error('BOOKING_NOT_FOUND'),{status:404});
  return r.rows[0];
}
export async function createBooking(actor, body, ctx){
  if(!actor) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401});
  if(!body || !Array.isArray(body.wishes) || !body.wishes.length) throw Object.assign(new Error('INVALID_BOOKING_PAYLOAD'),{status:400});
  if(body.wishes.length>3) throw Object.assign(new Error('MAX_THREE_WISHES'),{status:400});
  const universalMode=!!body.listingId;
  if(!universalMode && !body.serviceId) throw Object.assign(new Error('SERVICE_OR_LISTING_REQUIRED'),{status:400});
  if(universalMode && body.serviceId) throw Object.assign(new Error('AMBIGUOUS_BOOKING_SOURCE'),{status:400});
  const db=await getDb(); const client=await db.connect();
  try{
    await client.query('BEGIN');
    const existing=ctx.idempotencyKey ? await client.query('SELECT response_body FROM hala.idempotency_records WHERE actor_user_id=$1 AND idempotency_key=$2 AND route=$3',[actor,ctx.idempotencyKey,'POST /api/v1/bookings']) : {rowCount:0};
    if(existing.rowCount){await client.query('COMMIT');return existing.rows[0].response_body;}
    const start=new Date(body.eventStart), end=new Date(body.eventEnd);
    if(!Number.isFinite(start.getTime())||!Number.isFinite(end.getTime())||end<=start) throw Object.assign(new Error('INVALID_BOOKING_DATES'),{status:400});
    const quantity=Number(body.quantity||1); if(!(quantity>0&&quantity<=100000)) throw Object.assign(new Error('INVALID_BOOKING_QUANTITY'),{status:400});
    const ranks=body.wishes.map(w=>Number(w.rank)); if(new Set(ranks).size!==body.wishes.length || ranks.some(r=>![1,2,3].includes(r))) throw Object.assign(new Error('INVALID_WISH'),{status:400});
    if(!body.wishes.some(w=>Number(w.rank)===1)) throw Object.assign(new Error('PRIMARY_WISH_REQUIRED'),{status:400});
    let bookingPayload;
    let sourceMarketId=null; let sourceServiceId=null; let operation=''; let total=0; let subtotal=0; let insurance=0; let currency='YER';
    if(universalMode){
      const listingId=String(body.listingId);
      const primary=body.wishes.find(w=>Number(w.rank)===1);
      if(String(primary.listingId||'')!==listingId) throw Object.assign(new Error('PRIMARY_WISH_MISMATCH'),{status:400});
      const wishListingIds=body.wishes.map(w=>String(w.listingId||'')); if(new Set(wishListingIds).size!==wishListingIds.length) throw Object.assign(new Error('DUPLICATE_WISH_LISTING'),{status:400});
      operation=String(body.operationType||'').toUpperCase(); if(!['BUY','RENT'].includes(operation)) throw Object.assign(new Error('UNSUPPORTED_BOOKING_OPERATION'),{status:400});
      const lr=await client.query(`SELECT ul.*,m.status market_status,m.is_deleted,m.id market_id,p.status provider_status,p.user_id provider_user_id
        FROM hala.universal_listings ul JOIN hala.markets m ON m.id=ul.market_id JOIN hala.providers p ON p.id=ul.provider_id
        JOIN hala.market_provider_memberships mm ON mm.market_id=ul.market_id AND mm.provider_id=ul.provider_id AND mm.status='ACTIVE'
        WHERE ul.id=$1 AND ul.listing_status='PUBLISHED' AND m.status='ACTIVE' AND m.is_deleted=false AND p.status='active'
        AND p.insurance_confirmed=true AND p.subscription_expires_at>now() FOR SHARE`,[listingId]);
      if(!lr.rowCount) throw Object.assign(new Error('LISTING_NOT_BOOKABLE'),{status:409});
      const l=lr.rows[0]; sourceMarketId=l.market_id; currency=l.base_currency||'YER';
      const compatible=operation==='BUY'?['SALE','SALE_RENTAL'].includes(l.listing_kind):['RENTAL','SALE_RENTAL'].includes(l.listing_kind);
      if(!compatible) throw Object.assign(new Error('OPERATION_NOT_SUPPORTED_BY_LISTING'),{status:409});
      const opCfg=await client.query(`SELECT 1 FROM hala.market_operation_configs WHERE market_id=$1 AND operation_code=$2 AND enabled=true ORDER BY version DESC LIMIT 1`,[sourceMarketId,operation]);
      if(!opCfg.rowCount) throw Object.assign(new Error('OPERATION_NOT_ENABLED'),{status:409});
      const prices=await client.query(`SELECT price_type,amount,currency_code,billing_unit,minimum_quantity,maximum_quantity,minimum_duration,duration_unit
        FROM hala.listing_prices WHERE listing_id=$1 AND enabled=true AND (valid_from IS NULL OR valid_from<=now()) AND (valid_to IS NULL OR valid_to>=now())`,[listingId]);
      const pick=(type)=>prices.rows.find(x=>x.price_type===type);
      const sale=pick('SALE'), rental=pick('RENTAL'), ins=pick('INSURANCE');
      if(operation==='BUY' && !(sale?.amount>0)) throw Object.assign(new Error('SALE_PRICE_REQUIRED'),{status:409});
      if(operation==='RENT' && !(rental?.amount>0)) throw Object.assign(new Error('RENTAL_PRICE_REQUIRED'),{status:409});
      if(operation==='RENT' && !(ins?.amount>=0)) throw Object.assign(new Error('RENTAL_INSURANCE_REQUIRED'),{status:409});
      const minQ=(sale?.minimum_quantity??rental?.minimum_quantity); const maxQ=(sale?.maximum_quantity??rental?.maximum_quantity); if(minQ!=null&&quantity<Number(minQ))throw Object.assign(new Error('MINIMUM_QUANTITY_NOT_MET'),{status:409}); if(maxQ!=null&&quantity>Number(maxQ))throw Object.assign(new Error('MAXIMUM_QUANTITY_EXCEEDED'),{status:409});
      const days=Math.max(1,Math.ceil((end-start)/86400000));
      if(operation==='BUY'){subtotal=Number(sale.amount)*quantity;}
      else { if(rental.minimum_duration!=null && days<Number(rental.minimum_duration)) throw Object.assign(new Error('MINIMUM_RENTAL_DURATION_NOT_MET'),{status:409}); subtotal=Number(rental.amount)*quantity*days; insurance=Number(ins?.amount||0)*quantity; }
      total=subtotal+insurance;
      sourceServiceId=null;
      bookingPayload={source:'universal',listingId,marketId:sourceMarketId,operation};
      for(const w of body.wishes){ const lid=String(w.listingId||''); if(!lid)throw Object.assign(new Error('UNIVERSAL_WISH_LISTING_REQUIRED'),{status:400}); const wr=await client.query(`SELECT ul.id FROM hala.universal_listings ul JOIN hala.market_provider_memberships mm ON mm.market_id=ul.market_id AND mm.provider_id=ul.provider_id AND mm.status='ACTIVE' JOIN hala.providers p ON p.id=ul.provider_id WHERE ul.id=$1 AND ul.market_id=$2 AND ul.listing_status='PUBLISHED' AND p.status='active'`,[lid,sourceMarketId]); if(!wr.rowCount)throw Object.assign(new Error('WISH_LISTING_NOT_BOOKABLE'),{status:409}); }
    } else {
      const primary=body.wishes.find(w=>Number(w.rank)===1); const offer=await client.query(`SELECT so.*,p.status provider_status,p.id provider_id,s.market_id FROM hala.service_offers so JOIN hala.providers p ON p.id=so.provider_id JOIN hala.services s ON s.id=so.service_id WHERE so.id=$1 AND so.service_id=$2 AND so.status IN ('approved','published') AND p.status='active' FOR SHARE`,[primary.offerId,body.serviceId]); if(!offer.rowCount) throw Object.assign(new Error('PRIMARY_OFFER_NOT_BOOKABLE'),{status:409});
      operation=String(body.operationType||'RENT').toUpperCase(); if(!['BUY','RENT'].includes(operation)) throw Object.assign(new Error('UNSUPPORTED_BOOKING_OPERATION'),{status:400}); const lt=offer.rows[0].listing_type;if((operation==='BUY'&&lt!=='sale')||(operation==='RENT'&&lt!=='rental'))throw Object.assign(new Error('OPERATION_NOT_SUPPORTED_BY_OFFER'),{status:409});
      sourceMarketId=offer.rows[0].market_id; sourceServiceId=body.serviceId; const membership=await client.query(`SELECT 1 FROM hala.market_provider_memberships mm WHERE mm.market_id=$1 AND mm.provider_id=$2 AND mm.status='ACTIVE'`,[sourceMarketId,offer.rows[0].provider_id]);if(!membership.rowCount)throw Object.assign(new Error('PROVIDER_NOT_ACTIVE_IN_MARKET'),{status:409});
      for(const w of body.wishes){const rank=Number(w.rank);if(!w.offerId)throw Object.assign(new Error('LEGACY_WISH_OFFER_REQUIRED'),{status:400});const ow=await client.query(`SELECT so.id FROM hala.service_offers so JOIN hala.providers p ON p.id=so.provider_id WHERE so.id=$1 AND so.service_id=$2 AND so.status IN ('approved','published') AND p.status='active'`,[w.offerId,body.serviceId]);if(!ow.rowCount)throw Object.assign(new Error('WISH_OFFER_NOT_BOOKABLE'),{status:409});}
      const days=Math.max(1,Math.ceil((end-start)/86400000)); const unitPrice=operation==='BUY'?Number(offer.rows[0].sale_price):Number(offer.rows[0].rental_price);if(!(unitPrice>0))throw Object.assign(new Error('OFFER_PRICE_UNAVAILABLE'),{status:409});if(operation==='RENT'&&!(Number(offer.rows[0].insurance_price)>0))throw Object.assign(new Error('RENTAL_INSURANCE_REQUIRED'),{status:409});subtotal=operation==='BUY'?unitPrice*quantity:unitPrice*quantity*days;insurance=operation==='RENT'?Number(offer.rows[0].insurance_price||0)*quantity:0;total=subtotal+insurance;
      bookingPayload={source:'legacy',serviceId:body.serviceId,operation};
    }
    const b=await client.query(`INSERT INTO hala.bookings(customer_id,service_id,market_id,universal_listing_id,operation_type,status,event_start,event_end,quantity,subtotal,insurance_amount,extras_amount,total_amount,currency_code,notes,request_id,idempotency_key,lifecycle_status)
      VALUES($1,$2,$3,$4,$5,'draft',$6,$7,$8,$9,$10,0,$11,$12,$13,$14,$15,'DRAFT') RETURNING *`,[actor,sourceServiceId,sourceMarketId,universalMode?body.listingId:null,operation,body.eventStart,body.eventEnd,quantity,subtotal,insurance,total,currency,body.notes||null,ctx.requestId||null,ctx.idempotencyKey||null]);
    for(const w of body.wishes){const rank=Number(w.rank);await client.query(`INSERT INTO hala.booking_wishes(booking_id,wish_rank,offer_id,listing_id,unit_id,status,deposit_required) VALUES($1,$2,$3,$4,$5,$6,$7)`,[b.rows[0].id,rank,universalMode?null:w.offerId,universalMode?w.listingId:null,w.unitId||null,rank===1?'pending':'available',Number(w.depositRequired||0)]);}
    await client.query("INSERT INTO hala.escrow_accounts(booking_id,held_amount,status) VALUES($1,0,'holding') ON CONFLICT(booking_id) DO NOTHING",[b.rows[0].id]);
    await client.query('INSERT INTO hala.booking_lifecycle_history(booking_id,to_status,actor_user_id,request_id,reason) VALUES($1,$2,$3,$4,$5)',[b.rows[0].id,'DRAFT',actor,ctx.requestId||null,'booking.created']);
    const out=b.rows[0]; if(ctx.idempotencyKey) await client.query('INSERT INTO hala.idempotency_records(actor_user_id,idempotency_key,route,request_hash,response_status,response_body) VALUES($1,$2,$3,$4,$5,$6)',[actor,ctx.idempotencyKey,'POST /api/v1/bookings','not-computed',201,JSON.stringify(out)]);
    await client.query('COMMIT'); await emitPlatformEvent({eventKey:'booking.created',marketId:sourceMarketId,resourceType:'booking',resourceId:out.id,actorId:actor,payload:{status:'DRAFT',serviceId:sourceServiceId,listingId:universalMode?body.listingId:null,totalAmount:total}}); return out;
  }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
}
export async function transitionBooking(actor,id,to,reason,ctx){
  if(!actor) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401});
  const db=await getDb(); const client=await db.connect();
  try { await client.query('BEGIN');
    const q=await client.query(`SELECT b.*,p.user_id AS provider_user_id
      FROM hala.bookings b
      LEFT JOIN hala.service_offers so ON so.id=(SELECT bw.offer_id FROM hala.booking_wishes bw WHERE bw.booking_id=b.id ORDER BY bw.wish_rank LIMIT 1)
      LEFT JOIN hala.universal_listings ul ON ul.id=(SELECT bw.listing_id FROM hala.booking_wishes bw WHERE bw.booking_id=b.id ORDER BY bw.wish_rank LIMIT 1)
      LEFT JOIN hala.providers p ON p.id=COALESCE(so.provider_id,ul.provider_id)
      WHERE b.id=$1
        AND (b.customer_id=$2 OR p.user_id=$2 OR EXISTS(SELECT 1 FROM hala.user_roles ur JOIN hala.roles rr ON rr.id=ur.role_id WHERE ur.user_id=$2 AND lower(rr.name) IN ('admin','finance','agent')))
      FOR UPDATE`,[id,actor]);
    if(!q.rowCount) throw Object.assign(new Error('BOOKING_NOT_FOUND'),{status:404});
    const row=q.rows[0]; const from=row.lifecycle_status;
    assertTransition(from,to);
    if(to==='PAYMENT_PENDING') await reserveBookingInventory(client,id,{booking:row});
    if(to==='PROVIDER_PENDING' || to==='CONFIRMED' || to==='IN_PROGRESS' || to==='RETURN_PENDING' || to==='INSPECTION') await activateBookingInventory(client,id);
    if(['CANCELLED','FAILED','COMPLETED'].includes(to)) await releaseBookingInventory(client,id,to);
    await client.query('UPDATE hala.bookings SET lifecycle_status=$2, lifecycle_version=lifecycle_version+1, updated_at=now() WHERE id=$1',[id,to]);
    await client.query('INSERT INTO hala.booking_lifecycle_history(booking_id,from_status,to_status,actor_user_id,request_id,reason) VALUES($1,$2,$3,$4,$5,$6)',[id,from,to,actor,ctx.requestId,reason||null]);
    await client.query('INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,before_data,after_data,request_id,result) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',[actor,'BOOKING_STATUS_CHANGE','booking',id,JSON.stringify({lifecycle_status:from}),JSON.stringify({lifecycle_status:to}),ctx.requestId,'SUCCESS']);
    await client.query('COMMIT'); await emitPlatformEvent({eventKey:'booking.transitioned',resourceType:'booking',resourceId:id,actorId:actor,payload:{fromStatus:from,toStatus:to,reason:reason||null}}); return {...row,lifecycle_status:to};
  } catch(e){ await client.query('ROLLBACK'); throw e; } finally{client.release();}
}
