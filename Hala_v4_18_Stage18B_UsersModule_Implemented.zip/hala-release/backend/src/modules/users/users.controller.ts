import { Controller, Get, Param, Patch, Body, UseGuards } from '@nestjs/common';
import { ActorContext } from '../../common/decorators/actor.decorator.js';
import { HalaAuthGuard, RequireActorGuard } from '../../common/guards/hala-auth.guard.js';
import type { AuthRequestContext } from '../auth/auth.types.js';
import { UpdateUserDto } from './dto/update-user.dto.js';
import { UsersService } from './users.service.js';

@Controller('api/v1/users')
@UseGuards(HalaAuthGuard, RequireActorGuard)
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get(':id')
  getUser(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.users.getUser(ctx.actorId, id);
  }

  @Patch(':id')
  updateUser(
    @Param('id') id: string,
    @Body() dto: UpdateUserDto,
    @ActorContext() ctx: AuthRequestContext,
  ) {
    return this.users.updateUser(ctx.actorId, id, dto.fullName);
  }
}
