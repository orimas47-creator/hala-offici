import { BadRequestException, ForbiddenException, Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { DataSource } from 'typeorm';

export interface UserProfile {
  id: string;
  phone: string;
  full_name: string | null;
  account_type: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  roles: Array<{ id: string; name: string }>;
}

@Injectable()
export class UsersService {
  constructor(private readonly dataSource: DataSource) {}

  private async isAdmin(userId: string): Promise<boolean> {
    const rows = await this.dataSource.query(
      `SELECT 1
         FROM hala.user_roles ur
         JOIN hala.roles r ON r.id=ur.role_id
        WHERE ur.user_id=$1
          AND lower(r.name)=ANY($2::text[])
        LIMIT 1`,
      [userId, ['admin', 'super_admin', 'administrator']],
    );
    return rows.length > 0;
  }

  private requireActor(actorId: string | null): asserts actorId is string {
    if (!actorId) throw new UnauthorizedException('ACTOR_REQUIRED');
  }

  async getUser(actorId: string | null, userId: string): Promise<UserProfile> {
    this.requireActor(actorId);
    if (!userId) throw new NotFoundException('USER_NOT_FOUND');

    const rows = await this.dataSource.query(
      `SELECT u.id,u.phone,u.full_name,u.account_type,u.is_active,u.created_at,u.updated_at,
          COALESCE(
            json_agg(DISTINCT jsonb_build_object('id',r.id,'name',r.name))
            FILTER (WHERE r.id IS NOT NULL),'[]'::json
          ) AS roles
       FROM hala.users u
       LEFT JOIN hala.user_roles ur ON ur.user_id=u.id
       LEFT JOIN hala.roles r ON r.id=ur.role_id
       WHERE u.id=$1
       GROUP BY u.id`,
      [userId],
    );

    if (rows.length === 0) throw new NotFoundException('USER_NOT_FOUND');
    if (actorId !== userId && !(await this.isAdmin(actorId))) {
      throw new ForbiddenException('FORBIDDEN');
    }
    return rows[0] as UserProfile;
  }

  async updateUser(actorId: string | null, userId: string, fullName: string): Promise<Omit<UserProfile, 'roles'>> {
    this.requireActor(actorId);
    if (actorId !== userId && !(await this.isAdmin(actorId))) {
      throw new ForbiddenException('FORBIDDEN');
    }

    const name = String(fullName ?? '').trim();
    if (name.length < 2 || name.length > 200) {
      throw new BadRequestException('INVALID_FULL_NAME');
    }

    const rows = await this.dataSource.query(
      `UPDATE hala.users
          SET full_name=$2, updated_at=now()
        WHERE id=$1
        RETURNING id,phone,full_name,account_type,is_active,created_at,updated_at`,
      [userId, name],
    );
    if (rows.length === 0) throw new NotFoundException('USER_NOT_FOUND');
    return rows[0];
  }
}
