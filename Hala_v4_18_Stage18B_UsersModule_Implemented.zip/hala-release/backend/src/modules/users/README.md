# UsersModule — Stage 18B

NestJS implementation of the existing v4.17 user profile endpoints.

Routes:
- `GET /api/v1/users/:id`
- `PATCH /api/v1/users/:id`

Rules:
- Authentication is mandatory.
- A user may read/update only their own profile.
- Admin roles may access another user's profile.
- Role assignment, activation, phone changes, and credential changes are not exposed by this module.
- Database truth remains PostgreSQL; no in-memory user state is used.
