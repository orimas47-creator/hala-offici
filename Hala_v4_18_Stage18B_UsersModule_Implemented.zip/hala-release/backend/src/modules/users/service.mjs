import { getDb } from '../../common/db.mjs';
const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});
export async function getUser(actorId,userId=actorId){
  if(!actorId) throw fail('ACTOR_REQUIRED',401); if(!userId) throw fail('USER_REQUIRED');
  const db=await getDb();
  const r=await db.query(`SELECT u.id,u.phone,u.full_name,u.account_type,u.is_active,u.created_at,u.updated_at,
    COALESCE(json_agg(DISTINCT jsonb_build_object('id',r.id,'name',r.name)) FILTER (WHERE r.id IS NOT NULL),'[]'::json) roles
    FROM hala.users u LEFT JOIN hala.user_roles ur ON ur.user_id=u.id LEFT JOIN hala.roles r ON r.id=ur.role_id
    WHERE u.id=$1 GROUP BY u.id`,[userId]);
  if(!r.rowCount) throw fail('USER_NOT_FOUND',404);
  const isSelf=actorId===userId; const admin=await db.query(`SELECT 1 FROM hala.user_roles ur JOIN hala.roles r ON r.id=ur.role_id WHERE ur.user_id=$1 AND lower(r.name) IN ('admin','super_admin','administrator')`,[actorId]);
  if(!isSelf && !admin.rowCount) throw fail('FORBIDDEN',403);
  return r.rows[0];
}
export async function updateUser(actorId,userId,body){
  if(!actorId) throw fail('ACTOR_REQUIRED',401); const db=await getDb();
  const admin=await db.query(`SELECT 1 FROM hala.user_roles ur JOIN hala.roles r ON r.id=ur.role_id WHERE ur.user_id=$1 AND lower(r.name) IN ('admin','super_admin','administrator')`,[actorId]);
  if(actorId!==userId && !admin.rowCount) throw fail('FORBIDDEN',403);
  const fullName=body?.fullName==null?null:String(body.fullName).trim();
  if(fullName!==null && (fullName.length<2||fullName.length>200)) throw fail('INVALID_FULL_NAME');
  const r=await db.query(`UPDATE hala.users SET full_name=COALESCE($2,full_name),updated_at=now() WHERE id=$1 RETURNING id,phone,full_name,account_type,is_active,created_at,updated_at`,[userId,fullName]);
  if(!r.rowCount) throw fail('USER_NOT_FOUND',404); return r.rows[0];
}
