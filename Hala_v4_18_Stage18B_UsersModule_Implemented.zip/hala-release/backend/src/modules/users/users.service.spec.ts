import { BadRequestException, ForbiddenException, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { UsersService } from './users.service.js';

describe('UsersService', () => {
  const query = jest.fn();
  const service = new UsersService({ query } as any);

  beforeEach(() => query.mockReset());

  it('rejects missing actor', async () => {
    await expect(service.getUser(null, 'u1')).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('rejects unknown user', async () => {
    query.mockResolvedValueOnce([]);
    await expect(service.getUser('u1', 'u2')).rejects.toBeInstanceOf(NotFoundException);
  });

  it('allows self lookup without admin query', async () => {
    query.mockResolvedValueOnce([{ id: 'u1', phone: '+967771234567', roles: [] }]);
    await expect(service.getUser('u1', 'u1')).resolves.toEqual({ id: 'u1', phone: '+967771234567', roles: [] });
    expect(query).toHaveBeenCalledTimes(1);
  });

  it('rejects invalid name before writing', async () => {
    await expect(service.updateUser('u1', 'u1', 'x')).rejects.toBeInstanceOf(BadRequestException);
    expect(query).not.toHaveBeenCalled();
  });

  it('rejects cross-user lookup when actor is not admin', async () => {
    query.mockResolvedValueOnce([{ id: 'u2', phone: '+967771234567', roles: [] }]);
    query.mockResolvedValueOnce([]);
    await expect(service.getUser('u1', 'u2')).rejects.toBeInstanceOf(ForbiddenException);
  });
});
