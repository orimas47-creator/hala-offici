import { getDb } from '../../common/db.mjs';

const OPS = new Set(['BUY','RENT','BUY_OR_RENT','SERVICE','QUOTE']);
const STATUS = new Set(['DRAFT','ACTIVE','PAUSED','ARCHIVED']);
const idRx = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const fail = (code, status=400) => Object.assign(new Error(code), {status, code});
const json = (v) => v ?? {};
function requiredString(v, code){ if(typeof v !== 'string' || !v.trim()) throw fail(code); return v.trim(); }
function uuid(v, code='INVALID_UUID'){ if(!idRx.test(String(v||''))) throw fail(code); return v; }

async function requireManager(client, actorId){
  uuid(actorId,'ACTOR_REQUIRED');
  const r = await client.query(`
    SELECT 1
    FROM hala.users u
    WHERE u.id=$1 AND u.is_active=true
      AND (
        EXISTS (
          SELECT 1 FROM hala.user_roles ur
          JOIN hala.roles r ON r.id=ur.role_id
          WHERE ur.user_id=u.id AND lower(r.name) IN ('admin','super_admin','administrator')
        )
        OR EXISTS (
          SELECT 1 FROM hala.user_roles ur
          JOIN hala.role_permissions rp ON rp.role_id=ur.role_id
          JOIN hala.permissions p ON p.id=rp.permission_id
          WHERE ur.user_id=u.id AND p.code='market.builder.manage'
        )
      )`, [actorId]);
  if(!r.rowCount) throw fail('FORBIDDEN_MARKET_BUILDER',403);
}

async function audit(client, {marketId, actorId, objectType, objectId, action, requestId, before, after}){
  await client.query(`INSERT INTO hala.market_change_log
    (market_id,actor_user_id,object_type,object_id,action,request_id,before_json,after_json)
    VALUES($1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb)`,
    [marketId||null,actorId,objectType,objectId||null,action,requestId||null,before?JSON.stringify(before):null,after?JSON.stringify(after):null]);
  await client.query(`INSERT INTO hala.audit_logs
    (actor_user_id,action,entity_type,entity_id,before_data,after_data,request_id,result,metadata)
    VALUES($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7,'SUCCESS',$8::jsonb)`,
    [actorId,`MARKET_${action}`,objectType,objectId||null,before?JSON.stringify(before):null,after?JSON.stringify(after):null,requestId||null,JSON.stringify({marketId})]);
}

function normalizeMarket(body){
  const marketKey = requiredString(body.marketKey,'MARKET_KEY_REQUIRED').toLowerCase().replace(/\s+/g,'-');
  if(!/^[a-z0-9][a-z0-9_-]{1,119}$/.test(marketKey)) throw fail('INVALID_MARKET_KEY');
  return {
    marketKey,
    nameAr: requiredString(body.nameAr,'MARKET_NAME_AR_REQUIRED'),
    nameEn: body.nameEn ? String(body.nameEn).trim() : null,
    description: body.description ? String(body.description) : null,
    configuration: json(body.configuration),
    complianceProfile: json(body.complianceProfile),
    sortOrder: Number.isFinite(Number(body.sortOrder)) ? Number(body.sortOrder) : 0,
    templateMarketId: body.templateMarketId || null,
  };
}

export async function createMarket(actorId, body, ctx={}){
  const x=normalizeMarket(body); const db=await getDb(); const c=await db.connect();
  try{ await c.query('BEGIN'); await requireManager(c,actorId);
    const dup=await c.query('SELECT id FROM hala.markets WHERE market_key=$1',[x.marketKey]); if(dup.rowCount) throw fail('MARKET_KEY_EXISTS',409);
    let template=null;
    if(x.templateMarketId){ uuid(x.templateMarketId,'INVALID_TEMPLATE_MARKET_ID'); const t=await c.query(`SELECT * FROM hala.markets WHERE id=$1 AND status='ACTIVE' AND is_deleted=false`,[x.templateMarketId]); if(!t.rowCount) throw fail('TEMPLATE_MARKET_NOT_ACTIVE',409); template=t.rows[0]; }
    else { const t=await c.query(`SELECT * FROM hala.markets WHERE is_reference_template=true AND status='ACTIVE' AND is_deleted=false ORDER BY updated_at DESC LIMIT 1`); if(t.rowCount) template=t.rows[0]; }
    const r=await c.query(`INSERT INTO hala.markets
      (market_key,name_ar,name_en,description,status,configuration,compliance_profile,sort_order,created_by,updated_by,template_market_id)
      VALUES($1,$2,$3,$4,'DRAFT',$5::jsonb,$6::jsonb,$7,$8,$8,$9) RETURNING *`,
      [x.marketKey,x.nameAr,x.nameEn,x.description,JSON.stringify(template?.configuration||x.configuration),JSON.stringify(template?.compliance_profile||x.complianceProfile),x.sortOrder,actorId,template?.id||null]);
    const newMarket=r.rows[0];
    if(template){
      const sec=await c.query(`SELECT * FROM hala.market_sections WHERE market_id=$1 ORDER BY sort_order,name_ar`,[template.id]); const map=new Map();
      for(const row of sec.rows){ const parentNew=row.parent_id?map.get(row.parent_id)||null:null; const ins=await c.query(`INSERT INTO hala.market_sections(market_id,parent_id,section_key,name_ar,name_en,configuration,sort_order,is_active) VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,$8) RETURNING id`,[newMarket.id,parentNew,row.section_key,row.name_ar,row.name_en,JSON.stringify(row.configuration||{}),row.sort_order,row.is_active]); map.set(row.id,ins.rows[0].id); }
      const catRows=await c.query(`WITH RECURSIVE tree AS (SELECT c.*,0 AS depth FROM hala.categories c WHERE c.market_id=$1 AND c.parent_id IS NULL UNION ALL SELECT c.*,tree.depth+1 FROM hala.categories c JOIN tree ON tree.id=c.parent_id WHERE c.market_id=$1) SELECT * FROM tree ORDER BY depth,sort_order,name_ar`,[template.id]); const catMap=new Map();
      for(const cat of catRows.rows){ const parentNew=cat.parent_id?catMap.get(cat.parent_id)||null:null; const ins=await c.query(`INSERT INTO hala.categories(market_id,parent_id,name_ar,category_kind,sort_order,is_active) VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,[newMarket.id,parentNew,cat.name_ar,cat.category_kind,cat.sort_order,cat.is_active]); catMap.set(cat.id,ins.rows[0].id); }
      const serviceRows=await c.query(`SELECT * FROM hala.services WHERE market_id=$1 ORDER BY created_at`,[template.id]);
      for(const svc of serviceRows.rows){ const newCat=svc.category_id?catMap.get(svc.category_id)||null:null; await c.query(`INSERT INTO hala.services(market_id,category_id,name_ar,description,listing_type,is_active) VALUES($1,$2,$3,$4,$5,$6)`,[newMarket.id,newCat,svc.name_ar,svc.description,svc.listing_type,svc.is_active]); }
      const attrs=await c.query(`SELECT * FROM hala.listing_attribute_definitions WHERE market_id=$1 AND enabled=true`,[template.id]);
      for(const a of attrs.rows) await c.query(`INSERT INTO hala.listing_attribute_definitions(market_id,section_id,category_id,attribute_code,display_name,data_type,unit_code,required,searchable,filterable,sortable,validation_rules,allowed_values,display_rules,version,enabled) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12::jsonb,$13::jsonb,$14::jsonb,1,true)`,[newMarket.id,a.section_id?map.get(a.section_id):null,a.category_id?catMap.get(a.category_id)||null:null,a.attribute_code,a.display_name,a.data_type,a.unit_code,a.required,a.searchable,a.filterable,a.sortable,JSON.stringify(a.validation_rules||{}),JSON.stringify(a.allowed_values||[]),JSON.stringify(a.display_rules||{})]);
      const ops=await c.query(`SELECT DISTINCT ON(operation_code) * FROM hala.market_operation_configs WHERE market_id=$1 ORDER BY operation_code,version DESC`,[template.id]);
      for(const o of ops.rows) await c.query(`INSERT INTO hala.market_operation_configs(market_id,operation_code,enabled,label_ar,label_en,settings,version) VALUES($1,$2,$3,$4,$5,$6::jsonb,1)`,[newMarket.id,o.operation_code,o.enabled,o.label_ar,o.label_en,JSON.stringify(o.settings||{})]);
      const uis=await c.query(`SELECT DISTINCT ON(config_key,language_code) * FROM hala.market_ui_configs WHERE market_id=$1 AND status='PUBLISHED' ORDER BY config_key,language_code,version DESC`,[template.id]);
      for(const ui of uis.rows) await c.query(`INSERT INTO hala.market_ui_configs(market_id,config_key,language_code,config_json,status,version,updated_at) VALUES($1,$2,$3,$4::jsonb,'PUBLISHED',1,now())`,[newMarket.id,ui.config_key,ui.language_code,JSON.stringify(ui.config_json||{})]);
      const pol=await c.query(`SELECT DISTINCT ON(policy_key) * FROM hala.market_policy_configs WHERE market_id=$1 AND status='APPROVED' ORDER BY policy_key,version DESC`,[template.id]);
      for(const po of pol.rows) await c.query(`INSERT INTO hala.market_policy_configs(market_id,policy_key,policy_json,version,status,created_by,approved_by,approved_at) VALUES($1,$2,$3::jsonb,1,'APPROVED',$4,$4,now())`,[newMarket.id,po.policy_key,JSON.stringify(po.policy_json||{}),actorId]);
    }
    await c.query(`INSERT INTO hala.ai_market_bindings(market_id,supervisor_id,local_ai_enabled,local_ai_policy,inheritance_mode) SELECT $1,id,true,'{}'::jsonb,'INHERIT_AND_RESTRICT' FROM hala.ai_supervisor_configs WHERE supervisor_key='platform_supervisor' ON CONFLICT(market_id) DO NOTHING`,[newMarket.id]);
    await audit(c,{marketId:newMarket.id,actorId,objectType:'market',objectId:newMarket.id,action:'CREATE',requestId:ctx.requestId,after:newMarket});
    await c.query('COMMIT'); return newMarket;
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}

export async function setReferenceTemplate(actorId, marketId, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID'); const db=await getDb(); const c=await db.connect();
  try{ await c.query('BEGIN'); await requireManager(c,actorId);
    const q=await c.query('SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false FOR UPDATE',[marketId]);
    if(!q.rowCount) throw fail('MARKET_NOT_FOUND',404);
    if(q.rows[0].status!=='ACTIVE') throw fail('REFERENCE_MARKET_MUST_BE_ACTIVE',409);
    await c.query('UPDATE hala.markets SET is_reference_template=false WHERE is_reference_template=true AND id<>$1',[marketId]);
    const r=await c.query('UPDATE hala.markets SET is_reference_template=true,updated_by=$2,updated_at=now(),version=version+1 WHERE id=$1 RETURNING *',[marketId,actorId]);
    await audit(c,{marketId,actorId,objectType:'market',objectId:marketId,action:'SET_REFERENCE',requestId:ctx.requestId,before:q.rows[0],after:r.rows[0]});
    await c.query('COMMIT'); return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}

export async function listMarkets(actorId, ctx={}){
  const db=await getDb(); const c=await db.connect(); try{ await c.query('BEGIN'); await requireManager(c,actorId);
    const r=await c.query(`SELECT * FROM hala.markets WHERE is_deleted=false ORDER BY sort_order,name_ar`); await c.query('COMMIT'); return r.rows;
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}

export async function getMarket(actorId, marketId){
  uuid(marketId,'INVALID_MARKET_ID'); const db=await getDb(); const c=await db.connect();
  try{ await c.query('BEGIN'); await requireManager(c,actorId);
    const m=await c.query('SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false',[marketId]); if(!m.rowCount) throw fail('MARKET_NOT_FOUND',404);
    const [sections,attrs,ops,uis,policies,members]=await Promise.all([
      c.query('SELECT * FROM hala.market_sections WHERE market_id=$1 ORDER BY sort_order,name_ar',[marketId]),
      c.query('SELECT * FROM hala.listing_attribute_definitions WHERE market_id=$1 AND enabled=true ORDER BY attribute_code',[marketId]),
      c.query('SELECT * FROM hala.market_operation_configs WHERE market_id=$1 ORDER BY operation_code,version DESC',[marketId]),
      c.query("SELECT DISTINCT ON(config_key,language_code) * FROM hala.market_ui_configs WHERE market_id=$1 AND status='PUBLISHED' ORDER BY config_key,language_code,version DESC",[marketId]),
      c.query("SELECT DISTINCT ON(policy_key) * FROM hala.market_policy_configs WHERE market_id=$1 AND status='APPROVED' ORDER BY policy_key,version DESC",[marketId]),
      c.query('SELECT * FROM hala.market_provider_memberships WHERE market_id=$1 ORDER BY created_at DESC',[marketId])
    ]); await c.query('COMMIT'); return {...m.rows[0],sections:sections.rows,attributes:attrs.rows,operations:ops.rows,uiConfigs:uis.rows,policies:policies.rows,providers:members.rows};
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}

export async function updateMarket(actorId, marketId, body, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID'); if(!body || typeof body!=='object') throw fail('INVALID_MARKET_PAYLOAD');
  const allowed=['nameAr','nameEn','description','configuration','complianceProfile','sortOrder'];
  const db=await getDb(); const c=await db.connect(); try{await c.query('BEGIN');await requireManager(c,actorId);
    const q=await c.query('SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false FOR UPDATE',[marketId]); if(!q.rowCount) throw fail('MARKET_NOT_FOUND',404);
    const before=q.rows[0]; const vals={name_ar:body.nameAr ?? before.name_ar,name_en:body.nameEn ?? before.name_en,description:body.description ?? before.description,configuration:body.configuration ?? before.configuration,compliance_profile:body.complianceProfile ?? before.compliance_profile,sort_order:Number.isFinite(Number(body.sortOrder))?Number(body.sortOrder):before.sort_order};
    const r=await c.query(`UPDATE hala.markets SET name_ar=$2,name_en=$3,description=$4,configuration=$5::jsonb,compliance_profile=$6::jsonb,sort_order=$7,updated_by=$8,version=version+1,updated_at=now() WHERE id=$1 RETURNING *`,[marketId,vals.name_ar,vals.name_en,vals.description,JSON.stringify(vals.configuration),JSON.stringify(vals.compliance_profile),vals.sort_order,actorId]);
    await audit(c,{marketId,actorId,objectType:'market',objectId:marketId,action:'UPDATE',requestId:ctx.requestId,before,after:r.rows[0]}); await c.query('COMMIT'); return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}

async function setStatus(actorId, marketId, status, action, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID'); if(!STATUS.has(status)) throw fail('INVALID_MARKET_STATUS'); const db=await getDb();const c=await db.connect();
  try{await c.query('BEGIN');await requireManager(c,actorId);const q=await c.query('SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false FOR UPDATE',[marketId]);if(!q.rowCount)throw fail('MARKET_NOT_FOUND',404);const before=q.rows[0];
    if(status==='ACTIVE'){ const op=await c.query('SELECT 1 FROM hala.market_operation_configs WHERE market_id=$1 AND enabled=true LIMIT 1',[marketId]); if(!op.rowCount) throw fail('MARKET_NEEDS_ENABLED_OPERATION',409); }
    const r=await c.query('UPDATE hala.markets SET status=$2,is_deleted=false,deleted_at=NULL,updated_by=$3,version=version+1,updated_at=now() WHERE id=$1 RETURNING *',[marketId,status,actorId]);
    await audit(c,{marketId,actorId,objectType:'market',objectId:marketId,action,requestId:ctx.requestId,before,after:r.rows[0]}); await c.query('COMMIT'); return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}
export const activateMarket=(a,id,c)=>setStatus(a,id,'ACTIVE','ACTIVATE',c);
export const pauseMarket=(a,id,c)=>setStatus(a,id,'PAUSED','PAUSE',c);
export const archiveMarket=(a,id,c)=>setStatus(a,id,'ARCHIVED','ARCHIVE',c);
export async function softDeleteMarket(actorId, marketId, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID');const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await requireManager(c,actorId);const q=await c.query('SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false FOR UPDATE',[marketId]);if(!q.rowCount)throw fail('MARKET_NOT_FOUND',404);const before=q.rows[0];
    const r=await c.query("UPDATE hala.markets SET is_deleted=true,status='ARCHIVED',deleted_at=now(),updated_by=$2,version=version+1,updated_at=now() WHERE id=$1 RETURNING *",[marketId,actorId]);await audit(c,{marketId,actorId,objectType:'market',objectId:marketId,action:'SOFT_DELETE',requestId:ctx.requestId,before,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function restoreMarket(actorId, marketId, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID');const db=await getDb();const c=await db.connect();
  try{await c.query('BEGIN');await requireManager(c,actorId);const q=await c.query('SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=true FOR UPDATE',[marketId]);if(!q.rowCount)throw fail('DELETED_MARKET_NOT_FOUND',404);const before=q.rows[0];
    const r=await c.query("UPDATE hala.markets SET is_deleted=false,deleted_at=NULL,status='DRAFT',updated_by=$2,version=version+1,updated_at=now() WHERE id=$1 RETURNING *",[marketId,actorId]);await audit(c,{marketId,actorId,objectType:'market',objectId:marketId,action:'RESTORE',requestId:ctx.requestId,before,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}


export async function upsertOperation(actorId, marketId, body, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID'); if(!OPS.has(body.operationCode)) throw fail('INVALID_OPERATION_CODE');
  const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await requireManager(c,actorId);const m=await c.query('SELECT id FROM hala.markets WHERE id=$1 AND is_deleted=false',[marketId]);if(!m.rowCount)throw fail('MARKET_NOT_FOUND',404);
    const r=await c.query(`INSERT INTO hala.market_operation_configs(market_id,operation_code,enabled,label_ar,label_en,settings,version)
      VALUES($1,$2,$3,$4,$5,$6::jsonb,COALESCE((SELECT max(version)+1 FROM hala.market_operation_configs WHERE market_id=$1 AND operation_code=$2),1)) RETURNING *`,
      [marketId,body.operationCode,body.enabled!==false,body.labelAr||null,body.labelEn||null,JSON.stringify(body.settings||{})]);
    await audit(c,{marketId,actorId,objectType:'market_operation_config',objectId:r.rows[0].id,action:'CREATE',requestId:ctx.requestId,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}

export async function createUiConfig(actorId, marketId, body, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID');const key=requiredString(body.configKey,'CONFIG_KEY_REQUIRED');const lang=body.languageCode||'ar';const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await requireManager(c,actorId);const m=await c.query('SELECT id FROM hala.markets WHERE id=$1 AND is_deleted=false',[marketId]);if(!m.rowCount)throw fail('MARKET_NOT_FOUND',404);
    const r=await c.query(`INSERT INTO hala.market_ui_configs(market_id,config_key,language_code,config_json,version,status,created_by)
      VALUES($1,$2,$3,$4::jsonb,COALESCE((SELECT max(version)+1 FROM hala.market_ui_configs WHERE market_id=$1 AND config_key=$2 AND language_code=$3),1),'DRAFT',$5) RETURNING *`,[marketId,key,lang,JSON.stringify(body.configJson||{}),actorId]);
    await audit(c,{marketId,actorId,objectType:'market_ui_config',objectId:r.rows[0].id,action:'CREATE',requestId:ctx.requestId,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}

export async function createSection(actorId, marketId, body, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID');const key=requiredString(body.sectionKey,'SECTION_KEY_REQUIRED');const name=requiredString(body.nameAr,'SECTION_NAME_AR_REQUIRED');const parent=body.parentId?uuid(body.parentId):null;const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await requireManager(c,actorId);const m=await c.query('SELECT id FROM hala.markets WHERE id=$1 AND is_deleted=false',[marketId]);if(!m.rowCount)throw fail('MARKET_NOT_FOUND',404);
    if(parent){const p=await c.query('SELECT id FROM hala.market_sections WHERE id=$1 AND market_id=$2',[parent,marketId]);if(!p.rowCount)throw fail('INVALID_SECTION_PARENT',400)}
    const r=await c.query(`INSERT INTO hala.market_sections(market_id,parent_id,section_key,name_ar,name_en,configuration,sort_order,is_active) VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,true) RETURNING *`,[marketId,parent,key,name,body.nameEn||null,JSON.stringify(body.configuration||{}),Number(body.sortOrder||0)]);await audit(c,{marketId,actorId,objectType:'market_section',objectId:r.rows[0].id,action:'CREATE',requestId:ctx.requestId,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}

export async function createAttribute(actorId, marketId, body, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID');const code=requiredString(body.attributeCode,'ATTRIBUTE_CODE_REQUIRED');const name=requiredString(body.displayName,'ATTRIBUTE_DISPLAY_NAME_REQUIRED');const dt=requiredString(body.dataType,'ATTRIBUTE_DATA_TYPE_REQUIRED');const section=body.sectionId?uuid(body.sectionId):null;const category=body.categoryId?uuid(body.categoryId):null;const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await requireManager(c,actorId);
    const m=await c.query('SELECT id FROM hala.markets WHERE id=$1 AND is_deleted=false',[marketId]);if(!m.rowCount)throw fail('MARKET_NOT_FOUND',404);
    if(section){const q=await c.query('SELECT 1 FROM hala.market_sections WHERE id=$1 AND market_id=$2 AND is_active=true',[section,marketId]);if(!q.rowCount)throw fail('INVALID_ATTRIBUTE_SECTION',400);}
    if(category){const q=await c.query('SELECT 1 FROM hala.categories WHERE id=$1 AND market_id=$2',[category,marketId]);if(!q.rowCount)throw fail('INVALID_ATTRIBUTE_CATEGORY',400);}
    const r=await c.query(`INSERT INTO hala.listing_attribute_definitions(market_id,section_id,category_id,attribute_code,display_name,data_type,unit_code,required,searchable,filterable,sortable,validation_rules,allowed_values,display_rules,version,enabled)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12::jsonb,$13::jsonb,$14::jsonb,COALESCE((SELECT max(version)+1 FROM hala.listing_attribute_definitions WHERE market_id=$1 AND section_id IS NOT DISTINCT FROM $2 AND category_id IS NOT DISTINCT FROM $3 AND attribute_code=$4),1),true) RETURNING *`,[marketId,section,category,code,name,dt,body.unitCode||null,!!body.required,!!body.searchable,!!body.filterable,!!body.sortable,JSON.stringify(body.validationRules||{}),JSON.stringify(body.allowedValues||[]),JSON.stringify(body.displayRules||{})]);
    await audit(c,{marketId,actorId,objectType:'listing_attribute_definition',objectId:r.rows[0].id,action:'CREATE',requestId:ctx.requestId,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}



export async function updateSection(actorId, sectionId, body, ctx={}){
  uuid(sectionId,'INVALID_SECTION_ID'); const db=await getDb(); const c=await db.connect();
  try{await c.query('BEGIN');await requireManager(c,actorId);const q=await c.query('SELECT * FROM hala.market_sections WHERE id=$1 FOR UPDATE',[sectionId]);if(!q.rowCount)throw fail('SECTION_NOT_FOUND',404);const before=q.rows[0];
    const r=await c.query(`UPDATE hala.market_sections SET name_ar=COALESCE($2,name_ar),name_en=COALESCE($3,name_en),configuration=COALESCE($4::jsonb,configuration),sort_order=COALESCE($5,sort_order),is_active=COALESCE($6,is_active) WHERE id=$1 RETURNING *`,[sectionId,body.nameAr??null,body.nameEn??null,body.configuration?JSON.stringify(body.configuration):null,body.sortOrder==null?null:Number(body.sortOrder),body.isActive==null?null:!!body.isActive]);
    await audit(c,{marketId:r.rows[0].market_id,actorId,objectType:'market_section',objectId:sectionId,action:'UPDATE',requestId:ctx.requestId,before,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function archiveSection(actorId, sectionId, ctx={}){return updateSection(actorId,sectionId,{isActive:false},ctx)}

export async function updateAttribute(actorId, attributeId, body, ctx={}){
  uuid(attributeId,'INVALID_ATTRIBUTE_ID'); const db=await getDb(); const c=await db.connect();
  try{await c.query('BEGIN');await requireManager(c,actorId);const q=await c.query('SELECT * FROM hala.listing_attribute_definitions WHERE id=$1 FOR UPDATE',[attributeId]);if(!q.rowCount)throw fail('ATTRIBUTE_NOT_FOUND',404);const before=q.rows[0];
    const r=await c.query(`UPDATE hala.listing_attribute_definitions SET display_name=COALESCE($2,display_name),data_type=COALESCE($3,data_type),unit_code=COALESCE($4,unit_code),required=COALESCE($5,required),searchable=COALESCE($6,searchable),filterable=COALESCE($7,filterable),sortable=COALESCE($8,sortable),validation_rules=COALESCE($9::jsonb,validation_rules),allowed_values=COALESCE($10::jsonb,allowed_values),display_rules=COALESCE($11::jsonb,display_rules),enabled=COALESCE($12,enabled),version=version+1 WHERE id=$1 RETURNING *`,[attributeId,body.displayName??null,body.dataType??null,body.unitCode??null,body.required==null?null:!!body.required,body.searchable==null?null:!!body.searchable,body.filterable==null?null:!!body.filterable,body.sortable==null?null:!!body.sortable,body.validationRules?JSON.stringify(body.validationRules):null,body.allowedValues?JSON.stringify(body.allowedValues):null,body.displayRules?JSON.stringify(body.displayRules):null,body.enabled==null?null:!!body.enabled]);
    await audit(c,{marketId:r.rows[0].market_id,actorId,objectType:'listing_attribute_definition',objectId:attributeId,action:'UPDATE',requestId:ctx.requestId,before,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function archiveAttribute(actorId, attributeId, ctx={}){return updateAttribute(actorId,attributeId,{enabled:false},ctx)}

export async function updateUiConfig(actorId, configId, body, ctx={}){
  uuid(configId,'INVALID_UI_CONFIG_ID'); const db=await getDb(); const c=await db.connect();
  try{await c.query('BEGIN');await requireManager(c,actorId);const q=await c.query('SELECT * FROM hala.market_ui_configs WHERE id=$1 FOR UPDATE',[configId]);if(!q.rowCount)throw fail('UI_CONFIG_NOT_FOUND',404);const before=q.rows[0];
    const r=await c.query(`UPDATE hala.market_ui_configs SET config_json=$2::jsonb,version=version+1,status='DRAFT',updated_at=now() WHERE id=$1 RETURNING *`,[configId,JSON.stringify(body.configJson||{})]);await audit(c,{marketId:r.rows[0].market_id,actorId,objectType:'market_ui_config',objectId:configId,action:'UPDATE',requestId:ctx.requestId,before,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function archiveUiConfig(actorId, configId, ctx={}){uuid(configId,'INVALID_UI_CONFIG_ID');const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await requireManager(c,actorId);const q=await c.query('SELECT * FROM hala.market_ui_configs WHERE id=$1 FOR UPDATE',[configId]);if(!q.rowCount)throw fail('UI_CONFIG_NOT_FOUND',404);const before=q.rows[0];const r=await c.query("UPDATE hala.market_ui_configs SET status='ARCHIVED',updated_at=now() WHERE id=$1 RETURNING *",[configId]);await audit(c,{marketId:r.rows[0].market_id,actorId,objectType:'market_ui_config',objectId:configId,action:'ARCHIVE',requestId:ctx.requestId,before,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}

export async function addProvider(actorId, marketId, providerId, ctx={}){
  uuid(marketId,'INVALID_MARKET_ID');uuid(providerId,'INVALID_PROVIDER_ID');const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await requireManager(c,actorId);const m=await c.query('SELECT 1 FROM hala.markets WHERE id=$1 AND is_deleted=false',[marketId]);if(!m.rowCount)throw fail('MARKET_NOT_FOUND',404);const p=await c.query('SELECT 1 FROM hala.providers WHERE id=$1',[providerId]);if(!p.rowCount)throw fail('PROVIDER_NOT_FOUND',404);const r=await c.query(`INSERT INTO hala.market_provider_memberships(market_id,provider_id,status,joined_at) VALUES($1,$2,'ACTIVE',now()) ON CONFLICT(market_id,provider_id) DO UPDATE SET status='ACTIVE',joined_at=COALESCE(market_provider_memberships.joined_at,now()),updated_at=now() RETURNING *`,[marketId,providerId]);await audit(c,{marketId,actorId,objectType:'market_provider_membership',objectId:r.rows[0].id,action:'CREATE',requestId:ctx.requestId,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function suspendProvider(actorId, membershipId, ctx={}){uuid(membershipId,'INVALID_MEMBERSHIP_ID');const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await requireManager(c,actorId);const q=await c.query('SELECT * FROM hala.market_provider_memberships WHERE id=$1 FOR UPDATE',[membershipId]);if(!q.rowCount)throw fail('MEMBERSHIP_NOT_FOUND',404);const before=q.rows[0];const r=await c.query("UPDATE hala.market_provider_memberships SET status='SUSPENDED',suspended_at=now(),updated_at=now() WHERE id=$1 RETURNING *",[membershipId]);await audit(c,{marketId:r.rows[0].market_id,actorId,objectType:'market_provider_membership',objectId:membershipId,action:'UPDATE',requestId:ctx.requestId,before,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}



export async function publishUiConfig(actorId, configId, ctx={}){
  uuid(configId,'INVALID_UI_CONFIG_ID');const db=await getDb();const c=await db.connect();try{await c.query('BEGIN');await requireManager(c,actorId);const q=await c.query('SELECT * FROM hala.market_ui_configs WHERE id=$1 FOR UPDATE',[configId]);if(!q.rowCount)throw fail('UI_CONFIG_NOT_FOUND',404);const before=q.rows[0];
    const r=await c.query("UPDATE hala.market_ui_configs SET status='PUBLISHED',published_by=$2,published_at=now(),updated_at=now() WHERE id=$1 RETURNING *",[configId,actorId]);await audit(c,{marketId:r.rows[0].market_id,actorId,objectType:'market_ui_config',objectId:configId,action:'UPDATE',requestId:ctx.requestId,before,after:r.rows[0]});await c.query('COMMIT');return r.rows[0];
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}

export async function getPublicMarketConfig(marketKey){
  const key=requiredString(marketKey,'MARKET_KEY_REQUIRED').toLowerCase();const db=await getDb();const r=await db.query(`SELECT id,market_key,name_ar,name_en,description,configuration,compliance_profile,sort_order,status FROM hala.markets WHERE market_key=$1 AND status='ACTIVE' AND is_deleted=false`,[key]);if(!r.rowCount)throw fail('MARKET_NOT_FOUND',404);const m=r.rows[0];const [sections,ops,uis,attrs]=await Promise.all([
    db.query('SELECT id,parent_id,section_key,name_ar,name_en,configuration,sort_order FROM hala.market_sections WHERE market_id=$1 AND is_active=true ORDER BY sort_order,name_ar',[m.id]),
    db.query(`SELECT DISTINCT ON(operation_code) operation_code,enabled,label_ar,label_en,settings,version FROM hala.market_operation_configs WHERE market_id=$1 ORDER BY operation_code,version DESC`,[m.id]),
    db.query(`SELECT DISTINCT ON(config_key,language_code) config_key,language_code,config_json,version FROM hala.market_ui_configs WHERE market_id=$1 AND status='PUBLISHED' ORDER BY config_key,language_code,version DESC`,[m.id]),
    db.query(`SELECT id,section_id,category_id,attribute_code,display_name,data_type,unit_code,required,searchable,filterable,sortable,validation_rules,allowed_values,display_rules,version FROM hala.listing_attribute_definitions WHERE market_id=$1 AND enabled=true ORDER BY attribute_code,version DESC`,[m.id])
  ]);return {...m,sections:sections.rows,operations:ops.rows,ui:uis.rows,attributes:attrs.rows};
}
