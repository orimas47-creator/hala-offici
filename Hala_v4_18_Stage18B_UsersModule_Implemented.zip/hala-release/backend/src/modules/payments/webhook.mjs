import crypto from 'node:crypto';
import { getDb } from '../../common/db.mjs';
const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});
function signatureValid(raw,signature,secret,timestamp){
  if(!signature||!secret)return false; const received=String(signature).replace(/^sha256=/i,'').trim(); const payload=timestamp ? `${timestamp}.${raw}` : raw; const expected=crypto.createHmac('sha256',secret).update(payload).digest('hex');
  return received.length===expected.length && crypto.timingSafeEqual(Buffer.from(received),Buffer.from(expected));
}
export async function receivePaymentWebhook(provider,rawBody,headers={}){
 const secret=process.env[`HALA_WEBHOOK_SECRET_${String(provider).toUpperCase().replace(/[^A-Z0-9]/g,'_')}`] || process.env.HALA_WEBHOOK_SECRET;
 const timestamp=String(headers['x-hala-timestamp']||'').trim();
 const requireTimestamp=String(process.env.HALA_WEBHOOK_REQUIRE_TIMESTAMP||'false').toLowerCase()==='true';
 if(requireTimestamp && !timestamp) throw fail('WEBHOOK_TIMESTAMP_REQUIRED',401);
 if(timestamp){ const ts=Number(timestamp); if(!Number.isFinite(ts)) throw fail('INVALID_WEBHOOK_TIMESTAMP',401); const age=Math.abs(Date.now()/1000-ts); const tolerance=Number(process.env.HALA_WEBHOOK_TIMESTAMP_TOLERANCE_SECONDS||300); if(age>tolerance) throw fail('STALE_WEBHOOK_TIMESTAMP',401); }
 if(!signatureValid(rawBody,headers['x-hala-signature'],secret,timestamp||null))throw fail('INVALID_WEBHOOK_SIGNATURE',401);
 let body; try{body=JSON.parse(rawBody)}catch{throw fail('INVALID_WEBHOOK_JSON');}
 const eventId=String(body.eventId||body.id||'').trim(); const eventType=String(body.type||body.eventType||'').trim(); if(!eventId||!eventType)throw fail('WEBHOOK_EVENT_ID_AND_TYPE_REQUIRED');
 const db=await getDb(); const c=await db.connect(); try{await c.query('BEGIN');
   const existing=await c.query(`SELECT id,status FROM hala.webhook_inbox WHERE provider_name=$1 AND external_event_id=$2 FOR UPDATE`,[provider,eventId]); if(existing.rowCount){await c.query('COMMIT');return {accepted:true,duplicate:true,eventId,status:existing.rows[0].status};}
   await c.query(`INSERT INTO hala.webhook_inbox(provider_name,external_event_id,event_type,payload,status) VALUES($1,$2,$3,$4::jsonb,'RECEIVED')`,[provider,eventId,eventType,rawBody]);
   await c.query(`UPDATE hala.webhook_inbox SET status='QUEUED' WHERE provider_name=$1 AND external_event_id=$2`,[provider,eventId]);
   await c.query('COMMIT'); return {accepted:true,duplicate:false,eventId,status:'QUEUED'};
 }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}
