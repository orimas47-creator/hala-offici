import { getDb } from '../../common/db.mjs';
import { randomUUID } from 'node:crypto';
import { superviseInTransaction } from '../ai/supervisor.mjs';
import { reserveBookingInventory, activateBookingInventory, releaseBookingInventory } from '../availability/service.mjs';

const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});
const METHODS=new Set(['wallet','bank','card','local_wallet','cash']);
const amountOf=v=>{const n=Number(v);if(!Number.isFinite(n)||n<=0)throw fail('INVALID_PAYMENT_AMOUNT');return Math.round(n*100)/100;};

async function ensureLedgerAccounts(c){
  const defs=[['HALA_CASH_CLEARING','Hala Cash Clearing','asset'],['CUSTOMER_ESCROW_FUNDS','Customer Escrow Funds','liability'],['PROVIDER_PAYABLE','Provider Payable','liability']];
  const out={};
  for(const [code,name,type] of defs){const r=await c.query(`INSERT INTO hala.ledger_accounts(account_code,account_name,account_type) VALUES($1,$2,$3) ON CONFLICT(account_code) DO UPDATE SET account_name=EXCLUDED.account_name RETURNING id,account_code`,[code,name,type]);out[code]=r.rows[0].id;}
  return out;
}
async function postBalanced(c,{referenceType,referenceId,description,lines}){
  const signed=lines.reduce((s,l)=>s+(l.side==='debit'?Number(l.amount):-Number(l.amount)),0);
  if(Math.abs(signed)>0.000001)throw fail('LEDGER_UNBALANCED',500);
  const ex=await c.query(`SELECT id FROM hala.ledger_entries WHERE reference_type=$1 AND reference_id=$2 LIMIT 1`,[referenceType,referenceId]);
  if(ex.rowCount)return ex.rows[0].id;
  const e=await c.query(`INSERT INTO hala.ledger_entries(reference_type,reference_id,description) VALUES($1,$2,$3) RETURNING id`,[referenceType,referenceId,description]);
  for(const l of lines) await c.query(`INSERT INTO hala.ledger_entry_lines(entry_id,account_id,side,amount,currency) VALUES($1,$2,$3,$4,$5)`,[e.rows[0].id,l.accountId,l.side,l.amount,l.currency||'YER']);
  return e.rows[0].id;
}

export async function createPayment(actor, bookingId, body={}, ctx={}) {
  if (!actor) throw fail('ACTOR_REQUIRED',401);
  const amount=amountOf(body.amount); const method=String(body.method||'local_wallet').toLowerCase(); if(!METHODS.has(method))throw fail('INVALID_PAYMENT_METHOD');
  const db=await getDb(); const client=await db.connect();
  try{
    await client.query('BEGIN');
    const b=await client.query(`SELECT * FROM hala.bookings WHERE id=$1 AND customer_id=$2 FOR UPDATE`,[bookingId,actor]);
    if(!b.rowCount)throw fail('BOOKING_NOT_FOUND',404); const booking=b.rows[0]; const currency=String(booking.currency_code||'YER').toUpperCase(); if(!/^[A-Z]{3}$/.test(currency)) throw fail('INVALID_BOOKING_CURRENCY',409);
    if(!['DRAFT','PAYMENT_PENDING'].includes(booking.lifecycle_status))throw fail('BOOKING_NOT_PAYABLE',409);
    if(ctx.idempotencyKey){const existing=await client.query(`SELECT response_body FROM hala.idempotency_records WHERE actor_user_id=$1 AND idempotency_key=$2 AND route='POST /api/v1/bookings/payment'`,[actor,ctx.idempotencyKey]);if(existing.rowCount){await client.query('COMMIT');return existing.rows[0].response_body;}}
    const outstandingQ=await client.query(`SELECT GREATEST(b.total_amount-COALESCE(SUM(CASE WHEN p.status='verified' THEN p.amount ELSE 0 END),0),0)::numeric outstanding FROM hala.bookings b LEFT JOIN hala.payments p ON p.booking_id=b.id WHERE b.id=$1 GROUP BY b.id`,[bookingId]);
    const outstanding=Number(outstandingQ.rows[0]?.outstanding||0); if(amount>outstanding+0.000001)throw fail('PAYMENT_EXCEEDS_OUTSTANDING',409);
    const lock=await client.query(`SELECT 1 FROM hala.payment_locks WHERE booking_id=$1 AND locked_until>now() FOR UPDATE`,[bookingId]); if(lock.rowCount)throw fail('PAYMENT_LOCK_ACTIVE',409);
    const p=await client.query(`INSERT INTO hala.payments(booking_id,customer_id,amount,currency_code,method,status,client_reference) VALUES($1,$2,$3,$4,$5,'pending',$6) RETURNING *`,[bookingId,actor,amount,currency,method,body.clientReference||null]);
    await client.query(`INSERT INTO hala.payment_attempts(payment_id,attempt_no,external_reference,request_payload,status) VALUES($1,COALESCE((SELECT max(attempt_no)+1 FROM hala.payment_attempts WHERE payment_id=$1),1),$2,$3,'pending')`,[p.rows[0].id,body.externalReference||null,JSON.stringify(body)]);
    const tx=await client.query(`INSERT INTO hala.payment_transactions(payment_id,idempotency_key,external_reference,status,amount,currency_code,received_at) VALUES($1,$2,$3,'pending',$4,$5,now()) RETURNING *`,[p.rows[0].id,ctx.idempotencyKey||`idem-${randomUUID()}`,body.externalReference||null,amount,currency]);
    await client.query(`INSERT INTO hala.payment_locks(booking_id,locked_until,reason) VALUES($1,now()+interval '5 minutes','BOOKING_PAYMENT') ON CONFLICT(booking_id) DO UPDATE SET locked_until=EXCLUDED.locked_until,reason=EXCLUDED.reason`,[bookingId]);
    if(booking.lifecycle_status==='DRAFT') {
      await reserveBookingInventory(client,bookingId,{booking});
      await client.query(`UPDATE hala.bookings SET lifecycle_status='PAYMENT_PENDING',lifecycle_version=lifecycle_version+1,updated_at=now() WHERE id=$1`,[bookingId]);
      await client.query(`INSERT INTO hala.booking_lifecycle_history(booking_id,from_status,to_status,actor_user_id,request_id,reason) VALUES($1,'DRAFT','PAYMENT_PENDING',$2,$3,'payment.created')`,[bookingId,actor,ctx.requestId||null]);
    }
    const out=tx.rows[0]; if(ctx.idempotencyKey)await client.query(`INSERT INTO hala.idempotency_records(actor_user_id,idempotency_key,route,request_hash,response_status,response_body,expires_at) VALUES($1,$2,'POST /api/v1/bookings/payment','not-computed',201,$3::jsonb,now()+interval '24 hours')`,[actor,ctx.idempotencyKey,JSON.stringify(out)]);
    await client.query('COMMIT'); return out;
  }catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
}

export async function settlePaymentInTransaction(client, actor, bookingId, txId, outcome='verified', ctx={}) {
  if(!['verified','failed'].includes(outcome)) throw fail('INVALID_PAYMENT_OUTCOME');
  const q=await client.query(`SELECT t.*,p.customer_id,p.amount,p.currency_code AS payment_currency,t.currency_code AS transaction_currency,p.id payment_id,b.total_amount,b.lifecycle_status FROM hala.payment_transactions t JOIN hala.payments p ON p.id=t.payment_id JOIN hala.bookings b ON b.id=p.booking_id WHERE t.id=$1 AND p.booking_id=$2 FOR UPDATE`,[txId,bookingId]);
  if(!q.rowCount) throw fail('PAYMENT_TRANSACTION_NOT_FOUND',404);
  const row=q.rows[0];
  if(row.payment_currency!==row.transaction_currency) throw fail('PAYMENT_CURRENCY_MISMATCH',409);
  if(row.status!=='pending') throw fail('PAYMENT_ALREADY_FINAL',409);
  await client.query(`UPDATE hala.payment_transactions SET status=$2,reconciled_at=now() WHERE id=$1 AND status='pending'`,[txId,outcome]);
  await client.query(`UPDATE hala.payments SET status=$2,verified_at=CASE WHEN $2='verified' THEN now() ELSE verified_at END,failed_at=CASE WHEN $2='failed' THEN now() ELSE failed_at END WHERE id=$1 AND status='pending'`,[row.payment_id,outcome]);
  await client.query(`UPDATE hala.payment_attempts SET status=$2,finished_at=now(),response_payload=$3::jsonb WHERE payment_id=$1 AND finished_at IS NULL`,[row.payment_id,outcome,JSON.stringify({outcome,requestId:ctx.requestId||null})]);
  await client.query(`DELETE FROM hala.payment_locks WHERE booking_id=$1`,[bookingId]);
  await superviseInTransaction(client,{eventKey:`payment.${outcome}`,marketId:null,resourceType:'payment_transaction',resourceId:txId,actorId:actor||null,payload:{amount:Number(row.amount),bookingId,transactionId:txId,outcome}});
  if(outcome==='verified'){
    await client.query(`UPDATE hala.escrow_accounts SET held_amount=held_amount+$2,status='holding' WHERE booking_id=$1`,[bookingId,Number(row.amount)]);
    const a=await ensureLedgerAccounts(client); await postBalanced(client,{referenceType:'PAYMENT_VERIFIED',referenceId:txId,description:`Verified payment ${txId}`,lines:[{accountId:a.HALA_CASH_CLEARING,side:'debit',amount:Number(row.amount),currency:row.currency_code},{accountId:a.CUSTOMER_ESCROW_FUNDS,side:'credit',amount:Number(row.amount),currency:row.currency_code}]});
    const paid=await client.query(`SELECT COALESCE(SUM(amount),0)::numeric verified FROM hala.payments WHERE booking_id=$1 AND status='verified'`,[bookingId]);
    if(Number(paid.rows[0].verified)+0.000001>=Number(row.total_amount)) {
      await activateBookingInventory(client,bookingId);
      await client.query(`UPDATE hala.bookings SET lifecycle_status='PROVIDER_PENDING',lifecycle_version=lifecycle_version+1,updated_at=now() WHERE id=$1 AND lifecycle_status='PAYMENT_PENDING'`,[bookingId]);
      await client.query(`INSERT INTO hala.booking_lifecycle_history(booking_id,from_status,to_status,actor_user_id,request_id,reason) VALUES($1,'PAYMENT_PENDING','PROVIDER_PENDING',$2,$3,'payment.verified')`,[bookingId,actor||null,ctx.requestId||null]);
    }
  } else {
    await releaseBookingInventory(client,bookingId,'FAILED');
    await client.query(`UPDATE hala.bookings SET lifecycle_status='FAILED',lifecycle_version=lifecycle_version+1,updated_at=now() WHERE id=$1 AND lifecycle_status='PAYMENT_PENDING'`,[bookingId]);
    await client.query(`INSERT INTO hala.booking_lifecycle_history(booking_id,from_status,to_status,actor_user_id,request_id,reason) VALUES($1,'PAYMENT_PENDING','FAILED',$2,$3,'payment.failed')`,[bookingId,actor||null,ctx.requestId||null]);
  }
  return {transactionId:txId,status:outcome};
}

export async function verifyPayment(actor, bookingId, txId, outcome='verified', ctx={}) {
  if (!actor) throw fail('ACTOR_REQUIRED',401);
  const db=await getDb(); const client=await db.connect();
  try { await client.query('BEGIN'); const out=await settlePaymentInTransaction(client,actor,bookingId,txId,outcome,ctx); await client.query('COMMIT'); return out; }
  catch(e){await client.query('ROLLBACK');throw e} finally{client.release()}
}
