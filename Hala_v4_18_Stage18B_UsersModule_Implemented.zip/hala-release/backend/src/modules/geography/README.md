# geography
وحدة Hala v4.2. المنطق الحساس يمر عبر Service/Domain ويدوّن Audit، ولا يعتمد على الواجهة كمصدر حقيقة.
