import {getDb} from '../../common/db.mjs';
export async function children(parentId){ const db=await getDb(); const r=await db.query('SELECT id,level_id,parent_id,name_ar,code FROM hala.locations WHERE parent_id IS NOT DISTINCT FROM $1 ORDER BY name_ar',[parentId||null]); return r.rows; }
