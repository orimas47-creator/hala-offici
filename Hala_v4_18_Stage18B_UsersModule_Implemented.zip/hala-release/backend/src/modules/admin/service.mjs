import { getDb } from '../../common/db.mjs';
const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});
async function requireAdmin(db,actorId){const q=await db.query(`SELECT 1 FROM hala.user_roles ur JOIN hala.roles r ON r.id=ur.role_id WHERE ur.user_id=$1 AND lower(r.name) IN ('admin','super_admin','administrator')`,[actorId]);if(!q.rowCount)throw fail('FORBIDDEN',403)}
export async function dashboard(actorId){const db=await getDb();await requireAdmin(db,actorId);const [markets,providers,bookings,incidents]=await Promise.all([
 db.query(`SELECT COUNT(*)::int total,COUNT(*) FILTER(WHERE status='ACTIVE')::int active FROM hala.markets WHERE is_deleted=false`),
 db.query(`SELECT COUNT(*)::int total,COUNT(*) FILTER(WHERE status='active')::int active,COUNT(*) FILTER(WHERE status='suspended')::int suspended FROM hala.providers`),
 db.query(`SELECT COUNT(*)::int total,COUNT(*) FILTER(WHERE lifecycle_status IN ('PAYMENT_PENDING','PROVIDER_PENDING','CONFIRMED','IN_PROGRESS'))::int open FROM hala.bookings`),
 db.query(`SELECT COUNT(*)::int open FROM hala.ai_supervisor_incidents WHERE status IN ('OPEN','ACKNOWLEDGED','MITIGATING')`)
]);return {markets:markets.rows[0],providers:providers.rows[0],bookings:bookings.rows[0],security:incidents.rows[0]};}
