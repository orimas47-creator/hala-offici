import { getDb } from '../../common/db.mjs';
const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});
function safeUrl(v,{path=false}={}){
  if(v==null || v==='') return null;
  const x=String(v).trim();
  if(/^javascript:/i.test(x) || /^data:/i.test(x) || /^vbscript:/i.test(x) || /[\r\n]/.test(x)) throw fail('UNSAFE_EXTERNAL_URL');
  if(path){ if(!x.startsWith('/') || x.startsWith('//')) throw fail('INVALID_TARGET_PATH'); return x; }
  if(!/^https:\/\//i.test(x)) throw fail('HTTPS_URL_REQUIRED');
  return x;
}

export async function getGlobalPortal(){
  const db=await getDb();
  const [rails,ads,markets]=await Promise.all([
    db.query(`SELECT r.id,r.rail_key,r.title_ar,r.title_en,r.ranking_code,r.max_items,r.market_id,r.filter_json FROM hala.global_portal_rails r WHERE r.enabled=true ORDER BY r.sort_order,r.title_ar`),
    db.query(`SELECT a.id,a.market_id,
      CASE WHEN a.provider_id IS NULL THEN a.advertiser_name ELSE NULL END AS advertiser_name,
      a.title,a.body,a.asset_url,a.target_path,a.placement
      FROM hala.global_portal_ads a
      LEFT JOIN hala.markets m ON m.id=a.market_id
      WHERE a.status='ACTIVE'
        AND (a.start_at IS NULL OR a.start_at<=now())
        AND (a.end_at IS NULL OR a.end_at>=now())
        AND (m.id IS NULL OR (m.status='ACTIVE' AND m.is_deleted=false))
      ORDER BY a.created_at DESC LIMIT 100`),
    db.query(`SELECT id,market_key,name_ar,name_en,description,sort_order FROM hala.markets WHERE status='ACTIVE' AND is_deleted=false ORDER BY sort_order,name_ar`)
  ]);
  const content=[];
  for(const rail of rails.rows){
    const order={
      NEWEST:'ul.created_at DESC',
      TOP_RENTAL:`CASE WHEN lp.amount IS NULL THEN 0 ELSE 1 END DESC, COALESCE((SELECT AVG(cf.rating) FROM hala.customer_feedback cf WHERE cf.offer_id=ul.offer_id),0) DESC`,
      TOP_RATING:`COALESCE((SELECT AVG(cf.rating) FROM hala.customer_feedback cf WHERE cf.offer_id=ul.offer_id),0) DESC, ul.created_at DESC`,
      TOP_QUALITY:`CASE WHEN COALESCE(ul.attributes->>'qualityScore','') ~ '^[0-9]+(\\.[0-9]+)?$' THEN (ul.attributes->>'qualityScore')::numeric ELSE 0 END DESC, ul.created_at DESC`,
      TOP_DEMAND:`COALESCE((SELECT COUNT(*) FROM hala.supply_demand_matches sdm WHERE sdm.listing_id=ul.id),0) DESC, ul.created_at DESC`,
      TOP_MATCH:`COALESCE((SELECT AVG(sdm.score) FROM hala.supply_demand_matches sdm WHERE sdm.listing_id=ul.id),0) DESC, ul.created_at DESC`,
      MIXED:`COALESCE((SELECT AVG(cf.rating) FROM hala.customer_feedback cf WHERE cf.offer_id=ul.offer_id),0) DESC, ul.created_at DESC`
    }[rail.ranking_code] || 'ul.created_at DESC';
    const params=[rail.max_items]; let marketClause='';
    if(rail.market_id){ params.push(rail.market_id); marketClause=' AND ul.market_id=$2'; }
    const q=await db.query(`SELECT ul.id,ul.market_id,ul.title,ul.short_description,ul.listing_kind,ul.base_currency,ul.base_price,ul.created_at,m.market_key,m.name_ar AS market_name,
      COALESCE((SELECT AVG(cf.rating) FROM hala.customer_feedback cf WHERE cf.offer_id=ul.offer_id),0) AS rating,
      COALESCE((SELECT lp.amount FROM hala.listing_prices lp WHERE lp.listing_id=ul.id AND lp.enabled=true AND lp.price_type='RENTAL' ORDER BY lp.amount LIMIT 1),NULL) AS rental_price
      FROM hala.universal_listings ul JOIN hala.markets m ON m.id=ul.market_id
      LEFT JOIN LATERAL (SELECT amount FROM hala.listing_prices WHERE listing_id=ul.id AND enabled=true AND price_type='RENTAL' ORDER BY amount LIMIT 1) lp ON true
      WHERE ul.listing_status='PUBLISHED' AND m.status='ACTIVE' AND m.is_deleted=false${marketClause} ORDER BY ${order} LIMIT $1`,params);
    content.push({...rail,items:q.rows});
  }
  return {portal:{name:'Hala Global Portal',tagline:'يجمعنا'},markets:markets.rows,ads:ads.rows,rails:content};
}

export async function listPortalRails(actorId){
  const db=await getDb(); const r=await db.query(`SELECT * FROM hala.global_portal_rails ORDER BY sort_order,title_ar`); return r.rows;
}
export async function upsertPortalRail(actorId,body){
  const db=await getDb(); const r=await db.query(`INSERT INTO hala.global_portal_rails(rail_key,market_id,title_ar,title_en,ranking_code,max_items,filter_json,sort_order,enabled,version,updated_by,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb,$8,$9,1,$10,now()) ON CONFLICT(rail_key) DO UPDATE SET market_id=EXCLUDED.market_id,title_ar=EXCLUDED.title_ar,title_en=EXCLUDED.title_en,ranking_code=EXCLUDED.ranking_code,max_items=EXCLUDED.max_items,filter_json=EXCLUDED.filter_json,sort_order=EXCLUDED.sort_order,enabled=EXCLUDED.enabled,version=global_portal_rails.version+1,updated_by=EXCLUDED.updated_by,updated_at=now() RETURNING *`,[body.railKey,body.marketId||null,body.titleAr,body.titleEn||null,String(body.rankingCode||'NEWEST').toUpperCase(),Math.min(100,Math.max(1,Number(body.maxItems||12))),JSON.stringify(body.filterJson||{}),Number(body.sortOrder||0),body.enabled!==false,actorId]); return r.rows[0];
}
export async function createPortalAd(actorId,body){
  const db=await getDb();
  const marketId=body.marketId||null;
  const providerId=body.providerId||null;
  if(providerId){
    if(!marketId) throw fail('MARKET_REQUIRED_FOR_PROVIDER_AD');
    const m=await db.query(`SELECT 1 FROM hala.market_provider_memberships mm JOIN hala.markets m ON m.id=mm.market_id JOIN hala.providers p ON p.id=mm.provider_id WHERE mm.market_id=$1 AND mm.provider_id=$2 AND mm.status='ACTIVE' AND m.status='ACTIVE' AND m.is_deleted=false AND p.status='active'`,[marketId,providerId]);
    if(!m.rowCount) throw fail('PROVIDER_NOT_ACTIVE_IN_MARKET',409);
  }
  if(!body.title || !String(body.title).trim()) throw fail('AD_TITLE_REQUIRED');
  if(!body.placement || !String(body.placement).trim()) throw fail('AD_PLACEMENT_REQUIRED');
  const r=await db.query(`INSERT INTO hala.global_portal_ads(market_id,provider_id,advertiser_name,title,body,asset_url,target_path,placement,status,start_at,end_at,approved_by,approved_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,'APPROVED',$9,$10,$11,now()) RETURNING *`,[marketId,providerId,body.advertiserName||null,String(body.title).trim(),body.body||null,safeUrl(body.assetUrl||null),safeUrl(body.targetPath||null,{path:true}),String(body.placement).trim(),body.startAt||null,body.endAt||null,actorId]); return r.rows[0];
}
