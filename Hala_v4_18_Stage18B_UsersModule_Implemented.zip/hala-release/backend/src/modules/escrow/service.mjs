import { getDb } from '../../common/db.mjs';
import { superviseInTransaction } from '../ai/supervisor.mjs';
import { randomUUID } from 'node:crypto';
const fail=(code,status=400)=>Object.assign(new Error(code),{status,code});

async function resolveBookingParties(c,bookingId){
 const q=await c.query(`SELECT b.*,p.id provider_id,p.user_id provider_user_id,p.business_name,
   COALESCE(ul.market_id,svc.market_id,b.market_id) market_id,
   COALESCE(ul.provider_id,svc.provider_id) resolved_provider_id
  FROM hala.bookings b
  LEFT JOIN hala.universal_listings ul ON ul.id=b.universal_listing_id
  LEFT JOIN LATERAL (SELECT so.provider_id,s.market_id FROM hala.booking_wishes bw JOIN hala.service_offers so ON so.id=bw.offer_id JOIN hala.services s ON s.id=so.service_id WHERE bw.booking_id=b.id ORDER BY bw.wish_rank LIMIT 1) svc ON true
  LEFT JOIN hala.providers p ON p.id=COALESCE(ul.provider_id,svc.provider_id)
  WHERE b.id=$1`,[bookingId]);
 if(!q.rowCount)throw fail('BOOKING_NOT_FOUND',404);
 return q.rows[0];
}
async function allowed(c,actorId,bookingId){
 const row=await resolveBookingParties(c,bookingId);
 if(row.customer_id!==actorId&&row.provider_user_id!==actorId) {
  const a=await c.query(`SELECT 1 FROM hala.user_roles ur JOIN hala.roles r ON r.id=ur.role_id WHERE ur.user_id=$1 AND lower(r.name) IN ('admin','finance','agent')`,[actorId]);
  if(!a.rowCount)throw fail('FORBIDDEN',403);
 }
 return row;
}
async function ensureAccount(c,code,name,type){const r=await c.query(`INSERT INTO hala.ledger_accounts(account_code,account_name,account_type) VALUES($1,$2,$3) ON CONFLICT(account_code) DO UPDATE SET account_name=EXCLUDED.account_name RETURNING id`,[code,name,type]);return r.rows[0].id;}
async function resolveAgent(c,booking){
 const direct=await c.query(`SELECT maa.agent_id,maa.directorate_location_id,a.user_id FROM hala.market_agent_assignments maa JOIN hala.agents a ON a.id=maa.agent_id WHERE maa.market_id=$1 AND maa.status='ACTIVE' AND maa.directorate_location_id IS NULL LIMIT 1`,[booking.market_id]);
 let locationId=null;
 const loc=await c.query(`SELECT ul.location_id FROM hala.user_locations ul WHERE ul.user_id=$1`,[booking.customer_id]);
 if(loc.rowCount){
  const r=await c.query(`WITH RECURSIVE chain AS (SELECT l.id,l.parent_id,gl.code FROM hala.locations l JOIN hala.geographic_levels gl ON gl.id=l.level_id WHERE l.id=$1 UNION ALL SELECT p.id,p.parent_id,gl.code FROM hala.locations p JOIN chain c ON c.parent_id=p.id JOIN hala.geographic_levels gl ON gl.id=p.level_id) SELECT id FROM chain WHERE code='directorate' LIMIT 1`,[loc.rows[0].location_id]);
  locationId=r.rows[0]?.id||null;
 }
 if(locationId){
  const r=await c.query(`SELECT maa.agent_id,maa.directorate_location_id,a.user_id FROM hala.market_agent_assignments maa JOIN hala.agents a ON a.id=maa.agent_id WHERE maa.market_id=$1 AND maa.status='ACTIVE' AND maa.directorate_location_id=$2 LIMIT 1`,[booking.market_id,locationId]);
  if(r.rowCount)return r.rows[0];
 }
 if(direct.rowCount)return direct.rows[0];
 throw fail('AGENT_ASSIGNMENT_REQUIRED',409);
}
async function commissionRule(c,booking){
 const r=await c.query(`SELECT cr.* FROM hala.commission_rules cr
  JOIN hala.market_provider_memberships mm ON mm.market_id=$1 AND mm.provider_id=$2 AND mm.status='ACTIVE'
  WHERE cr.active=true AND cr.is_exclusive = CASE WHEN COALESCE(mm.metadata->>'exclusive','false') IN ('true','1') THEN true ELSE false END
  ORDER BY cr.is_exclusive DESC,cr.id LIMIT 1`,[booking.market_id,booking.resolved_provider_id]);
 if(!r.rowCount)throw fail('COMMISSION_RULE_NOT_CONFIGURED',500);
 return r.rows[0];
}
async function postSettlementLedger(c,settlement,escrow,rule,agent){
 const cash=await ensureAccount(c,'HALA_CASH_CLEARING','Hala Cash Clearing','asset');
 const escrowAcc=await ensureAccount(c,'CUSTOMER_ESCROW_FUNDS','Customer Escrow Funds','liability');
 const providerPayable=await ensureAccount(c,'PROVIDER_PAYABLE','Provider Payable','liability');
 const platformRevenue=await ensureAccount(c,'HALA_PLATFORM_REVENUE','Hala Platform Revenue','revenue');
 const agentPayable=await ensureAccount(c,'AGENT_PAYABLE','Agent Payable','liability');
 const e=await c.query(`INSERT INTO hala.ledger_entries(reference_type,reference_id,description) VALUES('FINANCIAL_SETTLEMENT',$1,$2) RETURNING id`,[settlement.id,`Settlement for booking ${settlement.booking_id}`]);
 const lines=[
  [escrowAcc,'debit',settlement.gross_amount],
  [providerPayable,'credit',settlement.provider_amount],
  [platformRevenue,'credit',settlement.platform_amount],
  [agentPayable,'credit',settlement.agent_amount]
 ].filter(x=>Number(x[2])>0);
 for(const [account,side,amount] of lines) await c.query(`INSERT INTO hala.ledger_entry_lines(entry_id,account_id,side,amount,currency) VALUES($1,$2,$3,$4,$5)`,[e.rows[0].id,account,side,amount,settlement.currency_code]);
 return e.rows[0].id;
}
async function creditWallet(c,userId,amount,referenceId,type,currency='YER'){
 if(!(Number(amount)>0))return null;
 const w=await c.query(`INSERT INTO hala.wallets(owner_user_id,currency,status) VALUES($1,$2,'active') ON CONFLICT(owner_user_id,currency) DO UPDATE SET status='active' RETURNING id`,[userId,currency]);
 const tx=await c.query(`INSERT INTO hala.wallet_transactions(wallet_id,amount,transaction_type,reference_type,reference_id) VALUES($1,$2,$3,'financial_settlement',$4) RETURNING id`,[w.rows[0].id,amount,type,referenceId]);
 return tx.rows[0].id;
}
export async function getEscrow(actorId,bookingId){const db=await getDb();const c=await db.connect();try{await allowed(c,actorId,bookingId);const r=await c.query('SELECT * FROM hala.escrow_accounts WHERE booking_id=$1',[bookingId]);return r.rows[0]||null}finally{c.release()}}

export async function releaseEscrow(actorId,bookingId,amount,ctx={}){
 if(!(Number(amount)>0))throw fail('INVALID_ESCROW_AMOUNT');
 const db=await getDb();const c=await db.connect();
 try{
  await c.query('BEGIN');
  const booking=await allowed(c,actorId,bookingId);
  if(!['COMPLETED','RESOLVED'].includes(String(booking.lifecycle_status))) throw fail('ESCROW_RELEASE_NOT_ALLOWED',409);
  const q=await c.query('SELECT * FROM hala.escrow_accounts WHERE booking_id=$1 FOR UPDATE',[bookingId]); if(!q.rowCount)throw fail('ESCROW_NOT_FOUND',404);
  const e=q.rows[0]; if(Number(e.held_amount)+0.000001 < Number(booking.total_amount)) throw fail('ESCROW_NOT_FULLY_FUNDED',409); const available=Number(e.held_amount)-Number(e.released_amount)-Number(e.refunded_amount); if(amount>available+0.000001)throw fail('ESCROW_INSUFFICIENT',409);
  if(ctx.idempotencyKey){const ex=await c.query(`SELECT response_body FROM hala.idempotency_records WHERE actor_user_id=$1 AND idempotency_key=$2 AND route='POST /api/v1/bookings/escrow/release'`,[actorId,ctx.idempotencyKey]);if(ex.rowCount){await c.query('COMMIT');return ex.rows[0].response_body;}}
  const rule=await commissionRule(c,booking); const agent=await resolveAgent(c,booking);
  const platformAmount=Math.round(amount*Number(rule.platform_rate)/100*100)/100;
  const agentAmount=Math.round(amount*Number(rule.agent_rate)/100*100)/100;
  const providerAmount=Math.round((amount-platformAmount-agentAmount)*100)/100;
  if(providerAmount<0)throw fail('COMMISSION_EXCEEDS_GROSS',500);
  const settlementKey=ctx.idempotencyKey||null;
  const s=await c.query(`INSERT INTO hala.financial_settlements(booking_id,escrow_account_id,gross_amount,platform_amount,agent_amount,provider_amount,currency_code,commission_rule_id,agent_id,provider_id,status,idempotency_key) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'POSTED',$11) RETURNING *`,[bookingId,e.id,amount,platformAmount,agentAmount,providerAmount,booking.currency_code||'YER',rule.id,agent.agent_id,booking.resolved_provider_id,settlementKey]);
  await postSettlementLedger(c,s.rows[0],e,rule,agent);
  await c.query(`INSERT INTO hala.booking_commissions(booking_id,rule_id,gross_amount,platform_amount,agent_amount,provider_amount,currency_code) VALUES($1,$2,$3,$4,$5,$6,$7)`,[bookingId,rule.id,amount,platformAmount,agentAmount,providerAmount,booking.currency_code||'YER']);
  await creditWallet(c,booking.provider_user_id,providerAmount,s.rows[0].id,'PROVIDER_EARNINGS',booking.currency_code||'YER');
  await creditWallet(c,agent.user_id,agentAmount,s.rows[0].id,'AGENT_COMMISSION',booking.currency_code||'YER');
  const r=await c.query(`UPDATE hala.escrow_accounts SET released_amount=released_amount+$2,status=CASE WHEN released_amount+$2+refunded_amount>=held_amount THEN 'released' ELSE status END WHERE booking_id=$1 RETURNING *`,[bookingId,amount]);
  if(ctx.idempotencyKey)await c.query(`INSERT INTO hala.idempotency_records(actor_user_id,idempotency_key,route,request_hash,response_status,response_body,expires_at) VALUES($1,$2,'POST /api/v1/bookings/escrow/release','not-computed',200,$3::jsonb,now()+interval '24 hours')`,[actorId,ctx.idempotencyKey,JSON.stringify(r.rows[0])]);
  await superviseInTransaction(c,{eventKey:'escrow.released',marketId:booking.market_id,resourceType:'financial_settlement',resourceId:s.rows[0].id,actorId,payload:{bookingId,amount,platformAmount,agentAmount,providerAmount,agentId:agent.agent_id,providerId:booking.resolved_provider_id}});
  await c.query('COMMIT'); return r.rows[0];
 }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}
export async function refundEscrow(actorId,bookingId,amount,ctx={}){
 if(!(Number(amount)>0))throw fail('INVALID_ESCROW_AMOUNT'); const db=await getDb(); const c=await db.connect();
 try{await c.query('BEGIN'); const booking=await allowed(c,actorId,bookingId); const q=await c.query('SELECT * FROM hala.escrow_accounts WHERE booking_id=$1 FOR UPDATE',[bookingId]); if(!q.rowCount)throw fail('ESCROW_NOT_FOUND',404); const e=q.rows[0]; const available=Number(e.held_amount)-Number(e.released_amount)-Number(e.refunded_amount); if(Number(amount)>available+0.000001)throw fail('ESCROW_INSUFFICIENT',409);
   if(ctx.idempotencyKey){const ex=await c.query(`SELECT response_body FROM hala.idempotency_records WHERE actor_user_id=$1 AND idempotency_key=$2 AND route='POST /api/v1/bookings/escrow/refund'`,[actorId,ctx.idempotencyKey]);if(ex.rowCount){await c.query('COMMIT');return ex.rows[0].response_body;}}
   const cash=await ensureAccount(c,'HALA_CASH_CLEARING','Hala Cash Clearing','asset'); const esc=await ensureAccount(c,'CUSTOMER_ESCROW_FUNDS','Customer Escrow Funds','liability');
   const sid=randomUUID(); const entry=await c.query(`INSERT INTO hala.ledger_entries(reference_type,reference_id,description) VALUES('ESCROW_REFUND',$1,$2) RETURNING id`,[sid,`Escrow refund for ${bookingId}`]); await c.query(`INSERT INTO hala.ledger_entry_lines(entry_id,account_id,side,amount,currency) VALUES($1,$2,'debit',$3,$4),($1,$5,'credit',$3,$4)`,[entry.rows[0].id,esc,Number(amount),booking.currency_code||'YER',cash]);
   const r=await c.query(`UPDATE hala.escrow_accounts SET refunded_amount=refunded_amount+$2,status=CASE WHEN released_amount+refunded_amount+$2>=held_amount THEN 'refunded' ELSE status END WHERE booking_id=$1 RETURNING *`,[bookingId,Number(amount)]);
   if(ctx.idempotencyKey)await c.query(`INSERT INTO hala.idempotency_records(actor_user_id,idempotency_key,route,request_hash,response_status,response_body,expires_at) VALUES($1,$2,'POST /api/v1/bookings/escrow/refund','not-computed',200,$3::jsonb,now()+interval '24 hours')`,[actorId,ctx.idempotencyKey,JSON.stringify(r.rows[0])]);
   await superviseInTransaction(c,{eventKey:'escrow.refunded',marketId:booking.market_id,resourceType:'booking',resourceId:bookingId,actorId,payload:{bookingId,amount:Number(amount)}});
   await c.query('COMMIT'); return r.rows[0];
 }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}
