import {getDb} from '../../common/db.mjs';
export async function userNotifications(userId){ const db=await getDb(); const r=await db.query('SELECT * FROM hala.notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[userId]); return r.rows; }
