import { plainToInstance } from 'class-transformer';
import {
  IsBooleanString,
  IsInt,
  IsOptional,
  IsString,
  Min,
  validateSync,
} from 'class-validator';

class EnvironmentVariables {
  @IsOptional()
  @IsString()
  NODE_ENV?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  PORT?: number;

  @IsOptional()
  @IsString()
  DATABASE_URL?: string;

  @IsOptional()
  @IsString()
  DB_HOST?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  DB_PORT?: number;

  @IsOptional()
  @IsString()
  DB_NAME?: string;

  @IsOptional()
  @IsString()
  DB_USER?: string;

  @IsOptional()
  @IsString()
  DB_PASSWORD?: string;

  @IsOptional()
  @IsString()
  HALA_CORS_ORIGINS?: string;

  @IsOptional()
  @IsBooleanString()
  HALA_ALLOW_DEV_ACTOR_HEADER?: string;

  @IsOptional()
  @IsBooleanString()
  HALA_DEV_OTP?: string;

  @IsOptional()
  @IsString()
  PGHOST?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  PGPORT?: number;

  @IsOptional()
  @IsString()
  PGDATABASE?: string;

  @IsOptional()
  @IsString()
  PGUSER?: string;

  @IsOptional()
  @IsString()
  PGPASSWORD?: string;
}

export function validateEnv(config: Record<string, unknown>) {
  const validated = plainToInstance(EnvironmentVariables, config, {
    enableImplicitConversion: true,
  });

  const errors = validateSync(validated, {
    skipMissingProperties: true,
    forbidUnknownValues: true,
  });

  if (errors.length > 0) {
    const details = errors.map((error) => Object.values(error.constraints ?? {})).flat();
    throw new Error(`Invalid environment: ${details.join('; ')}`);
  }

  const nodeEnv = String(config.NODE_ENV ?? 'development');
  if (nodeEnv === 'production') {
    if (String(config.HALA_DEV_OTP).toLowerCase() === 'true') {
      throw new Error('HALA_DEV_OTP must be false in production');
    }
    if (String(config.HALA_ALLOW_DEV_ACTOR_HEADER).toLowerCase() === 'true') {
      throw new Error('HALA_ALLOW_DEV_ACTOR_HEADER must be false in production');
    }
  }

  return config;
}
