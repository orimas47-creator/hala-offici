import 'reflect-metadata';
import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import helmet from 'helmet';
import express from 'express';
import { AppModule } from './app.module.js';
import { HalaExceptionFilter } from './common/filters/hala-exception.filter.js';
import { RequestIdInterceptor } from './common/interceptors/request-id.interceptor.js';
import { HalaAuthGuard } from './common/guards/hala-auth.guard.js';

const DEFAULT_PORT = 8080;
const REQUEST_TIMEOUT_MS = 30_000;
const HEADERS_TIMEOUT_MS = 10_000;
const KEEP_ALIVE_TIMEOUT_MS = 5_000;

function readPort(value: string | undefined): number {
  const port = Number(value ?? DEFAULT_PORT);
  if (!Number.isInteger(port) || port < 1 || port > 65_535) {
    throw new Error(`Invalid PORT: ${value}`);
  }
  return port;
}

function readCorsOrigins(value: string | undefined): string[] {
  return (value ?? '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

async function bootstrap(): Promise<void> {
  const nodeEnv = process.env.NODE_ENV ?? 'development';
  const port = readPort(process.env.PORT);

  if (nodeEnv === 'production') {
    if (process.env.HALA_ALLOW_DEV_ACTOR_HEADER === 'true') {
      throw new Error('HALA_ALLOW_DEV_ACTOR_HEADER must be false in production');
    }
    if (process.env.HALA_DEV_OTP === 'true') {
      throw new Error('HALA_DEV_OTP must be false in production');
    }
  }

  const app = await NestFactory.create(AppModule, {
    cors: false,
    bodyParser: false,
  });
  app.use(express.json({ limit: '1mb', strict: true }));
  app.use(express.urlencoded({ limit: '256kb', extended: false }));

  // Backend/API security headers. CSP is intentionally enabled for the API
  // runtime; the customer UI is served separately and can define its own CSP.
  app.use(
    helmet({
      crossOriginEmbedderPolicy: false,
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'none'"],
          frameAncestors: ["'none'"],
          baseUri: ["'none'"],
          formAction: ["'none'"],
          objectSrc: ["'none'"],
        },
      },
    }),
  );

  const allowedOrigins = readCorsOrigins(process.env.HALA_CORS_ORIGINS);
  app.enableCors({
    origin: allowedOrigins.length > 0 ? allowedOrigins : false,
    credentials: true,
    methods: ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: [
      'Content-Type',
      'Authorization',
      'X-Request-Id',
      'Idempotency-Key',
      'X-Actor-Id',
    ],
    exposedHeaders: ['X-Request-Id'],
    maxAge: 600,
  });

  app.useGlobalInterceptors(new RequestIdInterceptor());
  app.useGlobalGuards(new HalaAuthGuard());
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      stopAtFirstError: false,
      transformOptions: { enableImplicitConversion: false },
    }),
  );
  app.useGlobalFilters(new HalaExceptionFilter());
  app.enableShutdownHooks();

  const httpAdapter = app.getHttpAdapter();
  const httpServer = httpAdapter.getHttpServer() as {
    requestTimeout?: number;
    headersTimeout?: number;
    keepAliveTimeout?: number;
  };
  httpServer.requestTimeout = REQUEST_TIMEOUT_MS;
  httpServer.headersTimeout = HEADERS_TIMEOUT_MS;
  httpServer.keepAliveTimeout = KEEP_ALIVE_TIMEOUT_MS;

  await app.listen(port);
  console.log(`Hala NestJS Backend v4.18 listening on :${port} (${nodeEnv})`);
}

bootstrap().catch((error: unknown) => {
  console.error('Hala NestJS bootstrap failed', error);
  process.exitCode = 1;
});
