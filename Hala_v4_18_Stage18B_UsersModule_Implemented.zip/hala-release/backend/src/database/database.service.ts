import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class DatabaseService {
  constructor(private readonly dataSource: DataSource) {}

  isConnected(): boolean {
    return this.dataSource.isInitialized;
  }

  async ping(): Promise<{ now: string }> {
    const rows = await this.dataSource.query('SELECT NOW() AS now');
    return { now: String(rows[0]?.now ?? '') };
  }
}
