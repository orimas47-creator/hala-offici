import { Global, Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import type { DataSourceOptions } from 'typeorm';
import { DatabaseService } from './database.service.js';

function firstDefined(...values: Array<string | undefined>): string | undefined {
  return values.find((value) => value !== undefined && value !== '');
}

function asBoolean(value: string | undefined, fallback = false): boolean {
  if (value === undefined) return fallback;
  return value.trim().toLowerCase() === 'true';
}

export function buildDatabaseOptions(config: ConfigService): DataSourceOptions {
  const url = firstDefined(config.get<string>('DATABASE_URL'));
  const host = firstDefined(config.get<string>('DB_HOST'), config.get<string>('PGHOST'));
  const port = Number(firstDefined(config.get<string>('DB_PORT'), config.get<string>('PGPORT'), '5432'));
  const database = firstDefined(config.get<string>('DB_NAME'), config.get<string>('PGDATABASE'));
  const username = firstDefined(config.get<string>('DB_USER'), config.get<string>('PGUSER'));
  const password = firstDefined(config.get<string>('DB_PASSWORD'), config.get<string>('PGPASSWORD'));

  if (!url && (!host || !database || !username)) {
    throw new Error(
      'Database configuration is incomplete: set DATABASE_URL or DB_HOST/DB_NAME/DB_USER.',
    );
  }

  const ssl = asBoolean(config.get<string>('DB_SSL'), false)
    ? { rejectUnauthorized: asBoolean(config.get<string>('DB_SSL_REJECT_UNAUTHORIZED'), true) }
    : false;

  return {
    type: 'postgres',
    ...(url ? { url } : { host, port, database, username, password }),
    ssl,
    synchronize: false,
    migrationsRun: false,
    autoLoadEntities: true,
    logging: config.get<string>('DB_LOGGING') === 'true' ? ['error', 'warn'] : ['error'],
    applicationName: 'hala-backend',
    extra: {
      max: Number(config.get<string>('PGPOOL_MAX') ?? 10),
      idleTimeoutMillis: Number(config.get<string>('PGPOOL_IDLE_TIMEOUT_MS') ?? 30_000),
      connectionTimeoutMillis: Number(config.get<string>('PGCONNECT_TIMEOUT_MS') ?? 5_000),
    },
  };
}

@Global()
@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => buildDatabaseOptions(config),
    }),
  ],
  providers: [DatabaseService],
  exports: [DatabaseService],
})
export class DatabaseModule {}
