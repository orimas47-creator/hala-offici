import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus } from '@nestjs/common';
import { Response } from 'express';

@Catch()
export class HalaExceptionFilter implements ExceptionFilter {
  catch(error: unknown, host: ArgumentsHost) {
    const res = host.switchToHttp().getResponse<Response>();
    const req = host.switchToHttp().getRequest<{ halaContext?: { requestId?: string } }>();
    const requestId = req.halaContext?.requestId ?? res.getHeader('x-request-id')?.toString() ?? 'unknown';
    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let code = 'INTERNAL_ERROR';
    if (error instanceof HttpException) {
      status = error.getStatus();
      const body = error.getResponse();
      if (typeof body === 'string') code = body;
      else if (body && typeof body === 'object' && 'error' in body) code = String((body as { error: unknown }).error);
    } else if (error && typeof error === 'object' && 'status' in error) {
      status = Number((error as { status: unknown }).status) || status;
      if ('code' in error) code = String((error as { code: unknown }).code);
    }
    res.status(status).json({ error: code, requestId });
  }
}
