import { pingDb as legacyPingDb } from './db.mjs';
export async function pingDb() { return legacyPingDb(); }
