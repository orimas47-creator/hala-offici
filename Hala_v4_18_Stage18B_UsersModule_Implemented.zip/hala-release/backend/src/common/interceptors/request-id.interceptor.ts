import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { Observable } from 'rxjs';
import type { AuthRequestContext } from '../../modules/auth/auth.types.js';

@Injectable()
export class RequestIdInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const req = context.switchToHttp().getRequest<any>();
    const res = context.switchToHttp().getResponse<any>();
    const existing = req.halaContext as AuthRequestContext | undefined;
    const requestId = String(existing?.requestId || req.headers['x-request-id'] || randomUUID());

    req.halaContext = {
      requestId,
      actorId: existing?.actorId ?? null,
      authType: existing?.authType ?? 'none',
      authorization: existing?.authorization ?? req.headers.authorization,
      origin: existing?.origin ?? req.headers.origin ?? null,
      ip: existing?.ip ?? req.ip ?? req.socket?.remoteAddress ?? null,
      userAgent: existing?.userAgent ?? String(req.headers['user-agent'] || '').slice(0, 1000),
      legacyActorId: existing?.legacyActorId ?? req.headers['x-actor-id'] ?? null,
    } satisfies AuthRequestContext;

    res.setHeader('x-request-id', requestId);
    return next.handle();
  }
}
