import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { AuthService } from '../../modules/auth/auth.service.js';
import type { AuthRequestContext } from '../../modules/auth/auth.types.js';

@Injectable()
export class HalaAuthGuard implements CanActivate {
  constructor(private readonly auth: AuthService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest<any>();
    const requestId = String(req.headers['x-request-id'] || randomUUID());
    const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    const ctx: AuthRequestContext = {
      requestId,
      actorId: null,
      authType: 'none',
      authorization: req.headers.authorization,
      origin: req.headers.origin ?? null,
      ip: forwarded || req.ip || req.socket?.remoteAddress || null,
      userAgent: String(req.headers['user-agent'] || '').slice(0, 1000),
      legacyActorId: req.headers['x-actor-id'] ?? null,
    };

    req.halaContext = await this.auth.authenticate(ctx);
    return true;
  }
}

@Injectable()
export class RequireActorGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest<any>();
    if (!req.halaContext?.actorId) throw new UnauthorizedException('ACTOR_REQUIRED');
    return true;
  }
}
