import { randomUUID, createHash } from 'node:crypto';

function originAllowed(origin) {
  const configured = (process.env.CORS_ORIGIN || '').split(',').map(s=>s.trim()).filter(Boolean);
  if (!origin) return configured[0] || '';
  if (configured.length === 0) return process.env.NODE_ENV === 'production' ? '' : origin;
  return configured.includes(origin) ? origin : '';
}

export function json(res, status, body, extra={}) {
  const origin = extra['access-control-allow-origin'] || res._halaOrigin || '';
  const headers = {
    'content-type':'application/json; charset=utf-8',
    'x-content-type-options':'nosniff',
    'x-frame-options':'DENY',
    'referrer-policy':'no-referrer',
    'cache-control':'no-store',
    'permissions-policy':'camera=(), microphone=(), geolocation=(self)',
    'access-control-allow-methods':'GET,POST,PATCH,DELETE,OPTIONS',
    'access-control-allow-headers':'Content-Type, X-Request-Id, X-Actor-Id, Idempotency-Key, Authorization',
    'access-control-max-age':'600',
    ...(origin ? {'access-control-allow-origin':origin,'vary':'Origin'} : {}),
    ...extra,
  };
  res.writeHead(status, headers);
  res.end(JSON.stringify(body));
}

export async function readJson(req, maxBytes=1024*1024) {
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > maxBytes) throw Object.assign(new Error('PAYLOAD_TOO_LARGE'), {status:413, code:'PAYLOAD_TOO_LARGE'});
  const chunks=[]; let size=0;
  for await (const c of req) {
    size += c.length;
    if (size > maxBytes) throw Object.assign(new Error('PAYLOAD_TOO_LARGE'), {status:413, code:'PAYLOAD_TOO_LARGE'});
    chunks.push(c);
  }
  const raw=Buffer.concat(chunks).toString('utf8');
  if (!raw) return {};
  try { return JSON.parse(raw); } catch { throw Object.assign(new Error('INVALID_JSON'), {status:400, code:'INVALID_JSON'}); }
}

export function requestContext(req) {
  const forwarded = String(req.headers['x-forwarded-for']||'').split(',')[0].trim();
  return {
    requestId:req.headers['x-request-id'] || randomUUID(),
    idempotencyKey:req.headers['idempotency-key'] || null,
    legacyActorId:req.headers['x-actor-id'] || null,
    authorization:req.headers.authorization || null,
    ip: forwarded || req.socket.remoteAddress || null,
    userAgent: String(req.headers['user-agent']||'').slice(0,1000),
  };
}

export function allowedOrigin(req){ return originAllowed(req.headers.origin); }
export function hashToken(token){ return createHash('sha256').update(String(token)).digest('hex'); }
