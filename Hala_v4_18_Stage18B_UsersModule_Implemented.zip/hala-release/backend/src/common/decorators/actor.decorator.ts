import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { AuthRequestContext } from '../../modules/auth/auth.types.js';

export type HalaRequestContext = AuthRequestContext;

export const ActorContext = createParamDecorator((_data: unknown, ctx: ExecutionContext): HalaRequestContext => {
  const req = ctx.switchToHttp().getRequest<{ halaContext?: HalaRequestContext }>();
  return req.halaContext ?? { requestId: 'unknown', actorId: null, authType: 'none' };
});
