let pool = null;
export async function getDb() {
  if (pool) return pool;
  let pg;
  try { pg = await import('pg'); } catch { throw Object.assign(new Error('PG_DRIVER_NOT_INSTALLED'), {status:503}); }
  const { Pool } = pg;
  pool = new Pool({connectionString:process.env.DATABASE_URL || undefined, host:process.env.PGHOST, port:process.env.PGPORT, database:process.env.PGDATABASE, user:process.env.PGUSER, password:process.env.PGPASSWORD, max:Number(process.env.PGPOOL_MAX||10)});
  return pool;
}
export async function pingDb(){ const db=await getDb(); return db.query('select now() as now'); }
