-- Hala v4.14 Universal Booking Bridge
BEGIN;
SET search_path TO hala, public;

ALTER TABLE bookings ALTER COLUMN service_id DROP NOT NULL;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS market_id UUID REFERENCES markets(id);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS universal_listing_id UUID REFERENCES universal_listings(id);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS operation_type VARCHAR(40);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS currency_code VARCHAR(3) NOT NULL DEFAULT 'YER';

ALTER TABLE booking_wishes ALTER COLUMN offer_id DROP NOT NULL;
ALTER TABLE booking_wishes ADD COLUMN IF NOT EXISTS listing_id UUID REFERENCES universal_listings(id);

ALTER TABLE bookings DROP CONSTRAINT IF EXISTS chk_booking_source;
ALTER TABLE bookings ADD CONSTRAINT chk_booking_source CHECK (service_id IS NOT NULL OR universal_listing_id IS NOT NULL);
ALTER TABLE bookings DROP CONSTRAINT IF EXISTS chk_booking_operation_type;
ALTER TABLE bookings ADD CONSTRAINT chk_booking_operation_type CHECK (operation_type IS NULL OR operation_type IN ('BUY','RENT','BUY_OR_RENT','SERVICE','QUOTE'));
ALTER TABLE booking_wishes DROP CONSTRAINT IF EXISTS chk_booking_wish_source;
ALTER TABLE booking_wishes ADD CONSTRAINT chk_booking_wish_source CHECK (offer_id IS NOT NULL OR listing_id IS NOT NULL);

CREATE INDEX IF NOT EXISTS idx_bookings_market_listing ON bookings(market_id,universal_listing_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_booking_wishes_listing ON booking_wishes(listing_id,booking_id);

INSERT INTO policy_configs(key,value_json,description) VALUES
('booking.universal_listing_bridge','true','الحجز الموحد يدعم عروض الأسواق الديناميكية دون إنشاء جداول جديدة لكل سوق'),
('booking.require_server_pricing','true','الأسعار والإجماليات تحسب على الخادم ولا يثق النظام بإجمالي العميل'),
('booking.require_active_market','true','كل حجز لسوق ديناميكي يجب أن يكون في سوق نشط وغير محذوف')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;

COMMIT;
