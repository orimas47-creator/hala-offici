-- Hala Platform Unified Database v4.3
-- PostgreSQL + PostGIS
-- هدف هذا الإصدار: توسيع النواة لتدعم الأسواق الديناميكية، صوت العميل، تقييم الوكلاء،
-- المصنعين والتجارة الدولية، مع الحفاظ على قاعدة v1/v4.2 وعدم إنشاء قاعدة مستقلة لكل سوق.
BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS postgis;
SET search_path TO hala, public;

-- =========================================================
-- 1) Dynamic Markets / Sections / Attributes
-- =========================================================
CREATE TABLE IF NOT EXISTS markets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_key VARCHAR(120) NOT NULL UNIQUE,
  name_ar VARCHAR(250) NOT NULL,
  name_en VARCHAR(250),
  description TEXT,
  status VARCHAR(30) NOT NULL DEFAULT 'draft',
  configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
  compliance_profile JSONB NOT NULL DEFAULT '{}'::jsonb,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status IN ('draft','review','active','suspended','archived'))
);

ALTER TABLE categories ADD COLUMN IF NOT EXISTS market_id UUID REFERENCES markets(id);
ALTER TABLE services ADD COLUMN IF NOT EXISTS market_id UUID REFERENCES markets(id);

CREATE TABLE IF NOT EXISTS market_sections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  parent_id UUID REFERENCES market_sections(id),
  section_key VARCHAR(160) NOT NULL,
  name_ar VARCHAR(250) NOT NULL,
  name_en VARCHAR(250),
  configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(market_id, section_key)
);

CREATE TABLE IF NOT EXISTS attribute_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id) ON DELETE CASCADE,
  section_id UUID REFERENCES market_sections(id) ON DELETE CASCADE,
  attribute_key VARCHAR(160) NOT NULL,
  name_ar VARCHAR(250) NOT NULL,
  data_type VARCHAR(30) NOT NULL DEFAULT 'text',
  unit VARCHAR(60),
  required BOOLEAN NOT NULL DEFAULT FALSE,
  options_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  validation_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(market_id, section_id, attribute_key),
  CHECK (data_type IN ('text','number','decimal','integer','boolean','date','datetime','choice','multi_choice','json'))
);

-- العرض القديم offer_attributes يبقى للتوافق؛ هذه الطبقة تضيف تعريفًا ديناميكيًا للحقول.
ALTER TABLE offer_attributes ADD COLUMN IF NOT EXISTS attribute_key VARCHAR(160);
ALTER TABLE offer_attributes ADD COLUMN IF NOT EXISTS value_json JSONB;
ALTER TABLE offer_attributes ADD COLUMN IF NOT EXISTS template_id UUID REFERENCES attribute_templates(id);

-- =========================================================
-- 2) Manufacturer / Supplier / Trader / Company / International Trade
-- =========================================================
CREATE TABLE IF NOT EXISTS organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_type VARCHAR(40) NOT NULL,
  legal_name VARCHAR(300) NOT NULL,
  trade_name VARCHAR(300),
  country VARCHAR(120),
  registration_number VARCHAR(150),
  tax_number VARCHAR(150),
  website TEXT,
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (organization_type IN ('factory','company','supplier','trader','store','importer','exporter','distributor','service_company','government','other'))
);

CREATE TABLE IF NOT EXISTS organization_users (
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_name VARCHAR(120) NOT NULL,
  is_primary BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(organization_id,user_id)
);

ALTER TABLE manufacturers ADD COLUMN IF NOT EXISTS organization_id UUID REFERENCES organizations(id);
ALTER TABLE manufacturers ADD COLUMN IF NOT EXISTS registration_number VARCHAR(150);
ALTER TABLE manufacturers ADD COLUMN IF NOT EXISTS verification_status VARCHAR(30) NOT NULL DEFAULT 'pending';

CREATE TABLE IF NOT EXISTS offer_supply_chain (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id UUID NOT NULL REFERENCES service_offers(id) ON DELETE CASCADE,
  manufacturer_id UUID REFERENCES manufacturers(id),
  source_organization_id UUID REFERENCES organizations(id),
  distributor_organization_id UUID REFERENCES organizations(id),
  importer_organization_id UUID REFERENCES organizations(id),
  exporter_organization_id UUID REFERENCES organizations(id),
  origin_country VARCHAR(120),
  source_country VARCHAR(120),
  destination_country VARCHAR(120),
  supply_role VARCHAR(40) NOT NULL DEFAULT 'source',
  verification_status VARCHAR(30) NOT NULL DEFAULT 'pending',
  verification_evidence JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (supply_role IN ('manufacturer','source','distributor','importer','exporter','agent','other'))
);
CREATE INDEX IF NOT EXISTS idx_offer_supply_chain_offer ON offer_supply_chain(offer_id);

CREATE TABLE IF NOT EXISTS trade_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_reference VARCHAR(120) NOT NULL UNIQUE,
  market_id UUID REFERENCES markets(id),
  buyer_organization_id UUID REFERENCES organizations(id),
  seller_organization_id UUID REFERENCES organizations(id),
  manufacturer_id UUID REFERENCES manufacturers(id),
  direction VARCHAR(20) NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'draft',
  currency VARCHAR(10) NOT NULL DEFAULT 'YER',
  total_amount NUMERIC(20,4) NOT NULL DEFAULT 0,
  terms_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (direction IN ('import','export','domestic_wholesale','domestic_retail'))
);

CREATE TABLE IF NOT EXISTS trade_order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_order_id UUID NOT NULL REFERENCES trade_orders(id) ON DELETE CASCADE,
  offer_id UUID REFERENCES service_offers(id),
  product_name VARCHAR(300),
  quantity NUMERIC(20,4) NOT NULL DEFAULT 1,
  unit_price NUMERIC(20,4) NOT NULL DEFAULT 0,
  attributes JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS trade_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_order_id UUID NOT NULL REFERENCES trade_orders(id) ON DELETE CASCADE,
  document_type VARCHAR(80) NOT NULL,
  document_number VARCHAR(150),
  issuer_organization_id UUID REFERENCES organizations(id),
  country VARCHAR(120),
  file_uri TEXT,
  content_hash VARCHAR(128),
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  expires_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS shipments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_order_id UUID NOT NULL REFERENCES trade_orders(id) ON DELETE CASCADE,
  carrier_organization_id UUID REFERENCES organizations(id),
  origin_country VARCHAR(120),
  destination_country VARCHAR(120),
  origin_location TEXT,
  destination_location TEXT,
  tracking_reference VARCHAR(200),
  status VARCHAR(40) NOT NULL DEFAULT 'planned',
  scheduled_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status IN ('planned','booked','in_transit','customs','delivered','delayed','cancelled'))
);

-- =========================================================
-- 3) Customer Voice: rating, complaint, report, suggestion
-- =========================================================
CREATE TABLE IF NOT EXISTS customer_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES users(id),
  booking_id UUID REFERENCES bookings(id),
  provider_id UUID REFERENCES providers(id),
  agent_id UUID REFERENCES agents(id),
  service_id UUID REFERENCES services(id),
  offer_id UUID REFERENCES service_offers(id),
  feedback_type VARCHAR(40) NOT NULL,
  rating NUMERIC(2,1),
  title VARCHAR(250),
  body TEXT NOT NULL,
  confidentiality VARCHAR(30) NOT NULL DEFAULT 'normal',
  status VARCHAR(40) NOT NULL DEFAULT 'submitted',
  ai_risk_score NUMERIC(6,5),
  assigned_to UUID REFERENCES users(id),
  resolution TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ,
  CHECK (feedback_type IN ('rating','suggestion','complaint','shortcoming','misconduct','fraud_report','security_report','financial_report','recommendation')),
  CHECK (confidentiality IN ('normal','confidential','restricted')),
  CHECK (status IN ('submitted','triaged','under_review','awaiting_response','resolved','rejected','duplicate','escalated')),
  CHECK (rating IS NULL OR rating BETWEEN 1 AND 5)
);

CREATE TABLE IF NOT EXISTS feedback_votes (
  feedback_id UUID NOT NULL REFERENCES customer_feedback(id) ON DELETE CASCADE,
  voter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  vote_value SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(feedback_id,voter_id),
  CHECK (vote_value IN (1,-1))
);

CREATE TABLE IF NOT EXISTS agent_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  reviewer_user_id UUID NOT NULL REFERENCES users(id),
  booking_id UUID REFERENCES bookings(id),
  rating NUMERIC(2,1),
  response_time_score NUMERIC(2,1),
  compliance_score NUMERIC(2,1),
  neutrality_score NUMERIC(2,1),
  followup_score NUMERIC(2,1),
  review_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (rating IS NULL OR rating BETWEEN 1 AND 5)
);

CREATE TABLE IF NOT EXISTS feedback_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feedback_id UUID NOT NULL REFERENCES customer_feedback(id) ON DELETE CASCADE,
  case_reference VARCHAR(120) NOT NULL UNIQUE,
  owner_user_id UUID REFERENCES users(id),
  status VARCHAR(40) NOT NULL DEFAULT 'open',
  findings JSONB NOT NULL DEFAULT '{}'::jsonb,
  corrective_action JSONB NOT NULL DEFAULT '{}'::jsonb,
  due_at TIMESTAMPTZ,
  closed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_customer_feedback_target ON customer_feedback(service_id,provider_id,agent_id,status,created_at);
CREATE INDEX IF NOT EXISTS idx_customer_feedback_type ON customer_feedback(feedback_type,status,created_at);
CREATE INDEX IF NOT EXISTS idx_agent_reviews_agent ON agent_reviews(agent_id,created_at);

-- =========================================================
-- 4) AI governance: advisory/guarded, no direct financial authority
-- =========================================================
CREATE TABLE IF NOT EXISTS ai_agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_key VARCHAR(120) NOT NULL UNIQUE,
  display_name VARCHAR(200) NOT NULL,
  purpose VARCHAR(120) NOT NULL,
  provider VARCHAR(120),
  model VARCHAR(160),
  mode VARCHAR(30) NOT NULL DEFAULT 'advisory',
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (mode IN ('advisory','guarded_action','disabled'))
);

CREATE TABLE IF NOT EXISTS ai_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_key VARCHAR(160) NOT NULL,
  source_module VARCHAR(120) NOT NULL,
  resource_type VARCHAR(100),
  resource_id UUID,
  actor_user_id UUID REFERENCES users(id),
  risk_score NUMERIC(6,5),
  payload_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS ai_findings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES ai_events(id) ON DELETE SET NULL,
  agent_id UUID REFERENCES ai_agents(id) ON DELETE SET NULL,
  severity VARCHAR(20) NOT NULL DEFAULT 'info',
  finding_type VARCHAR(120) NOT NULL,
  confidence NUMERIC(6,5),
  recommendation TEXT,
  evidence_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ,
  CHECK (severity IN ('info','low','medium','high','critical')),
  CHECK (status IN ('OPEN','ACKNOWLEDGED','RESOLVED','FALSE_POSITIVE','ESCALATED'))
);

CREATE TABLE IF NOT EXISTS ai_decisions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  finding_id UUID REFERENCES ai_findings(id) ON DELETE SET NULL,
  agent_id UUID REFERENCES ai_agents(id) ON DELETE SET NULL,
  decision VARCHAR(80) NOT NULL,
  decision_scope VARCHAR(80) NOT NULL,
  proposed_action JSONB NOT NULL DEFAULT '{}'::jsonb,
  applied_by_rule BOOLEAN NOT NULL DEFAULT FALSE,
  applied_by_user_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_watch_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_key VARCHAR(160) NOT NULL UNIQUE,
  event_pattern VARCHAR(200) NOT NULL,
  severity VARCHAR(20) NOT NULL DEFAULT 'medium',
  threshold_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  action_policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_report_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_type VARCHAR(100) NOT NULL,
  scope_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  period_start TIMESTAMPTZ,
  period_end TIMESTAMPTZ,
  metrics_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  recommendations_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  generated_by_agent_id UUID REFERENCES ai_agents(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =========================================================
-- 5) Legal / Contract linkage
-- =========================================================
CREATE TABLE IF NOT EXISTS contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_type VARCHAR(80) NOT NULL,
  party_a_user_id UUID REFERENCES users(id),
  party_a_organization_id UUID REFERENCES organizations(id),
  party_b_user_id UUID REFERENCES users(id),
  party_b_organization_id UUID REFERENCES organizations(id),
  booking_id UUID REFERENCES bookings(id),
  market_id UUID REFERENCES markets(id),
  status VARCHAR(30) NOT NULL DEFAULT 'draft',
  effective_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  accepted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS contract_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id UUID NOT NULL REFERENCES contracts(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  content_hash VARCHAR(128) NOT NULL,
  terms_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(contract_id,version)
);

-- =========================================================
-- 6) Safety / indexing / policy flags
-- =========================================================
CREATE INDEX IF NOT EXISTS idx_markets_status_sort ON markets(status,sort_order);
CREATE INDEX IF NOT EXISTS idx_market_sections_market ON market_sections(market_id,is_active,sort_order);
CREATE INDEX IF NOT EXISTS idx_attribute_templates_market ON attribute_templates(market_id,section_id,is_active);
CREATE INDEX IF NOT EXISTS idx_organizations_type_country ON organizations(organization_type,country,status);
CREATE INDEX IF NOT EXISTS idx_trade_orders_status_direction ON trade_orders(status,direction,created_at);
CREATE INDEX IF NOT EXISTS idx_shipments_status ON shipments(status,scheduled_at);
CREATE INDEX IF NOT EXISTS idx_ai_events_unprocessed ON ai_events(processed_at,occurred_at);
CREATE INDEX IF NOT EXISTS idx_ai_findings_open ON ai_findings(status,severity,created_at);

INSERT INTO policy_configs(key,value_json,description) VALUES
('platform.dynamic_markets.enabled','true','تمكين إنشاء الأسواق والأقسام من الإعدادات دون قاعدة مستقلة لكل سوق'),
('platform.customer_voice.enabled','true','تمكين آراء وشكاوى واقتراحات العملاء'),
('platform.agent_review.enabled','true','تمكين تقييم الوكلاء ومساءلتهم المهنية مع حفظ حقوقهم'),
('platform.international_trade.enabled','true','دعم الاستيراد والتصدير كسعة عامة عبر الأسواق'),
('ai.governance.version','"4.3"','إصدار حوكمة الذكاء الاصطناعي'),
('ai.never_directly_controls_money','true','AI لا يحرر الأموال أو يعدل Ledger مباشرة'),
('ai.never_directly_changes_permissions','true','AI لا يمنح/يسحب صلاحيات مباشرة'),
('feedback.customer_voice_is_improvement_tool','true','صوت العميل أداة تحسين وليس إدانة تلقائية')
ON CONFLICT(key) DO NOTHING;

INSERT INTO ai_agents(agent_key,display_name,purpose,mode,enabled)
VALUES
('customer_voice_guard','مراقب صوت العميل','feedback_analysis','advisory',TRUE),
('agent_quality_guard','مراقب جودة الوكلاء','agent_quality','advisory',TRUE),
('trade_guard','مراقب التجارة الدولية','trade_compliance','advisory',TRUE),
('platform_reporter','محلل تقارير هلا','management_reporting','advisory',TRUE)
ON CONFLICT(agent_key) DO NOTHING;

COMMIT;
