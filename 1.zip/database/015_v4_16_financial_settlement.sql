-- Hala v4.16 Financial Settlement, Commission & Agent Routing
BEGIN;
SET search_path TO hala, public;

CREATE TABLE IF NOT EXISTS market_agent_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  directorate_location_id UUID REFERENCES locations(id),
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','PAUSED','ENDED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,agent_id,directorate_location_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_market_active_agent_directorate
  ON market_agent_assignments(market_id,directorate_location_id) WHERE status='ACTIVE' AND directorate_location_id IS NOT NULL;


ALTER TABLE payments ADD COLUMN IF NOT EXISTS currency_code VARCHAR(3) NOT NULL DEFAULT 'YER';
ALTER TABLE payment_transactions ADD COLUMN IF NOT EXISTS currency_code VARCHAR(3) NOT NULL DEFAULT 'YER';
ALTER TABLE booking_commissions ADD COLUMN IF NOT EXISTS currency_code VARCHAR(3) NOT NULL DEFAULT 'YER';
ALTER TABLE wallets DROP CONSTRAINT IF EXISTS wallets_owner_user_id_key;
CREATE UNIQUE INDEX IF NOT EXISTS uq_wallet_owner_currency ON wallets(owner_user_id,currency);

CREATE TABLE IF NOT EXISTS financial_settlements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES bookings(id),
  escrow_account_id UUID NOT NULL REFERENCES escrow_accounts(id),
  gross_amount NUMERIC(18,2) NOT NULL CHECK(gross_amount>0),
  platform_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK(platform_amount>=0),
  agent_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK(agent_amount>=0),
  provider_amount NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK(provider_amount>=0),
  currency_code VARCHAR(3) NOT NULL DEFAULT 'YER',
  commission_rule_id UUID REFERENCES commission_rules(id),
  agent_id UUID REFERENCES agents(id),
  provider_id UUID REFERENCES providers(id),
  status VARCHAR(20) NOT NULL DEFAULT 'POSTED' CHECK(status IN ('POSTED','REVERSED')),
  idempotency_key VARCHAR(200),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK(platform_amount+agent_amount+provider_amount=gross_amount)
);
CREATE INDEX IF NOT EXISTS idx_financial_settlements_booking ON financial_settlements(booking_id,created_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_financial_settlement_idempotency ON financial_settlements(idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_market_active_global_agent
  ON market_agent_assignments(market_id) WHERE status='ACTIVE' AND directorate_location_id IS NULL;

INSERT INTO policy_configs(key,value_json,description) VALUES
('finance.require_completed_for_release','true','لا يخرج مبلغ من Escrow إلا بعد إكمال الحجز أو حله نهائيًا'),
('finance.commission_rules_source','commission_rules','عمولة هلا والوكيل تقرأ من قواعد النظام ولا يقبلها العميل'),
('finance.require_agent_assignment','true','التسوية تتطلب وكيلًا مسؤولًا وفق السوق والنطاق الجغرافي')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;

COMMIT;
