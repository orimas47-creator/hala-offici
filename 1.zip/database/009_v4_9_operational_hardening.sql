-- Hala v4.9 operational hardening.
BEGIN;
SET search_path TO hala, public;

-- Force every newly created market to inherit the central supervisor binding.
INSERT INTO ai_market_bindings(market_id,supervisor_id,local_ai_enabled,local_ai_policy,inheritance_mode)
SELECT m.id,s.id,true,'{}'::jsonb,'INHERIT_AND_RESTRICT'
FROM markets m CROSS JOIN ai_supervisor_configs s
WHERE s.supervisor_key='platform_supervisor' AND m.is_deleted=false
ON CONFLICT (market_id) DO UPDATE SET supervisor_id=EXCLUDED.supervisor_id,
  inheritance_mode='INHERIT_AND_RESTRICT',updated_at=now();

-- Operational policy guardrails.
INSERT INTO policy_configs(key,value_json,description) VALUES
('security.production_require_tls','true','الإنتاج يتطلب HTTPS/TLS من نقطة الدخول'),
('security.reject_forwarded_identity','true','لا تُستخدم X-Actor-Id كهوية موثوقة في الإنتاج'),
('security.max_json_body_bytes','1048576','الحد الأعلى لجسم طلب JSON'),
('security.external_urls_https_only','true','الروابط الخارجية يجب أن تستخدم HTTPS'),
('security.ai_prompt_injection_guard','true','المحتوى الخارجي لا يتحول إلى تعليمات للنظام'),
('security.ai_tool_allowlist','true','أدوات الذكاء محصورة في قائمة مسموحة'),
('finance.no_direct_balance_edit','true','لا يوجد مسار مباشر لتعديل الرصيد'),
('market.ai_central_supervisor_required','true','كل سوق يجب أن يرتبط بمشرف الذكاء المركزي')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;

COMMIT;

BEGIN;
SET search_path TO hala, public;
ALTER TABLE market_change_log DROP CONSTRAINT IF EXISTS market_change_log_action_check;
ALTER TABLE market_change_log ADD CONSTRAINT market_change_log_action_check CHECK (action IN ('CREATE','UPDATE','ACTIVATE','PAUSE','ARCHIVE','RESTORE','SOFT_DELETE','SET_REFERENCE'));
CREATE UNIQUE INDEX IF NOT EXISTS ux_markets_active_reference_template ON markets(is_reference_template) WHERE is_reference_template=true AND status='ACTIVE' AND is_deleted=false;
COMMIT;
