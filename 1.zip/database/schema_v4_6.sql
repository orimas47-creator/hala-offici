-- Hala Platform Database v1.0
-- PostgreSQL + PostGIS
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE SCHEMA IF NOT EXISTS hala;
SET search_path TO hala, public;

CREATE TYPE account_type AS ENUM ('personal','agent','representative','professional');
CREATE TYPE provider_status AS ENUM ('pending','active','suspended','closed');
CREATE TYPE offer_status AS ENUM ('draft','ai_review','needs_correction','approved','published','rejected','archived');
CREATE TYPE listing_type AS ENUM ('rental','sale');
CREATE TYPE booking_status AS ENUM ('draft','hold','awaiting_payment','payment_pending','payment_verified','confirmed','alternate_activation','executing','completed','cancelled','disputed','refund_pending','refunded','expired');
CREATE TYPE payment_status AS ENUM ('created','pending','verified','failed','cancelled','refunded','partially_refunded');
CREATE TYPE payment_method AS ENUM ('wallet','bank','card','local_wallet','cash');
CREATE TYPE ledger_side AS ENUM ('debit','credit');
CREATE TYPE insurance_type AS ENUM ('cash','inkind','none');
CREATE TYPE document_status AS ENUM ('pending','verified','rejected','expired');
CREATE TYPE hold_status AS ENUM ('active','released','converted','expired');
CREATE TYPE unit_status AS ENUM ('available','reserved','maintenance','inactive','sold');

CREATE TABLE users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 phone VARCHAR(30) UNIQUE NOT NULL,
 full_name VARCHAR(200) NOT NULL,
 account_type account_type NOT NULL DEFAULT 'personal',
 password_hash TEXT,
 is_active BOOLEAN DEFAULT TRUE,
 created_at TIMESTAMPTZ DEFAULT now(),
 updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE roles (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name VARCHAR(80) UNIQUE NOT NULL, description TEXT);
CREATE TABLE permissions (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), code VARCHAR(120) UNIQUE NOT NULL, description TEXT);
CREATE TABLE user_roles (user_id UUID REFERENCES users(id) ON DELETE CASCADE, role_id UUID REFERENCES roles(id) ON DELETE CASCADE, PRIMARY KEY(user_id,role_id));
CREATE TABLE user_documents (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 document_type VARCHAR(100) NOT NULL, document_number VARCHAR(120), file_uri TEXT NOT NULL,
 status document_status DEFAULT 'pending', issued_at DATE, expires_at DATE, verified_by UUID REFERENCES users(id), verified_at TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE otp_events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID REFERENCES users(id), phone VARCHAR(30) NOT NULL,
 purpose VARCHAR(80) NOT NULL, code_hash TEXT NOT NULL, expires_at TIMESTAMPTZ NOT NULL, consumed_at TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE geographic_levels (id SMALLSERIAL PRIMARY KEY, code VARCHAR(40) UNIQUE NOT NULL, name_ar VARCHAR(100) NOT NULL);
CREATE TABLE locations (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), level_id SMALLINT NOT NULL REFERENCES geographic_levels(id),
 parent_id UUID REFERENCES locations(id), name_ar VARCHAR(200) NOT NULL, code VARCHAR(80),
 boundary GEOMETRY(MULTIPOLYGON,4326), center GEOMETRY(POINT,4326), UNIQUE(parent_id,name_ar)
);
CREATE TABLE user_locations (
 user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, location_id UUID NOT NULL REFERENCES locations(id),
 address_text TEXT, latitude NUMERIC(10,7), longitude NUMERIC(10,7)
);

CREATE TABLE providers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID UNIQUE NOT NULL REFERENCES users(id),
 business_name VARCHAR(250), status provider_status DEFAULT 'pending',
 subscription_started_at TIMESTAMPTZ, subscription_expires_at TIMESTAMPTZ,
 insurance_confirmed BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE agents (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID UNIQUE NOT NULL REFERENCES users(id),
 directorate_location_id UUID REFERENCES locations(id), status provider_status DEFAULT 'pending', created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE memberships (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), provider_id UUID NOT NULL REFERENCES providers(id),
 membership_number VARCHAR(100) UNIQUE NOT NULL, status VARCHAR(40) DEFAULT 'active', created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE serials (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), serial_number VARCHAR(120) UNIQUE NOT NULL,
 membership_id UUID REFERENCES memberships(id), owner_user_id UUID REFERENCES users(id),
 status VARCHAR(40) DEFAULT 'active', transferred_at TIMESTAMPTZ, transfer_deadline TIMESTAMPTZ
);
CREATE TABLE ownership_transfers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), serial_id UUID NOT NULL REFERENCES serials(id),
 old_owner_id UUID REFERENCES users(id), new_owner_id UUID REFERENCES users(id),
 symbolic_fee_payment_id UUID, started_at TIMESTAMPTZ DEFAULT now(), deadline_at TIMESTAMPTZ NOT NULL, completed_at TIMESTAMPTZ
);

CREATE TABLE categories (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), parent_id UUID REFERENCES categories(id),
 name_ar VARCHAR(200) NOT NULL, category_kind VARCHAR(40) NOT NULL, sort_order INT DEFAULT 0, is_active BOOLEAN DEFAULT TRUE
);
CREATE TABLE services (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), category_id UUID REFERENCES categories(id),
 name_ar VARCHAR(250) NOT NULL, description TEXT, listing_type listing_type NOT NULL, is_active BOOLEAN DEFAULT TRUE, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE manufacturers (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name_ar VARCHAR(250) NOT NULL, name_en VARCHAR(250), country VARCHAR(120), official_url TEXT);
CREATE TABLE models (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), manufacturer_id UUID REFERENCES manufacturers(id), model_name VARCHAR(250), global_code VARCHAR(150));

CREATE TABLE service_offers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), service_id UUID NOT NULL REFERENCES services(id),
 provider_id UUID NOT NULL REFERENCES providers(id), title VARCHAR(300) NOT NULL, description TEXT,
 manufacturer_id UUID REFERENCES manufacturers(id), model_id UUID REFERENCES models(id), global_code VARCHAR(150),
 status offer_status DEFAULT 'draft', rental_price NUMERIC(18,2), sale_price NUMERIC(18,2),
 insurance_price NUMERIC(18,2) DEFAULT 0, transport_price NUMERIC(18,2) DEFAULT 0,
 installation_price NUMERIC(18,2) DEFAULT 0, dismantling_price NUMERIC(18,2) DEFAULT 0,
 price_includes_contact BOOLEAN DEFAULT FALSE, ai_review_deadline TIMESTAMPTZ, published_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE offer_attributes (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id) ON DELETE CASCADE,
 attribute_name VARCHAR(150) NOT NULL, attribute_value TEXT NOT NULL, UNIQUE(offer_id,attribute_name)
);
CREATE TABLE offer_media (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id) ON DELETE CASCADE,
 media_type VARCHAR(30) NOT NULL, file_uri TEXT NOT NULL, caption TEXT, sort_order INT DEFAULT 0
);
CREATE TABLE service_units (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id) ON DELETE CASCADE,
 unit_code VARCHAR(120) NOT NULL, unit_status unit_status DEFAULT 'available', quantity NUMERIC(12,2) DEFAULT 1, UNIQUE(offer_id,unit_code)
);

CREATE TABLE ai_reviews (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id),
 review_status VARCHAR(40) DEFAULT 'pending', data_score NUMERIC(5,2), specification_score NUMERIC(5,2),
 evidence_score NUMERIC(5,2), price_score NUMERIC(5,2), similarity_score NUMERIC(5,2),
 findings JSONB, recommendation TEXT, started_at TIMESTAMPTZ DEFAULT now(), completed_at TIMESTAMPTZ
);
CREATE TABLE ai_price_checks (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id),
 comparable_offer_count INT DEFAULT 0, market_min NUMERIC(18,2), market_avg NUMERIC(18,2), market_max NUMERIC(18,2),
 submitted_price NUMERIC(18,2), insurance_min NUMERIC(18,2), insurance_avg NUMERIC(18,2),
 submitted_insurance NUMERIC(18,2), decision VARCHAR(40), reason TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE ai_flags (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID REFERENCES service_offers(id), severity VARCHAR(30), code VARCHAR(100), message TEXT, resolved_at TIMESTAMPTZ);

CREATE TABLE availability_rules (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), unit_id UUID NOT NULL REFERENCES service_units(id) ON DELETE CASCADE,
 start_date DATE NOT NULL, end_date DATE NOT NULL, available_quantity NUMERIC(12,2) DEFAULT 1
);
CREATE TABLE maintenance_blocks (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), unit_id UUID NOT NULL REFERENCES service_units(id),
 start_at TIMESTAMPTZ NOT NULL, end_at TIMESTAMPTZ NOT NULL, reason TEXT
);
CREATE TABLE holds (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), unit_id UUID NOT NULL REFERENCES service_units(id),
 booking_id UUID, status hold_status DEFAULT 'active', start_at TIMESTAMPTZ NOT NULL, end_at TIMESTAMPTZ NOT NULL, expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE bookings (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), customer_id UUID NOT NULL REFERENCES users(id),
 service_id UUID NOT NULL REFERENCES services(id), status booking_status DEFAULT 'draft',
 event_start TIMESTAMPTZ NOT NULL, event_end TIMESTAMPTZ NOT NULL, quantity NUMERIC(12,2) DEFAULT 1,
 subtotal NUMERIC(18,2) DEFAULT 0, insurance_amount NUMERIC(18,2) DEFAULT 0, extras_amount NUMERIC(18,2) DEFAULT 0,
 total_amount NUMERIC(18,2) DEFAULT 0, insurance_type insurance_type DEFAULT 'none', notes TEXT,
 created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE booking_wishes (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 wish_rank SMALLINT NOT NULL CHECK(wish_rank BETWEEN 1 AND 3), offer_id UUID NOT NULL REFERENCES service_offers(id),
 unit_id UUID REFERENCES service_units(id), status VARCHAR(40) DEFAULT 'pending', deposit_required NUMERIC(18,2) DEFAULT 0,
 UNIQUE(booking_id,wish_rank)
);
CREATE TABLE booking_events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 event_code VARCHAR(100) NOT NULL, old_status booking_status, new_status booking_status,
 actor_user_id UUID REFERENCES users(id), metadata JSONB, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE booking_state_history (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id),
 status booking_status NOT NULL, changed_by UUID REFERENCES users(id), note TEXT, created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE payments (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID REFERENCES bookings(id),
 customer_id UUID NOT NULL REFERENCES users(id), amount NUMERIC(18,2) NOT NULL,
 method payment_method NOT NULL, status payment_status DEFAULT 'created',
 provider_reference VARCHAR(200), client_reference VARCHAR(200), receipt_file_uri TEXT,
 created_at TIMESTAMPTZ DEFAULT now(), verified_at TIMESTAMPTZ, failed_at TIMESTAMPTZ
);
CREATE TABLE payment_attempts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), payment_id UUID NOT NULL REFERENCES payments(id),
 attempt_no INT NOT NULL, external_reference VARCHAR(200), request_payload JSONB, response_payload JSONB,
 status payment_status NOT NULL, started_at TIMESTAMPTZ DEFAULT now(), finished_at TIMESTAMPTZ,
 UNIQUE(payment_id,attempt_no)
);
CREATE TABLE payment_transactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), payment_id UUID NOT NULL REFERENCES payments(id),
 idempotency_key VARCHAR(200) UNIQUE NOT NULL, external_reference VARCHAR(200),
 status payment_status NOT NULL, amount NUMERIC(18,2) NOT NULL, received_at TIMESTAMPTZ, reconciled_at TIMESTAMPTZ
);
CREATE TABLE payment_locks (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID UNIQUE NOT NULL REFERENCES bookings(id),
 locked_until TIMESTAMPTZ NOT NULL, reason TEXT
);
CREATE TABLE escrow_accounts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID UNIQUE NOT NULL REFERENCES bookings(id),
 held_amount NUMERIC(18,2) DEFAULT 0, released_amount NUMERIC(18,2) DEFAULT 0,
 refunded_amount NUMERIC(18,2) DEFAULT 0, status VARCHAR(40) DEFAULT 'holding'
);

CREATE TABLE ledger_accounts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), account_code VARCHAR(80) UNIQUE NOT NULL,
 account_name VARCHAR(200) NOT NULL, account_type VARCHAR(60) NOT NULL, owner_user_id UUID REFERENCES users(id)
);
CREATE TABLE ledger_entries (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), reference_type VARCHAR(80) NOT NULL, reference_id UUID,
 description TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE ledger_entry_lines (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), entry_id UUID NOT NULL REFERENCES ledger_entries(id) ON DELETE CASCADE,
 account_id UUID NOT NULL REFERENCES ledger_accounts(id), side ledger_side NOT NULL,
 amount NUMERIC(18,2) NOT NULL CHECK(amount>0), currency VARCHAR(10) DEFAULT 'YER'
);

CREATE TABLE commission_rules (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name VARCHAR(120) NOT NULL,
 total_rate NUMERIC(7,4) NOT NULL, platform_rate NUMERIC(7,4) NOT NULL,
 agent_rate NUMERIC(7,4) NOT NULL, is_exclusive BOOLEAN DEFAULT FALSE, active BOOLEAN DEFAULT TRUE
);
CREATE TABLE booking_commissions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id),
 rule_id UUID REFERENCES commission_rules(id), gross_amount NUMERIC(18,2) NOT NULL,
 platform_amount NUMERIC(18,2) NOT NULL, agent_amount NUMERIC(18,2) NOT NULL, provider_amount NUMERIC(18,2) NOT NULL
);
CREATE TABLE wallets (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), owner_user_id UUID UNIQUE REFERENCES users(id),
 currency VARCHAR(10) DEFAULT 'YER', status VARCHAR(30) DEFAULT 'active'
);
CREATE TABLE wallet_transactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), wallet_id UUID NOT NULL REFERENCES wallets(id),
 amount NUMERIC(18,2) NOT NULL, transaction_type VARCHAR(60) NOT NULL,
 reference_type VARCHAR(80), reference_id UUID, created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE insurance_records (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID UNIQUE NOT NULL REFERENCES bookings(id),
 type insurance_type NOT NULL, cash_amount NUMERIC(18,2) DEFAULT 0, description TEXT, evidence_uri TEXT,
 received_at TIMESTAMPTZ, returned_at TIMESTAMPTZ, status VARCHAR(40) DEFAULT 'held'
);
CREATE TABLE service_executions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID UNIQUE NOT NULL REFERENCES bookings(id),
 provider_id UUID REFERENCES providers(id), started_at TIMESTAMPTZ, completed_at TIMESTAMPTZ,
 customer_confirmation_at TIMESTAMPTZ, provider_confirmation_at TIMESTAMPTZ, notes TEXT
);

CREATE TABLE disputes (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id),
 opened_by UUID NOT NULL REFERENCES users(id), status VARCHAR(40) DEFAULT 'open',
 reason TEXT NOT NULL, resolution TEXT, opened_at TIMESTAMPTZ DEFAULT now(), resolved_at TIMESTAMPTZ
);
CREATE TABLE dispute_events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), dispute_id UUID NOT NULL REFERENCES disputes(id) ON DELETE CASCADE,
 actor_user_id UUID REFERENCES users(id), action VARCHAR(100) NOT NULL, note TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE customer_reviews (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id),
 customer_id UUID NOT NULL REFERENCES users(id), provider_id UUID REFERENCES providers(id),
 offer_id UUID REFERENCES service_offers(id), rating NUMERIC(2,1) CHECK(rating BETWEEN 1 AND 5),
 review_text TEXT, created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE notifications (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id),
 title VARCHAR(250) NOT NULL, body TEXT NOT NULL, type VARCHAR(80),
 reference_type VARCHAR(80), reference_id UUID, read_at TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE conversations (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID REFERENCES bookings(id), created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE conversation_members (conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE, user_id UUID REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY(conversation_id,user_id));
CREATE TABLE messages (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
 sender_id UUID NOT NULL REFERENCES users(id), message_type VARCHAR(30) DEFAULT 'text', body TEXT, media_uri TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE ads (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), provider_id UUID REFERENCES providers(id), title VARCHAR(250) NOT NULL,
 placement VARCHAR(80) NOT NULL, price NUMERIC(18,2), start_at TIMESTAMPTZ, end_at TIMESTAMPTZ, status VARCHAR(40) DEFAULT 'pending'
);
CREATE TABLE audit_logs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), actor_user_id UUID REFERENCES users(id), action VARCHAR(120) NOT NULL,
 entity_type VARCHAR(100) NOT NULL, entity_id UUID, before_data JSONB, after_data JSONB, ip_address INET, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE incidents (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), type VARCHAR(100) NOT NULL, severity VARCHAR(30) NOT NULL,
 booking_id UUID REFERENCES bookings(id), payment_id UUID REFERENCES payments(id), description TEXT,
 status VARCHAR(40) DEFAULT 'open', created_at TIMESTAMPTZ DEFAULT now(), resolved_at TIMESTAMPTZ
);
CREATE TABLE policy_configs (key VARCHAR(120) PRIMARY KEY, value_json JSONB NOT NULL, description TEXT);

CREATE INDEX idx_locations_parent ON locations(parent_id);
CREATE INDEX idx_services_category ON services(category_id);
CREATE INDEX idx_offers_service_status ON service_offers(service_id,status);
CREATE INDEX idx_offers_provider ON service_offers(provider_id);
CREATE INDEX idx_availability_unit_dates ON availability_rules(unit_id,start_date,end_date);
CREATE INDEX idx_bookings_customer ON bookings(customer_id);
CREATE INDEX idx_bookings_dates ON bookings(event_start,event_end);
CREATE INDEX idx_booking_wishes_booking ON booking_wishes(booking_id);
CREATE INDEX idx_payments_booking ON payments(booking_id);
CREATE INDEX idx_payments_reference ON payments(provider_reference);
CREATE INDEX idx_ledger_lines_account ON ledger_entry_lines(account_id);
CREATE INDEX idx_notifications_user ON notifications(user_id,read_at);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type,entity_id);

INSERT INTO roles(name,description) VALUES
('customer','طالب خدمة'),('provider','منتسب'),('agent','وكيل متجر هلا في المديرية'),
('admin','إدارة'),('finance','مالية'),('ai_reviewer','مراجعة ذكية') ON CONFLICT DO NOTHING;
INSERT INTO geographic_levels(code,name_ar) VALUES
('country','الدولة'),('governorate','المحافظة'),('directorate','المديرية'),('neighborhood','الحي'),('alley','الحارة') ON CONFLICT DO NOTHING;
INSERT INTO commission_rules(name,total_rate,platform_rate,agent_rate,is_exclusive) VALUES
('عادي',15,10,5,FALSE),('حصري',25,20,5,TRUE);
INSERT INTO policy_configs(key,value_json,description) VALUES
('payment_pending_window_minutes','5','نافذة حماية التوريد المعلق'),
('offer_min_ai_review_hours','6','مراجعة موسعة للعروض'),
('offer_fast_publish_minutes','30','النشر بعد اجتياز المراجعة'),
('booking_reminder_hours','[24,18,12]','مواعيد التنبيهات'),
('serial_completion_days','10','مهلة استكمال نقل الملكية'),
('availability_horizon_days','365','جدول التوفر لمدة سنة')
ON CONFLICT(key) DO NOTHING;


-- Hala Platform Unified Database v4.2
-- PostgreSQL + PostGIS
-- هذا الملف يحافظ على قاعدة v1 الحالية ويضيف طبقة v4.2 بدلاً من استبدالها.
BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE SCHEMA IF NOT EXISTS hala;
SET search_path TO hala, public;

-- Canonical lifecycle مستقل عن enum القديم للتوافق.
DO $$ BEGIN
  CREATE TYPE booking_lifecycle_status AS ENUM ('DRAFT','PAYMENT_PENDING','PROVIDER_PENDING','CONFIRMED','IN_PROGRESS','RETURN_PENDING','INSPECTION','COMPLETED','CANCELLED','FAILED','DISPUTED','FORCE_MAJEURE','RESOLVED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS booking_timers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 timer_type VARCHAR(60) NOT NULL,
 scheduled_at TIMESTAMPTZ NOT NULL,
 processed BOOLEAN NOT NULL DEFAULT FALSE,
 processed_at TIMESTAMPTZ,
 status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
 failure_reason TEXT,
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(booking_id,timer_type)
);
CREATE INDEX IF NOT EXISTS idx_booking_timers_due ON booking_timers(processed,scheduled_at,status);
CREATE INDEX IF NOT EXISTS idx_booking_timers_booking ON booking_timers(booking_id);

ALTER TABLE bookings ADD COLUMN IF NOT EXISTS lifecycle_status booking_lifecycle_status;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS lifecycle_version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS request_id UUID;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(200);
CREATE UNIQUE INDEX IF NOT EXISTS ux_bookings_idempotency ON bookings(idempotency_key) WHERE idempotency_key IS NOT NULL;

-- تحويل آمن للحالات القديمة إلى الحالة الموحدة.
UPDATE bookings SET lifecycle_status = CASE status::text
 WHEN 'draft' THEN 'DRAFT'::booking_lifecycle_status
 WHEN 'hold' THEN 'PAYMENT_PENDING'::booking_lifecycle_status
 WHEN 'awaiting_payment' THEN 'PAYMENT_PENDING'::booking_lifecycle_status
 WHEN 'payment_pending' THEN 'PAYMENT_PENDING'::booking_lifecycle_status
 WHEN 'payment_verified' THEN 'PROVIDER_PENDING'::booking_lifecycle_status
 WHEN 'confirmed' THEN 'CONFIRMED'::booking_lifecycle_status
 WHEN 'alternate_activation' THEN 'PROVIDER_PENDING'::booking_lifecycle_status
 WHEN 'executing' THEN 'IN_PROGRESS'::booking_lifecycle_status
 WHEN 'completed' THEN 'COMPLETED'::booking_lifecycle_status
 WHEN 'cancelled' THEN 'CANCELLED'::booking_lifecycle_status
 WHEN 'disputed' THEN 'DISPUTED'::booking_lifecycle_status
 WHEN 'refund_pending' THEN 'FAILED'::booking_lifecycle_status
 WHEN 'refunded' THEN 'COMPLETED'::booking_lifecycle_status
 WHEN 'expired' THEN 'FAILED'::booking_lifecycle_status
 ELSE 'DRAFT'::booking_lifecycle_status END
WHERE lifecycle_status IS NULL;
ALTER TABLE bookings ALTER COLUMN lifecycle_status SET NOT NULL;

-- سجل موحد للدورات إذا لم يكن موجوداً.
CREATE TABLE IF NOT EXISTS booking_lifecycle_history (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 from_status booking_lifecycle_status,
 to_status booking_lifecycle_status NOT NULL,
 actor_user_id UUID REFERENCES users(id),
 request_id UUID,
 reason TEXT,
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_booking_lifecycle_history_booking ON booking_lifecycle_history(booking_id,created_at);

-- Webhook Inbox يمنع إسقاط callback غير معروف أو تكراره.
CREATE TABLE IF NOT EXISTS webhook_inbox (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 provider_name VARCHAR(100) NOT NULL,
 external_event_id VARCHAR(200) NOT NULL,
 event_type VARCHAR(150) NOT NULL,
 payload JSONB NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'RECEIVED',
 received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 processed_at TIMESTAMPTZ,
 failure_reason TEXT,
 UNIQUE(provider_name,external_event_id)
);

CREATE TABLE IF NOT EXISTS idempotency_records (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 actor_user_id UUID REFERENCES users(id),
 idempotency_key VARCHAR(200) NOT NULL,
 route VARCHAR(300) NOT NULL,
 request_hash VARCHAR(128) NOT NULL,
 response_status INTEGER,
 response_body JSONB,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 expires_at TIMESTAMPTZ,
 UNIQUE(actor_user_id,idempotency_key,route)
);

-- Audit v4.2 يحافظ على audit القديم ويضيف request/result.
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS request_id UUID;
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS result VARCHAR(40);
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}'::jsonb;
CREATE INDEX IF NOT EXISTS idx_audit_request ON audit_logs(request_id);

-- إشعارات قابلة لإعادة المحاولة.
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS priority VARCHAR(30) DEFAULT 'normal';
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS delivery_status VARCHAR(30) DEFAULT 'pending';
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS sent_at TIMESTAMPTZ;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMPTZ;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS retry_count INTEGER NOT NULL DEFAULT 0;

-- سياسات قابلة للإصدار بدلاً من hard-code.
CREATE TABLE IF NOT EXISTS policy_versions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 policy_key VARCHAR(150) NOT NULL,
 version INTEGER NOT NULL,
 value_json JSONB NOT NULL,
 effective_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 approved_by UUID REFERENCES users(id),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(policy_key,version)
);

-- AI audit trail.
CREATE TABLE IF NOT EXISTS ai_review_runs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 offer_id UUID REFERENCES service_offers(id) ON DELETE CASCADE,
 model_name VARCHAR(150),
 model_version VARCHAR(100),
 input_hash VARCHAR(128),
 result VARCHAR(50) NOT NULL,
 score NUMERIC(8,5),
 findings JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- مؤشرات التوفر الأساسية.
CREATE INDEX IF NOT EXISTS idx_maintenance_blocks_unit_dates ON maintenance_blocks(unit_id,start_at,end_at);
CREATE INDEX IF NOT EXISTS idx_holds_unit_dates ON holds(unit_id,start_at,end_at,status);
CREATE INDEX IF NOT EXISTS idx_bookings_lifecycle ON bookings(lifecycle_status,event_start,event_end);
CREATE INDEX IF NOT EXISTS idx_webhook_inbox_status ON webhook_inbox(status,received_at);

-- قيود ledger: لا تسمح بمبلغ غير موجب.
ALTER TABLE ledger_entry_lines DROP CONSTRAINT IF EXISTS ledger_entry_lines_amount_check;
ALTER TABLE ledger_entry_lines ADD CONSTRAINT ledger_entry_lines_amount_check CHECK(amount > 0);

-- سياسة افتراضية فقط؛ القيم المالية النهائية يجب اعتمادها قبل الإنتاج.
INSERT INTO policy_configs(key,value_json,description) VALUES
('booking.lifecycle.version','"4.2"','الإصدار القانوني/التقني لدورة الحجز'),
('booking.timer.types','["PAYMENT_DEADLINE","SUPPLIER_CONFIRMATION","MILESTONE_24H","MILESTONE_18H","MILESTONE_12H","MILESTONE_6H","ALTERNATIVE_HOLD_EXPIRY","INSURANCE_REFUND"]','أنواع المؤقتات'),
('ai.fast_publish_minutes','30','هدف تشغيلي لا يعني موافقة تلقائية'),
('ai.extended_review_hours','6','نافذة البحث الإضافي'),
('availability.horizon_days','365','أفق التوفر'),
('payment.lock_minutes','5','نافذة حماية الدفع'),
('ownership.transfer_completion_days','10','مهلة استكمال نقل الملكية')
ON CONFLICT(key) DO NOTHING;

COMMIT;


-- Hala Platform Unified Database v4.3
-- PostgreSQL + PostGIS
-- هدف هذا الإصدار: توسيع النواة لتدعم الأسواق الديناميكية، صوت العميل، تقييم الوكلاء،
-- المصنعين والتجارة الدولية، مع الحفاظ على قاعدة v1/v4.2 وعدم إنشاء قاعدة مستقلة لكل سوق.
BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS postgis;
SET search_path TO hala, public;

-- =========================================================
-- 1) Dynamic Markets / Sections / Attributes
-- =========================================================
CREATE TABLE IF NOT EXISTS markets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_key VARCHAR(120) NOT NULL UNIQUE,
  name_ar VARCHAR(250) NOT NULL,
  name_en VARCHAR(250),
  description TEXT,
  status VARCHAR(30) NOT NULL DEFAULT 'draft',
  configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
  compliance_profile JSONB NOT NULL DEFAULT '{}'::jsonb,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status IN ('draft','review','active','suspended','archived'))
);

ALTER TABLE categories ADD COLUMN IF NOT EXISTS market_id UUID REFERENCES markets(id);
ALTER TABLE services ADD COLUMN IF NOT EXISTS market_id UUID REFERENCES markets(id);

CREATE TABLE IF NOT EXISTS market_sections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  parent_id UUID REFERENCES market_sections(id),
  section_key VARCHAR(160) NOT NULL,
  name_ar VARCHAR(250) NOT NULL,
  name_en VARCHAR(250),
  configuration JSONB NOT NULL DEFAULT '{}'::jsonb,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(market_id, section_key)
);

CREATE TABLE IF NOT EXISTS attribute_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id) ON DELETE CASCADE,
  section_id UUID REFERENCES market_sections(id) ON DELETE CASCADE,
  attribute_key VARCHAR(160) NOT NULL,
  name_ar VARCHAR(250) NOT NULL,
  data_type VARCHAR(30) NOT NULL DEFAULT 'text',
  unit VARCHAR(60),
  required BOOLEAN NOT NULL DEFAULT FALSE,
  options_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  validation_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(market_id, section_id, attribute_key),
  CHECK (data_type IN ('text','number','decimal','integer','boolean','date','datetime','choice','multi_choice','json'))
);

-- العرض القديم offer_attributes يبقى للتوافق؛ هذه الطبقة تضيف تعريفًا ديناميكيًا للحقول.
ALTER TABLE offer_attributes ADD COLUMN IF NOT EXISTS attribute_key VARCHAR(160);
ALTER TABLE offer_attributes ADD COLUMN IF NOT EXISTS value_json JSONB;
ALTER TABLE offer_attributes ADD COLUMN IF NOT EXISTS template_id UUID REFERENCES attribute_templates(id);

-- =========================================================
-- 2) Manufacturer / Supplier / Trader / Company / International Trade
-- =========================================================
CREATE TABLE IF NOT EXISTS organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_type VARCHAR(40) NOT NULL,
  legal_name VARCHAR(300) NOT NULL,
  trade_name VARCHAR(300),
  country VARCHAR(120),
  registration_number VARCHAR(150),
  tax_number VARCHAR(150),
  website TEXT,
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (organization_type IN ('factory','company','supplier','trader','store','importer','exporter','distributor','service_company','government','other'))
);

CREATE TABLE IF NOT EXISTS organization_users (
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_name VARCHAR(120) NOT NULL,
  is_primary BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(organization_id,user_id)
);

ALTER TABLE manufacturers ADD COLUMN IF NOT EXISTS organization_id UUID REFERENCES organizations(id);
ALTER TABLE manufacturers ADD COLUMN IF NOT EXISTS registration_number VARCHAR(150);
ALTER TABLE manufacturers ADD COLUMN IF NOT EXISTS verification_status VARCHAR(30) NOT NULL DEFAULT 'pending';

CREATE TABLE IF NOT EXISTS offer_supply_chain (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id UUID NOT NULL REFERENCES service_offers(id) ON DELETE CASCADE,
  manufacturer_id UUID REFERENCES manufacturers(id),
  source_organization_id UUID REFERENCES organizations(id),
  distributor_organization_id UUID REFERENCES organizations(id),
  importer_organization_id UUID REFERENCES organizations(id),
  exporter_organization_id UUID REFERENCES organizations(id),
  origin_country VARCHAR(120),
  source_country VARCHAR(120),
  destination_country VARCHAR(120),
  supply_role VARCHAR(40) NOT NULL DEFAULT 'source',
  verification_status VARCHAR(30) NOT NULL DEFAULT 'pending',
  verification_evidence JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (supply_role IN ('manufacturer','source','distributor','importer','exporter','agent','other'))
);
CREATE INDEX IF NOT EXISTS idx_offer_supply_chain_offer ON offer_supply_chain(offer_id);

CREATE TABLE IF NOT EXISTS trade_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_reference VARCHAR(120) NOT NULL UNIQUE,
  market_id UUID REFERENCES markets(id),
  buyer_organization_id UUID REFERENCES organizations(id),
  seller_organization_id UUID REFERENCES organizations(id),
  manufacturer_id UUID REFERENCES manufacturers(id),
  direction VARCHAR(20) NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'draft',
  currency VARCHAR(10) NOT NULL DEFAULT 'YER',
  total_amount NUMERIC(20,4) NOT NULL DEFAULT 0,
  terms_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (direction IN ('import','export','domestic_wholesale','domestic_retail'))
);

CREATE TABLE IF NOT EXISTS trade_order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_order_id UUID NOT NULL REFERENCES trade_orders(id) ON DELETE CASCADE,
  offer_id UUID REFERENCES service_offers(id),
  product_name VARCHAR(300),
  quantity NUMERIC(20,4) NOT NULL DEFAULT 1,
  unit_price NUMERIC(20,4) NOT NULL DEFAULT 0,
  attributes JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS trade_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_order_id UUID NOT NULL REFERENCES trade_orders(id) ON DELETE CASCADE,
  document_type VARCHAR(80) NOT NULL,
  document_number VARCHAR(150),
  issuer_organization_id UUID REFERENCES organizations(id),
  country VARCHAR(120),
  file_uri TEXT,
  content_hash VARCHAR(128),
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  expires_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS shipments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trade_order_id UUID NOT NULL REFERENCES trade_orders(id) ON DELETE CASCADE,
  carrier_organization_id UUID REFERENCES organizations(id),
  origin_country VARCHAR(120),
  destination_country VARCHAR(120),
  origin_location TEXT,
  destination_location TEXT,
  tracking_reference VARCHAR(200),
  status VARCHAR(40) NOT NULL DEFAULT 'planned',
  scheduled_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status IN ('planned','booked','in_transit','customs','delivered','delayed','cancelled'))
);

-- =========================================================
-- 3) Customer Voice: rating, complaint, report, suggestion
-- =========================================================
CREATE TABLE IF NOT EXISTS customer_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES users(id),
  booking_id UUID REFERENCES bookings(id),
  provider_id UUID REFERENCES providers(id),
  agent_id UUID REFERENCES agents(id),
  service_id UUID REFERENCES services(id),
  offer_id UUID REFERENCES service_offers(id),
  feedback_type VARCHAR(40) NOT NULL,
  rating NUMERIC(2,1),
  title VARCHAR(250),
  body TEXT NOT NULL,
  confidentiality VARCHAR(30) NOT NULL DEFAULT 'normal',
  status VARCHAR(40) NOT NULL DEFAULT 'submitted',
  ai_risk_score NUMERIC(6,5),
  assigned_to UUID REFERENCES users(id),
  resolution TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ,
  CHECK (feedback_type IN ('rating','suggestion','complaint','shortcoming','misconduct','fraud_report','security_report','financial_report','recommendation')),
  CHECK (confidentiality IN ('normal','confidential','restricted')),
  CHECK (status IN ('submitted','triaged','under_review','awaiting_response','resolved','rejected','duplicate','escalated')),
  CHECK (rating IS NULL OR rating BETWEEN 1 AND 5)
);

CREATE TABLE IF NOT EXISTS feedback_votes (
  feedback_id UUID NOT NULL REFERENCES customer_feedback(id) ON DELETE CASCADE,
  voter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  vote_value SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(feedback_id,voter_id),
  CHECK (vote_value IN (1,-1))
);

CREATE TABLE IF NOT EXISTS agent_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  reviewer_user_id UUID NOT NULL REFERENCES users(id),
  booking_id UUID REFERENCES bookings(id),
  rating NUMERIC(2,1),
  response_time_score NUMERIC(2,1),
  compliance_score NUMERIC(2,1),
  neutrality_score NUMERIC(2,1),
  followup_score NUMERIC(2,1),
  review_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (rating IS NULL OR rating BETWEEN 1 AND 5)
);

CREATE TABLE IF NOT EXISTS feedback_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feedback_id UUID NOT NULL REFERENCES customer_feedback(id) ON DELETE CASCADE,
  case_reference VARCHAR(120) NOT NULL UNIQUE,
  owner_user_id UUID REFERENCES users(id),
  status VARCHAR(40) NOT NULL DEFAULT 'open',
  findings JSONB NOT NULL DEFAULT '{}'::jsonb,
  corrective_action JSONB NOT NULL DEFAULT '{}'::jsonb,
  due_at TIMESTAMPTZ,
  closed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_customer_feedback_target ON customer_feedback(service_id,provider_id,agent_id,status,created_at);
CREATE INDEX IF NOT EXISTS idx_customer_feedback_type ON customer_feedback(feedback_type,status,created_at);
CREATE INDEX IF NOT EXISTS idx_agent_reviews_agent ON agent_reviews(agent_id,created_at);

-- =========================================================
-- 4) AI governance: advisory/guarded, no direct financial authority
-- =========================================================
CREATE TABLE IF NOT EXISTS ai_agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_key VARCHAR(120) NOT NULL UNIQUE,
  display_name VARCHAR(200) NOT NULL,
  purpose VARCHAR(120) NOT NULL,
  provider VARCHAR(120),
  model VARCHAR(160),
  mode VARCHAR(30) NOT NULL DEFAULT 'advisory',
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (mode IN ('advisory','guarded_action','disabled'))
);

CREATE TABLE IF NOT EXISTS ai_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_key VARCHAR(160) NOT NULL,
  source_module VARCHAR(120) NOT NULL,
  resource_type VARCHAR(100),
  resource_id UUID,
  actor_user_id UUID REFERENCES users(id),
  risk_score NUMERIC(6,5),
  payload_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS ai_findings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES ai_events(id) ON DELETE SET NULL,
  agent_id UUID REFERENCES ai_agents(id) ON DELETE SET NULL,
  severity VARCHAR(20) NOT NULL DEFAULT 'info',
  finding_type VARCHAR(120) NOT NULL,
  confidence NUMERIC(6,5),
  recommendation TEXT,
  evidence_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ,
  CHECK (severity IN ('info','low','medium','high','critical')),
  CHECK (status IN ('OPEN','ACKNOWLEDGED','RESOLVED','FALSE_POSITIVE','ESCALATED'))
);

CREATE TABLE IF NOT EXISTS ai_decisions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  finding_id UUID REFERENCES ai_findings(id) ON DELETE SET NULL,
  agent_id UUID REFERENCES ai_agents(id) ON DELETE SET NULL,
  decision VARCHAR(80) NOT NULL,
  decision_scope VARCHAR(80) NOT NULL,
  proposed_action JSONB NOT NULL DEFAULT '{}'::jsonb,
  applied_by_rule BOOLEAN NOT NULL DEFAULT FALSE,
  applied_by_user_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_watch_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_key VARCHAR(160) NOT NULL UNIQUE,
  event_pattern VARCHAR(200) NOT NULL,
  severity VARCHAR(20) NOT NULL DEFAULT 'medium',
  threshold_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  action_policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_report_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_type VARCHAR(100) NOT NULL,
  scope_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  period_start TIMESTAMPTZ,
  period_end TIMESTAMPTZ,
  metrics_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  recommendations_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  generated_by_agent_id UUID REFERENCES ai_agents(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =========================================================
-- 5) Legal / Contract linkage
-- =========================================================
CREATE TABLE IF NOT EXISTS contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_type VARCHAR(80) NOT NULL,
  party_a_user_id UUID REFERENCES users(id),
  party_a_organization_id UUID REFERENCES organizations(id),
  party_b_user_id UUID REFERENCES users(id),
  party_b_organization_id UUID REFERENCES organizations(id),
  booking_id UUID REFERENCES bookings(id),
  market_id UUID REFERENCES markets(id),
  status VARCHAR(30) NOT NULL DEFAULT 'draft',
  effective_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  accepted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS contract_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id UUID NOT NULL REFERENCES contracts(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  content_hash VARCHAR(128) NOT NULL,
  terms_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(contract_id,version)
);

-- =========================================================
-- 6) Safety / indexing / policy flags
-- =========================================================
CREATE INDEX IF NOT EXISTS idx_markets_status_sort ON markets(status,sort_order);
CREATE INDEX IF NOT EXISTS idx_market_sections_market ON market_sections(market_id,is_active,sort_order);
CREATE INDEX IF NOT EXISTS idx_attribute_templates_market ON attribute_templates(market_id,section_id,is_active);
CREATE INDEX IF NOT EXISTS idx_organizations_type_country ON organizations(organization_type,country,status);
CREATE INDEX IF NOT EXISTS idx_trade_orders_status_direction ON trade_orders(status,direction,created_at);
CREATE INDEX IF NOT EXISTS idx_shipments_status ON shipments(status,scheduled_at);
CREATE INDEX IF NOT EXISTS idx_ai_events_unprocessed ON ai_events(processed_at,occurred_at);
CREATE INDEX IF NOT EXISTS idx_ai_findings_open ON ai_findings(status,severity,created_at);

INSERT INTO policy_configs(key,value_json,description) VALUES
('platform.dynamic_markets.enabled','true','تمكين إنشاء الأسواق والأقسام من الإعدادات دون قاعدة مستقلة لكل سوق'),
('platform.customer_voice.enabled','true','تمكين آراء وشكاوى واقتراحات العملاء'),
('platform.agent_review.enabled','true','تمكين تقييم الوكلاء ومساءلتهم المهنية مع حفظ حقوقهم'),
('platform.international_trade.enabled','true','دعم الاستيراد والتصدير كسعة عامة عبر الأسواق'),
('ai.governance.version','"4.3"','إصدار حوكمة الذكاء الاصطناعي'),
('ai.never_directly_controls_money','true','AI لا يحرر الأموال أو يعدل Ledger مباشرة'),
('ai.never_directly_changes_permissions','true','AI لا يمنح/يسحب صلاحيات مباشرة'),
('feedback.customer_voice_is_improvement_tool','true','صوت العميل أداة تحسين وليس إدانة تلقائية')
ON CONFLICT(key) DO NOTHING;

INSERT INTO ai_agents(agent_key,display_name,purpose,mode,enabled)
VALUES
('customer_voice_guard','مراقب صوت العميل','feedback_analysis','advisory',TRUE),
('agent_quality_guard','مراقب جودة الوكلاء','agent_quality','advisory',TRUE),
('trade_guard','مراقب التجارة الدولية','trade_compliance','advisory',TRUE),
('platform_reporter','محلل تقارير هلا','management_reporting','advisory',TRUE)
ON CONFLICT(agent_key) DO NOTHING;

COMMIT;


-- =========================================================
-- Hala Universal Market Database Extension v4.4
-- Purpose: make the catalog capable of representing ANY legally
-- permitted thing/service that can be offered for sale or rental,
-- without requiring a new table/column for every future category.
-- This is an extension layer; the financial/security/core lifecycle
-- remains strict and governed.
-- PostgreSQL + PostGIS
-- =========================================================

BEGIN;

-- ---------------------------------------------------------
-- 1) Universal listing taxonomy
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_kinds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(40) UNIQUE NOT NULL,
  display_name VARCHAR(160) NOT NULL,
  description TEXT,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO listing_kinds(code,display_name,description) VALUES
('SALE','بيع','عرض أصل/منتج/بضاعة للبيع'),
('RENTAL','تأجير','عرض أصل/منتج/معدات/مكان للتأجير'),
('SALE_RENTAL','بيع وتأجير','العرض متاح للبيع والتأجير'),
('SERVICE','خدمة','خدمة قابلة للحجز والتنفيذ'),
('BUNDLE','حزمة','مجموعة عناصر أو خدمات كوحدة عرض'),
('SUBSCRIPTION','اشتراك','استخدام متكرر/دوري وفق سياسة السوق')
ON CONFLICT(code) DO NOTHING;

-- ---------------------------------------------------------
-- 2) Universal catalog item (one flexible representation)
--    Core searchable fields are normalized; future-specific
--    properties live in structured JSONB + templates.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS universal_listings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id),
  section_id UUID REFERENCES market_sections(id),
  category_id UUID REFERENCES categories(id),
  provider_id UUID REFERENCES providers(id),
  service_id UUID REFERENCES services(id),
  offer_id UUID REFERENCES service_offers(id),
  parent_listing_id UUID REFERENCES universal_listings(id),

  title VARCHAR(500) NOT NULL,
  short_description TEXT,
  long_description TEXT,
  listing_kind VARCHAR(40) NOT NULL,
  listing_status VARCHAR(40) NOT NULL DEFAULT 'DRAFT',

  brand VARCHAR(250),
  manufacturer_name VARCHAR(300),
  model_name VARCHAR(300),
  model_year INTEGER,
  condition_code VARCHAR(60),
  country_of_origin VARCHAR(3),

  quantity NUMERIC(20,6),
  unit_code VARCHAR(40),
  min_order_quantity NUMERIC(20,6),
  max_order_quantity NUMERIC(20,6),

  base_currency VARCHAR(3),
  base_price NUMERIC(20,6),
  pricing_model VARCHAR(60),

  searchable_text TEXT,
  tags JSONB NOT NULL DEFAULT '[]'::jsonb,
  attributes JSONB NOT NULL DEFAULT '{}'::jsonb,
  specifications JSONB NOT NULL DEFAULT '{}'::jsonb,
  usage_constraints JSONB NOT NULL DEFAULT '{}'::jsonb,
  service_capabilities JSONB NOT NULL DEFAULT '{}'::jsonb,
  compatibility JSONB NOT NULL DEFAULT '{}'::jsonb,

  source_type VARCHAR(40) NOT NULL DEFAULT 'PROVIDER',
  source_reference VARCHAR(500),
  version INTEGER NOT NULL DEFAULT 1,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CHECK (listing_kind IN ('SALE','RENTAL','SALE_RENTAL','SERVICE','BUNDLE','SUBSCRIPTION')),
  CHECK (listing_status IN ('DRAFT','AI_REVIEW','HUMAN_REVIEW','APPROVED','PUBLISHED','SUSPENDED','ARCHIVED','REJECTED'))
);

CREATE INDEX IF NOT EXISTS idx_universal_listings_market_section
  ON universal_listings(market_id,section_id,listing_status);
CREATE INDEX IF NOT EXISTS idx_universal_listings_category
  ON universal_listings(category_id,listing_status);
CREATE INDEX IF NOT EXISTS idx_universal_listings_provider
  ON universal_listings(provider_id,listing_status);
CREATE INDEX IF NOT EXISTS idx_universal_listings_kind
  ON universal_listings(listing_kind,listing_status);
CREATE INDEX IF NOT EXISTS idx_universal_listings_attributes_gin
  ON universal_listings USING GIN(attributes);
CREATE INDEX IF NOT EXISTS idx_universal_listings_specs_gin
  ON universal_listings USING GIN(specifications);
CREATE INDEX IF NOT EXISTS idx_universal_listings_tags_gin
  ON universal_listings USING GIN(tags);

-- ---------------------------------------------------------
-- 3) Universal product/service variants
--    One listing may represent many configurations.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_variants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  variant_code VARCHAR(160),
  barcode VARCHAR(160),
  sku VARCHAR(160),
  serial_number VARCHAR(240),
  external_identifier VARCHAR(240),
  variant_name VARCHAR(300),
  attributes JSONB NOT NULL DEFAULT '{}'::jsonb,
  dimensions JSONB NOT NULL DEFAULT '{}'::jsonb,
  technical_specifications JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(listing_id,variant_code)
);

CREATE INDEX IF NOT EXISTS idx_listing_variants_listing
  ON listing_variants(listing_id,status);
CREATE INDEX IF NOT EXISTS idx_listing_variants_barcode
  ON listing_variants(barcode);

-- ---------------------------------------------------------
-- 4) Physical/digital/service units
--    Allows an offer to point to the actual rentable/sellable unit.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  variant_id UUID REFERENCES listing_variants(id) ON DELETE SET NULL,
  unit_code VARCHAR(180),
  asset_identifier VARCHAR(240),
  unit_type VARCHAR(80),
  quantity NUMERIC(20,6) NOT NULL DEFAULT 1,
  status VARCHAR(40) NOT NULL DEFAULT 'AVAILABLE',
  condition_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  technical_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  location_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_units_listing_status
  ON listing_units(listing_id,status);

-- ---------------------------------------------------------
-- 5) Flexible attribute definitions and values per market/category
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_attribute_definitions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id) ON DELETE CASCADE,
  section_id UUID REFERENCES market_sections(id) ON DELETE CASCADE,
  category_id UUID REFERENCES categories(id) ON DELETE CASCADE,
  attribute_code VARCHAR(160) NOT NULL,
  display_name VARCHAR(300) NOT NULL,
  data_type VARCHAR(40) NOT NULL,
  unit_code VARCHAR(40),
  required BOOLEAN NOT NULL DEFAULT FALSE,
  searchable BOOLEAN NOT NULL DEFAULT FALSE,
  filterable BOOLEAN NOT NULL DEFAULT FALSE,
  sortable BOOLEAN NOT NULL DEFAULT FALSE,
  validation_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  allowed_values JSONB NOT NULL DEFAULT '[]'::jsonb,
  display_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,section_id,category_id,attribute_code,version)
);

CREATE INDEX IF NOT EXISTS idx_listing_attribute_defs_scope
  ON listing_attribute_definitions(market_id,section_id,category_id,enabled);

CREATE TABLE IF NOT EXISTS listing_attribute_values (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  attribute_definition_id UUID NOT NULL REFERENCES listing_attribute_definitions(id),
  value_text TEXT,
  value_number NUMERIC(30,10),
  value_boolean BOOLEAN,
  value_date DATE,
  value_datetime TIMESTAMPTZ,
  value_json JSONB,
  value_unit_code VARCHAR(40),
  normalized_value JSONB,
  source VARCHAR(40) NOT NULL DEFAULT 'PROVIDER',
  confidence NUMERIC(6,5),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_attr_values_listing
  ON listing_attribute_values(listing_id,attribute_definition_id);
CREATE INDEX IF NOT EXISTS idx_listing_attr_values_number
  ON listing_attribute_values(attribute_definition_id,value_number);

-- ---------------------------------------------------------
-- 6) Global identifiers / standards / references
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_identifiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  identifier_type VARCHAR(80) NOT NULL,
  identifier_value VARCHAR(500) NOT NULL,
  issuing_country VARCHAR(3),
  issuer VARCHAR(250),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(identifier_type,identifier_value)
);

CREATE INDEX IF NOT EXISTS idx_listing_identifiers_listing
  ON listing_identifiers(listing_id,identifier_type);

-- ---------------------------------------------------------
-- 7) Listing media / technical documents metadata
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  asset_type VARCHAR(60) NOT NULL,
  storage_key VARCHAR(1000) NOT NULL,
  mime_type VARCHAR(160),
  file_size_bytes BIGINT,
  content_hash VARCHAR(128),
  language_code VARCHAR(16),
  title VARCHAR(500),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  moderation_status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_assets_listing
  ON listing_assets(listing_id,asset_type,moderation_status);

-- ---------------------------------------------------------
-- 8) Universal pricing rules
--    Pricing remains data/policy-driven, not hard-coded.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  price_type VARCHAR(60) NOT NULL,
  currency_code VARCHAR(3) NOT NULL,
  amount NUMERIC(20,6) NOT NULL,
  billing_unit VARCHAR(60),
  minimum_quantity NUMERIC(20,6),
  maximum_quantity NUMERIC(20,6),
  minimum_duration NUMERIC(20,6),
  duration_unit VARCHAR(40),
  valid_from TIMESTAMPTZ,
  valid_to TIMESTAMPTZ,
  conditions JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_prices_active
  ON listing_prices(listing_id,enabled,valid_from,valid_to);

-- ---------------------------------------------------------
-- 9) Geographic / delivery / service coverage constraints
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_service_coverage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  coverage_type VARCHAR(40) NOT NULL,
  location_id UUID REFERENCES locations(id) ON DELETE SET NULL,
  geometry_json JSONB,
  radius_meters NUMERIC(20,6),
  rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_coverage_listing
  ON listing_service_coverage(listing_id,enabled);

-- ---------------------------------------------------------
-- 10) Compliance / safety / eligibility data
--     Policy-driven and reviewable; does not grant approval by itself.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_compliance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  compliance_type VARCHAR(100) NOT NULL,
  jurisdiction_code VARCHAR(32),
  status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
  reference_number VARCHAR(300),
  expires_at TIMESTAMPTZ,
  evidence JSONB NOT NULL DEFAULT '{}'::jsonb,
  reviewer_actor_id UUID,
  reviewed_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_compliance_scope
  ON listing_compliance(listing_id,compliance_type,jurisdiction_code,status);

-- ---------------------------------------------------------
-- 11) Listing versions / audit snapshot
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS universal_listing_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  snapshot JSONB NOT NULL,
  change_reason VARCHAR(500),
  actor_user_id UUID,
  request_id VARCHAR(200),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(listing_id,version)
);

CREATE INDEX IF NOT EXISTS idx_universal_listing_versions_listing
  ON universal_listing_versions(listing_id,version DESC);

-- ---------------------------------------------------------
-- 12) Extension registry
--     Allows future technologies/standards/connectors to be registered
--     without altering the core ledger/security schema.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS extension_registry (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  extension_key VARCHAR(180) UNIQUE NOT NULL,
  extension_type VARCHAR(80) NOT NULL,
  version VARCHAR(80) NOT NULL,
  vendor_name VARCHAR(300),
  capabilities JSONB NOT NULL DEFAULT '{}'::jsonb,
  configuration_schema JSONB NOT NULL DEFAULT '{}'::jsonb,
  compatibility JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(40) NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------
-- 13) Marketplace-wide policy flag
-- ---------------------------------------------------------
INSERT INTO policy_configs(key,value_json,description) VALUES
('platform.universal_market.enabled','true','قاعدة هلا قادرة على تمثيل أي سلعة/أصل/معدة/مكان/خدمة/حزمة/اشتراك قابل للبيع أو للتأجير وفق السياسة والقانون'),
('platform.universal_market.dynamic_attributes','true','خصائص الأصناف والأسواق ديناميكية ولا تتطلب إضافة أعمدة لكل نوع جديد'),
('platform.universal_market.dynamic_variants','true','دعم المتغيرات والمواصفات والتجهيزات المختلفة داخل العرض الواحد'),
('platform.universal_market.dynamic_standards','true','دعم المعرفات والمعايير الدولية عبر سجل مرن دون تغيير النواة'),
('platform.universal_market.dynamic_extensions','true','دعم تقنيات وموصلات وامتدادات مستقبلية عبر Extension Registry'),
('platform.core.strict_finance_security','true','النواة المالية والأمنية والصلاحيات والحالات الحرجة تبقى محكومة وليست ديناميكية بلا ضوابط')
ON CONFLICT(key) DO NOTHING;

COMMIT;


-- Hala Universal Market Database v4.5 Hardening
-- Apply AFTER: base schema + v4.2 + v4.3 + v4.4 Universal Market
-- Purpose: close integration gaps for simple supply/demand, lifecycle history,
-- pricing/rental periods, matching, multilingual presentation, and governed publishing.
BEGIN;
SET search_path TO hala, public;

-- 1) Stronger listing kind relation and lifecycle history
ALTER TABLE universal_listings
  ADD COLUMN IF NOT EXISTS listing_kind_id UUID REFERENCES listing_kinds(id),
  ADD COLUMN IF NOT EXISTS language_code VARCHAR(16) DEFAULT 'ar',
  ADD COLUMN IF NOT EXISTS country_code VARCHAR(3),
  ADD COLUMN IF NOT EXISTS visibility VARCHAR(30) NOT NULL DEFAULT 'PUBLIC',
  ADD COLUMN IF NOT EXISTS moderation_reason TEXT,
  ADD COLUMN IF NOT EXISTS published_by UUID REFERENCES users(id),
  ADD COLUMN IF NOT EXISTS policy_version VARCHAR(120);

UPDATE universal_listings ul
SET listing_kind_id = lk.id
FROM listing_kinds lk
WHERE ul.listing_kind_id IS NULL AND ul.listing_kind = lk.code;

ALTER TABLE universal_listings
  ADD CONSTRAINT chk_universal_listing_visibility
  CHECK (visibility IN ('PUBLIC','PRIVATE','MATCH_ONLY','SUSPENDED'));

CREATE INDEX IF NOT EXISTS idx_universal_listings_visibility
  ON universal_listings(visibility,listing_status,market_id);

CREATE TABLE IF NOT EXISTS universal_listing_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  old_status VARCHAR(40),
  new_status VARCHAR(40) NOT NULL,
  reason VARCHAR(500),
  actor_user_id UUID REFERENCES users(id),
  request_id VARCHAR(200),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_universal_listing_history_listing
  ON universal_listing_history(listing_id,created_at DESC);

-- 2) Multilingual display values without duplicating the listing
CREATE TABLE IF NOT EXISTS listing_translations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  language_code VARCHAR(16) NOT NULL,
  title VARCHAR(500),
  short_description TEXT,
  long_description TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(listing_id,language_code,version)
);
CREATE INDEX IF NOT EXISTS idx_listing_translations_lookup
  ON listing_translations(listing_id,language_code,version DESC);

-- 3) Demand: a customer can request something even when no listing exists.
CREATE TABLE IF NOT EXISTS demand_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES users(id),
  market_id UUID REFERENCES markets(id),
  section_id UUID REFERENCES market_sections(id),
  category_id UUID REFERENCES categories(id),
  operation_type VARCHAR(40) NOT NULL,
  title VARCHAR(500) NOT NULL,
  description TEXT,
  requested_attributes JSONB NOT NULL DEFAULT '{}'::jsonb,
  quantity NUMERIC(20,6),
  unit_code VARCHAR(40),
  budget_min NUMERIC(20,6),
  budget_max NUMERIC(20,6),
  currency_code VARCHAR(3),
  needed_from TIMESTAMPTZ,
  needed_to TIMESTAMPTZ,
  location_id UUID REFERENCES locations(id),
  location_requirements JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(40) NOT NULL DEFAULT 'OPEN',
  visibility VARCHAR(30) NOT NULL DEFAULT 'MATCHED_PROVIDERS',
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (operation_type IN ('BUY','RENT','BUY_OR_RENT','SERVICE','QUOTE')),
  CHECK (status IN ('DRAFT','OPEN','MATCHING','OFFERED','NEGOTIATING','FULFILLED','CANCELLED','EXPIRED')),
  CHECK (visibility IN ('MATCHED_PROVIDERS','PUBLIC','PRIVATE')),
  CHECK (budget_min IS NULL OR budget_min >= 0),
  CHECK (budget_max IS NULL OR budget_max >= 0),
  CHECK (budget_min IS NULL OR budget_max IS NULL OR budget_min <= budget_max),
  CHECK (needed_to IS NULL OR needed_from IS NULL OR needed_to > needed_from)
);
CREATE INDEX IF NOT EXISTS idx_demand_requests_matching
  ON demand_requests(market_id,category_id,operation_type,status,needed_from,needed_to);
CREATE INDEX IF NOT EXISTS idx_demand_requests_attrs_gin
  ON demand_requests USING GIN(requested_attributes);

-- 4) Provider responses to demand; response is not a booking until customer accepts.
CREATE TABLE IF NOT EXISTS demand_offers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  demand_request_id UUID NOT NULL REFERENCES demand_requests(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES providers(id),
  listing_id UUID REFERENCES universal_listings(id),
  proposed_title VARCHAR(500),
  proposed_price NUMERIC(20,6),
  currency_code VARCHAR(3),
  proposed_terms JSONB NOT NULL DEFAULT '{}'::jsonb,
  availability_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(40) NOT NULL DEFAULT 'SUBMITTED',
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status IN ('SUBMITTED','UNDER_REVIEW','ACCEPTED','DECLINED','EXPIRED','WITHDRAWN'))
);
CREATE INDEX IF NOT EXISTS idx_demand_offers_request
  ON demand_offers(demand_request_id,status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_demand_offers_provider
  ON demand_offers(provider_id,status);

-- 5) Explicit matching records: explainable and auditable, not an opaque AI-only decision.
CREATE TABLE IF NOT EXISTS supply_demand_matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  demand_request_id UUID NOT NULL REFERENCES demand_requests(id) ON DELETE CASCADE,
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  match_method VARCHAR(40) NOT NULL,
  score NUMERIC(8,5),
  matched_factors JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(30) NOT NULL DEFAULT 'PROPOSED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(demand_request_id,listing_id),
  CHECK (match_method IN ('RULES','AI','HYBRID','MANUAL')),
  CHECK (status IN ('PROPOSED','SHOWN','DISMISSED','CONTACTED','CONVERTED','EXPIRED'))
);
CREATE INDEX IF NOT EXISTS idx_supply_demand_matches_demand
  ON supply_demand_matches(demand_request_id,status,score DESC);

-- 6) Rental periods / operational pricing. Keeps price data separate from catalog identity.
CREATE TABLE IF NOT EXISTS listing_rental_terms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  duration_unit VARCHAR(30) NOT NULL,
  minimum_duration NUMERIC(20,6) NOT NULL,
  maximum_duration NUMERIC(20,6),
  billing_rule VARCHAR(40) NOT NULL DEFAULT 'PER_UNIT',
  deposit_required BOOLEAN NOT NULL DEFAULT FALSE,
  cancellation_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  conditions JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  CHECK (minimum_duration > 0),
  CHECK (maximum_duration IS NULL OR maximum_duration >= minimum_duration),
  CHECK (billing_rule IN ('PER_UNIT','PER_PERIOD','PRO_RATA','QUOTE'))
);
CREATE INDEX IF NOT EXISTS idx_listing_rental_terms
  ON listing_rental_terms(listing_id,enabled);

-- 7) Keep provider/source evidence separate from publication decision.
CREATE TABLE IF NOT EXISTS listing_source_evidence (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  source_type VARCHAR(50) NOT NULL,
  source_reference VARCHAR(1000),
  evidence_hash VARCHAR(128),
  verification_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
  verified_by UUID REFERENCES users(id),
  verified_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (verification_status IN ('PENDING','VERIFIED','REJECTED','EXPIRED'))
);
CREATE INDEX IF NOT EXISTS idx_listing_source_evidence
  ON listing_source_evidence(listing_id,verification_status);

-- 8) Global unit-of-measure registry; avoids hard-coded units in future markets.
CREATE TABLE IF NOT EXISTS unit_registry (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_code VARCHAR(60) UNIQUE NOT NULL,
  dimension_code VARCHAR(60) NOT NULL,
  symbol VARCHAR(40),
  name_ar VARCHAR(160),
  name_en VARCHAR(160),
  conversion_to_base NUMERIC(40,20),
  base_unit_code VARCHAR(60),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 9) Matching/visibility policies are configuration, not hard-coded behavior.
INSERT INTO policy_configs(key,value_json,description) VALUES
('market.supply_demand.enabled','true','تمكين مسار العرض والطلب العام'),
('market.supply_demand.simple_customer_flow','true','العميل يطلب أو يعرض دون معرفة بنية البيانات الداخلية'),
('market.supply_demand.matching_methods','["RULES","AI","HYBRID","MANUAL"]','طرق المطابقة المسموح بها'),
('market.listing.universal_scope','true','السوق قادر على تمثيل أي عرض قانوني للبيع أو التأجير أو الخدمة'),
('market.listing.publish_requires_review','true','لا يصبح العرض منشوراً إلا بعد بوابة المراجعة المعتمدة')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json, description=EXCLUDED.description;

COMMIT;


-- Hala v4.6 Market Builder
-- Apply after 001_base + 002_v4_2 + 003_pilot_seed + 004_ai_extensibility_v4_3 + 005_v4_4 + 006_v4_5.
-- Goal: one shared Hala UI/Backend, markets created and configured from Admin as data.
BEGIN;
SET search_path TO hala, public;

-- Existing v4.3 market statuses are normalized to the v4.6 builder lifecycle.
ALTER TABLE markets DROP CONSTRAINT IF EXISTS markets_status_check;
ALTER TABLE markets DROP CONSTRAINT IF EXISTS chk_markets_builder_status;
UPDATE markets
SET status = CASE lower(status)
  WHEN 'draft' THEN 'DRAFT'
  WHEN 'review' THEN 'DRAFT'
  WHEN 'active' THEN 'ACTIVE'
  WHEN 'suspended' THEN 'PAUSED'
  WHEN 'archived' THEN 'ARCHIVED'
  ELSE 'DRAFT'
END;

ALTER TABLE markets
  ALTER COLUMN status SET DEFAULT 'DRAFT',
  ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS updated_by UUID REFERENCES users(id),
  ADD COLUMN IF NOT EXISTS version INTEGER NOT NULL DEFAULT 1;

ALTER TABLE markets
  ADD CONSTRAINT chk_markets_builder_status
  CHECK (status IN ('DRAFT','ACTIVE','PAUSED','ARCHIVED'));

CREATE INDEX IF NOT EXISTS idx_markets_builder_status
  ON markets(status,is_deleted,sort_order);

CREATE TABLE IF NOT EXISTS market_provider_memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
  joined_at TIMESTAMPTZ,
  suspended_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,provider_id),
  CHECK (status IN ('PENDING','ACTIVE','SUSPENDED','LEFT'))
);
CREATE INDEX IF NOT EXISTS idx_market_provider_memberships_market
  ON market_provider_memberships(market_id,status);
CREATE INDEX IF NOT EXISTS idx_market_provider_memberships_provider
  ON market_provider_memberships(provider_id,status);

CREATE TABLE IF NOT EXISTS market_ui_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  config_key VARCHAR(160) NOT NULL,
  language_code VARCHAR(16) NOT NULL DEFAULT 'ar',
  config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
  created_by UUID REFERENCES users(id),
  published_by UUID REFERENCES users(id),
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,config_key,language_code,version),
  CHECK (status IN ('DRAFT','PUBLISHED','ARCHIVED'))
);
CREATE INDEX IF NOT EXISTS idx_market_ui_configs_lookup
  ON market_ui_configs(market_id,language_code,status,config_key,version DESC);

CREATE TABLE IF NOT EXISTS market_operation_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  operation_code VARCHAR(40) NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  label_ar VARCHAR(160),
  label_en VARCHAR(160),
  settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,operation_code,version),
  CHECK (operation_code IN ('BUY','RENT','BUY_OR_RENT','SERVICE','QUOTE'))
);
CREATE INDEX IF NOT EXISTS idx_market_operation_configs
  ON market_operation_configs(market_id,enabled,operation_code,version DESC);

CREATE TABLE IF NOT EXISTS market_policy_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  policy_key VARCHAR(180) NOT NULL,
  policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
  created_by UUID REFERENCES users(id),
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,policy_key,version),
  CHECK (status IN ('DRAFT','PENDING_REVIEW','APPROVED','ARCHIVED'))
);
CREATE INDEX IF NOT EXISTS idx_market_policy_configs
  ON market_policy_configs(market_id,status,policy_key,version DESC);

CREATE TABLE IF NOT EXISTS market_change_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id) ON DELETE SET NULL,
  actor_user_id UUID REFERENCES users(id),
  object_type VARCHAR(80) NOT NULL,
  object_id UUID,
  action VARCHAR(30) NOT NULL,
  request_id VARCHAR(200),
  before_json JSONB,
  after_json JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (action IN ('CREATE','UPDATE','ACTIVATE','PAUSE','ARCHIVE','RESTORE','SOFT_DELETE'))
);
CREATE INDEX IF NOT EXISTS idx_market_change_log_market
  ON market_change_log(market_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_market_change_log_object
  ON market_change_log(object_type,object_id,created_at DESC);

-- Permission is data, not a hard-coded special account.
INSERT INTO permissions(code,description)
VALUES ('market.builder.manage','إنشاء وتعديل وتفعيل وإيقاف وأرشفة إعدادات الأسواق من منشئ الأسواق')
ON CONFLICT(code) DO NOTHING;


CREATE TABLE IF NOT EXISTS role_permissions (
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY(role_id,permission_id)
);
CREATE INDEX IF NOT EXISTS idx_role_permissions_permission ON role_permissions(permission_id);


INSERT INTO policy_configs(key,value_json,description) VALUES
('market.builder.shared_ui','true','كل الأسواق تستخدم نفس واجهة وصفحات ولوحات هلا وتختلف بالبيانات والإعدادات'),
('market.builder.admin_crud','true','مدير النظام المخول يدير الأسواق دون برمجة جديدة'),
('market.builder.soft_delete','true','الحذف التشغيلي يحفظ الأثر التاريخي عند الحاجة'),
('market.builder.financial_immutability','true','منشئ الأسواق لا يكتب Ledger أو أرصدة مباشرة'),
('market.builder.demand_simple_flow','true','الطلب يبدأ بأقل بيانات لازمة ثم تتم المطابقة في الخلفية'),
('market.builder.offer_simple_flow','true','المنتسب يرفع بيانات وصور وفيديو وأسعار وفق نوع السوق')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json, description=EXCLUDED.description;

COMMIT;

