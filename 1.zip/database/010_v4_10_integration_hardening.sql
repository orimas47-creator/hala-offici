-- Hala v4.10 integration hardening.
BEGIN;
SET search_path TO hala, public;
ALTER TABLE otp_events ADD COLUMN IF NOT EXISTS ip_address INET;
CREATE INDEX IF NOT EXISTS idx_otp_ip_purpose_created ON otp_events(ip_address,purpose,created_at DESC);
INSERT INTO policy_configs(key,value_json,description) VALUES
('security.otp.ip_rate_limit_multiplier','5','حد IP النسبي لطلبات OTP'),
('security.otp.cooldown_seconds','30','فترة الانتظار بين طلبات OTP لنفس الرقم'),
('payments.webhook.settlement_mode','VERIFY_OR_FAIL','أحداث الدفع الموقعة تقوم بالتسوية فقط لأحداث التحقق/الفشل'),
('runtime.readiness_requires_database','true','جاهزية الخدمة لا تعتبر مكتملة دون اتصال قاعدة البيانات')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;
COMMIT;

BEGIN;
SET search_path TO hala, public;
CREATE TABLE IF NOT EXISTS provider_applications (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id UUID NOT NULL REFERENCES users(id),
 market_id UUID REFERENCES markets(id),
 provider_id UUID REFERENCES providers(id),
 business_name VARCHAR(250),
 application_data JSONB NOT NULL DEFAULT '{}'::jsonb,
 status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
 reviewed_by UUID REFERENCES users(id),
 reviewed_at TIMESTAMPTZ,
 review_reason TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 CONSTRAINT provider_applications_status_check CHECK(status IN ('PENDING','UNDER_REVIEW','APPROVED','REJECTED','CANCELLED'))
);
CREATE INDEX IF NOT EXISTS idx_provider_applications_user_status ON provider_applications(user_id,status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_provider_applications_market_status ON provider_applications(market_id,status,created_at DESC);
COMMIT;
