-- Hala v4.6 Market Builder
-- Apply after 001_base + 002_v4_2 + 003_pilot_seed + 004_ai_extensibility_v4_3 + 005_v4_4 + 006_v4_5.
-- Goal: one shared Hala UI/Backend, markets created and configured from Admin as data.
BEGIN;
SET search_path TO hala, public;

-- Existing v4.3 market statuses are normalized to the v4.6 builder lifecycle.
ALTER TABLE markets DROP CONSTRAINT IF EXISTS markets_status_check;
ALTER TABLE markets DROP CONSTRAINT IF EXISTS chk_markets_builder_status;
UPDATE markets
SET status = CASE lower(status)
  WHEN 'draft' THEN 'DRAFT'
  WHEN 'review' THEN 'DRAFT'
  WHEN 'active' THEN 'ACTIVE'
  WHEN 'suspended' THEN 'PAUSED'
  WHEN 'archived' THEN 'ARCHIVED'
  ELSE 'DRAFT'
END;

ALTER TABLE markets
  ALTER COLUMN status SET DEFAULT 'DRAFT',
  ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS updated_by UUID REFERENCES users(id),
  ADD COLUMN IF NOT EXISTS version INTEGER NOT NULL DEFAULT 1;

ALTER TABLE markets
  ADD CONSTRAINT chk_markets_builder_status
  CHECK (status IN ('DRAFT','ACTIVE','PAUSED','ARCHIVED'));

CREATE INDEX IF NOT EXISTS idx_markets_builder_status
  ON markets(status,is_deleted,sort_order);

CREATE TABLE IF NOT EXISTS market_provider_memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
  joined_at TIMESTAMPTZ,
  suspended_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,provider_id),
  CHECK (status IN ('PENDING','ACTIVE','SUSPENDED','LEFT'))
);
CREATE INDEX IF NOT EXISTS idx_market_provider_memberships_market
  ON market_provider_memberships(market_id,status);
CREATE INDEX IF NOT EXISTS idx_market_provider_memberships_provider
  ON market_provider_memberships(provider_id,status);

CREATE TABLE IF NOT EXISTS market_ui_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  config_key VARCHAR(160) NOT NULL,
  language_code VARCHAR(16) NOT NULL DEFAULT 'ar',
  config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
  created_by UUID REFERENCES users(id),
  published_by UUID REFERENCES users(id),
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,config_key,language_code,version),
  CHECK (status IN ('DRAFT','PUBLISHED','ARCHIVED'))
);
CREATE INDEX IF NOT EXISTS idx_market_ui_configs_lookup
  ON market_ui_configs(market_id,language_code,status,config_key,version DESC);

CREATE TABLE IF NOT EXISTS market_operation_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  operation_code VARCHAR(40) NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  label_ar VARCHAR(160),
  label_en VARCHAR(160),
  settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,operation_code,version),
  CHECK (operation_code IN ('BUY','RENT','BUY_OR_RENT','SERVICE','QUOTE'))
);
CREATE INDEX IF NOT EXISTS idx_market_operation_configs
  ON market_operation_configs(market_id,enabled,operation_code,version DESC);

CREATE TABLE IF NOT EXISTS market_policy_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
  policy_key VARCHAR(180) NOT NULL,
  policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
  created_by UUID REFERENCES users(id),
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,policy_key,version),
  CHECK (status IN ('DRAFT','PENDING_REVIEW','APPROVED','ARCHIVED'))
);
CREATE INDEX IF NOT EXISTS idx_market_policy_configs
  ON market_policy_configs(market_id,status,policy_key,version DESC);

CREATE TABLE IF NOT EXISTS market_change_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id) ON DELETE SET NULL,
  actor_user_id UUID REFERENCES users(id),
  object_type VARCHAR(80) NOT NULL,
  object_id UUID,
  action VARCHAR(30) NOT NULL,
  request_id VARCHAR(200),
  before_json JSONB,
  after_json JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (action IN ('CREATE','UPDATE','ACTIVATE','PAUSE','ARCHIVE','RESTORE','SOFT_DELETE'))
);
CREATE INDEX IF NOT EXISTS idx_market_change_log_market
  ON market_change_log(market_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_market_change_log_object
  ON market_change_log(object_type,object_id,created_at DESC);

-- Permission is data, not a hard-coded special account.
INSERT INTO permissions(code,description)
VALUES ('market.builder.manage','إنشاء وتعديل وتفعيل وإيقاف وأرشفة إعدادات الأسواق من منشئ الأسواق')
ON CONFLICT(code) DO NOTHING;


CREATE TABLE IF NOT EXISTS role_permissions (
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY(role_id,permission_id)
);
CREATE INDEX IF NOT EXISTS idx_role_permissions_permission ON role_permissions(permission_id);


INSERT INTO policy_configs(key,value_json,description) VALUES
('market.builder.shared_ui','true','كل الأسواق تستخدم نفس واجهة وصفحات ولوحات هلا وتختلف بالبيانات والإعدادات'),
('market.builder.admin_crud','true','مدير النظام المخول يدير الأسواق دون برمجة جديدة'),
('market.builder.soft_delete','true','الحذف التشغيلي يحفظ الأثر التاريخي عند الحاجة'),
('market.builder.financial_immutability','true','منشئ الأسواق لا يكتب Ledger أو أرصدة مباشرة'),
('market.builder.demand_simple_flow','true','الطلب يبدأ بأقل بيانات لازمة ثم تتم المطابقة في الخلفية'),
('market.builder.offer_simple_flow','true','المنتسب يرفع بيانات وصور وفيديو وأسعار وفق نوع السوق')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json, description=EXCLUDED.description;

COMMIT;
