-- Hala v4.17 Security: webhook replay defense + AI telemetry resilience
BEGIN;
SET search_path TO hala, public;

INSERT INTO policy_configs(key,value_json,description) VALUES
('security.webhook_require_timestamp','true','إلزام Webhook الخارجي بتوقيع زمني في التشغيل الإنتاجي لمنع إعادة الإرسال القديمة'),
('security.webhook_timestamp_tolerance_seconds','300','الحد الأقصى لانحراف توقيت Webhook المقبول'),
('ai.platform_supervisor.telemetry_fail_open','true','تعطل قناة مراقبة الذكاء المركزي لا يجب أن يعطل العمليات التجارية الأساسية مع بقاء المراقبة والأمن المستقلين فعالين')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;

COMMIT;
