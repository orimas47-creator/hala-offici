-- Hala v4.11 prelaunch resilience.
BEGIN;
SET search_path TO hala, public;

ALTER TABLE webhook_inbox ADD COLUMN IF NOT EXISTS attempt_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE webhook_inbox ADD COLUMN IF NOT EXISTS next_attempt_at TIMESTAMPTZ;
ALTER TABLE webhook_inbox ADD COLUMN IF NOT EXISTS locked_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_webhook_queue_retry ON webhook_inbox(status,next_attempt_at,received_at);

CREATE TABLE IF NOT EXISTS platform_health_snapshots (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 observed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 markets_active INTEGER NOT NULL DEFAULT 0,
 listings_published INTEGER NOT NULL DEFAULT 0,
 pending_payments INTEGER NOT NULL DEFAULT 0,
 webhook_backlog INTEGER NOT NULL DEFAULT 0,
 open_incidents INTEGER NOT NULL DEFAULT 0,
 failed_otp_24h INTEGER NOT NULL DEFAULT 0,
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_platform_health_observed ON platform_health_snapshots(observed_at DESC);

INSERT INTO policy_configs(key,value_json,description) VALUES
('runtime.webhook_max_attempts','8','الحد الأعلى لإعادة معالجة Webhook قبل التصعيد للمراجعة'),
('runtime.health_snapshot_interval_seconds','30','الفاصل الزمني لتحديث حالة المنصة المركزية')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;

COMMIT;
