-- Hala v4.7: platform control plane, secure sessions, global portal, AI supervision.
BEGIN;
SET search_path TO hala, public;

-- Secure authenticated sessions. X-Actor-Id remains test-only and is rejected in production.
CREATE TABLE IF NOT EXISTS auth_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash VARCHAR(128) NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at TIMESTAMPTZ,
  ip_address INET,
  user_agent TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_auth_sessions_user ON auth_sessions(user_id,revoked_at,expires_at);

ALTER TABLE otp_events ADD COLUMN IF NOT EXISTS attempt_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE otp_events ADD COLUMN IF NOT EXISTS last_attempt_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_otp_phone_purpose_created ON otp_events(phone,purpose,created_at DESC);

-- Mark a completed market as the reusable reference template for future markets.
ALTER TABLE markets ADD COLUMN IF NOT EXISTS template_market_id UUID REFERENCES markets(id);
ALTER TABLE markets ADD COLUMN IF NOT EXISTS is_reference_template BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_markets_template ON markets(template_market_id,is_reference_template,status);

-- Global Hala portal: market-neutral rails and approved advertising.
CREATE TABLE IF NOT EXISTS global_portal_rails (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rail_key VARCHAR(120) NOT NULL UNIQUE,
  market_id UUID REFERENCES markets(id) ON DELETE SET NULL,
  title_ar VARCHAR(250) NOT NULL,
  title_en VARCHAR(250),
  ranking_code VARCHAR(80) NOT NULL DEFAULT 'NEWEST',
  max_items INTEGER NOT NULL DEFAULT 12,
  filter_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  sort_order INTEGER NOT NULL DEFAULT 0,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  version INTEGER NOT NULL DEFAULT 1,
  updated_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (max_items BETWEEN 1 AND 100),
  CHECK (ranking_code IN ('NEWEST','TOP_RENTAL','TOP_RATING','TOP_QUALITY','TOP_DEMAND','TOP_MATCH','MIXED'))
);
CREATE INDEX IF NOT EXISTS idx_global_portal_rails_enabled ON global_portal_rails(enabled,sort_order);

CREATE TABLE IF NOT EXISTS global_portal_ads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id) ON DELETE SET NULL,
  provider_id UUID REFERENCES providers(id) ON DELETE SET NULL,
  advertiser_name VARCHAR(300),
  title VARCHAR(300) NOT NULL,
  body TEXT,
  asset_url TEXT,
  target_path TEXT,
  placement VARCHAR(100) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
  start_at TIMESTAMPTZ,
  end_at TIMESTAMPTZ,
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status IN ('DRAFT','PENDING','APPROVED','ACTIVE','PAUSED','ARCHIVED','REJECTED'))
);
CREATE INDEX IF NOT EXISTS idx_global_portal_ads_active ON global_portal_ads(status,start_at,end_at,placement,market_id);

-- Platform supervisor is above market-level AI agents. It can observe all markets,
-- issue guarded recommendations and safe quarantine actions, but never edits money or roles.
CREATE TABLE IF NOT EXISTS ai_supervisor_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  supervisor_key VARCHAR(120) NOT NULL UNIQUE DEFAULT 'platform_supervisor',
  display_name VARCHAR(200) NOT NULL DEFAULT 'Hala Platform Supervisor AI',
  mode VARCHAR(30) NOT NULL DEFAULT 'GUARDED',
  provider VARCHAR(120),
  model VARCHAR(200),
  policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (mode IN ('ADVISORY','GUARDED','EMERGENCY_LOCKDOWN'))
);
CREATE TABLE IF NOT EXISTS ai_market_bindings (
  market_id UUID PRIMARY KEY REFERENCES markets(id) ON DELETE CASCADE,
  supervisor_id UUID NOT NULL REFERENCES ai_supervisor_configs(id),
  local_ai_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  local_ai_policy JSONB NOT NULL DEFAULT '{}'::jsonb,
  inheritance_mode VARCHAR(30) NOT NULL DEFAULT 'INHERIT_AND_RESTRICT',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (inheritance_mode IN ('INHERIT','INHERIT_AND_RESTRICT'))
);
CREATE TABLE IF NOT EXISTS ai_supervisor_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  supervisor_id UUID NOT NULL REFERENCES ai_supervisor_configs(id),
  market_id UUID REFERENCES markets(id) ON DELETE SET NULL,
  event_key VARCHAR(160) NOT NULL,
  resource_type VARCHAR(100),
  resource_id UUID,
  severity VARCHAR(20) NOT NULL DEFAULT 'INFO',
  risk_score NUMERIC(6,5) NOT NULL DEFAULT 0,
  source_ai_agent_id UUID REFERENCES ai_agents(id) ON DELETE SET NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(30) NOT NULL DEFAULT 'OBSERVED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ,
  CHECK (severity IN ('INFO','LOW','MEDIUM','HIGH','CRITICAL')),
  CHECK (status IN ('OBSERVED','QUEUED','REVIEWED','ESCALATED','RESOLVED'))
);
CREATE INDEX IF NOT EXISTS idx_ai_supervisor_events_queue ON ai_supervisor_events(status,created_at);
CREATE INDEX IF NOT EXISTS idx_ai_supervisor_events_market ON ai_supervisor_events(market_id,created_at DESC);

CREATE TABLE IF NOT EXISTS ai_supervisor_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  supervisor_event_id UUID NOT NULL REFERENCES ai_supervisor_events(id) ON DELETE CASCADE,
  action_code VARCHAR(120) NOT NULL,
  action_scope VARCHAR(100) NOT NULL,
  proposed_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  execution_status VARCHAR(30) NOT NULL DEFAULT 'PROPOSED',
  executed_by_rule BOOLEAN NOT NULL DEFAULT FALSE,
  executed_by_user_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  executed_at TIMESTAMPTZ,
  CHECK (execution_status IN ('PROPOSED','APPROVED','EXECUTED','REJECTED','FAILED'))
);
CREATE INDEX IF NOT EXISTS idx_ai_supervisor_actions_status ON ai_supervisor_actions(execution_status,created_at);

CREATE TABLE IF NOT EXISTS ai_supervisor_incidents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id) ON DELETE SET NULL,
  supervisor_event_id UUID REFERENCES ai_supervisor_events(id) ON DELETE SET NULL,
  incident_type VARCHAR(120) NOT NULL,
  severity VARCHAR(20) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
  summary TEXT NOT NULL,
  evidence_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  owner_user_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ,
  CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
  CHECK (status IN ('OPEN','ACKNOWLEDGED','MITIGATING','RESOLVED','FALSE_POSITIVE'))
);
CREATE INDEX IF NOT EXISTS idx_ai_supervisor_incidents_open ON ai_supervisor_incidents(status,severity,created_at);

INSERT INTO ai_supervisor_configs(supervisor_key,display_name,mode,policy_json)
VALUES ('platform_supervisor','Hala Platform Supervisor AI','GUARDED',
  '{"can_observe_all_markets":true,"can_restrict_publication":true,"can_quarantine_listings":true,"can_escalate_financial_anomalies":true,"can_directly_edit_money":false,"can_directly_change_roles":false,"can_override_legal_policy":false,"local_ai_must_inherit":true}'::jsonb)
ON CONFLICT(supervisor_key) DO UPDATE SET policy_json=EXCLUDED.policy_json,updated_at=now();

INSERT INTO policy_configs(key,value_json,description) VALUES
('security.require_bearer_auth','true','الإنتاج يعتمد على جلسة موثقة ولا يقبل X-Actor-Id كهوية'),
('security.allow_dev_actor_header','false','السماح بهوية الاختبار من Header خارج الإنتاج فقط'),
('security.otp_max_attempts','5','الحد الأعلى لمحاولات OTP للسجل الواحد'),
('security.otp_rate_window_minutes','10','نافذة حد طلبات OTP'),
('security.otp_max_requests_per_window','3','الحد الأعلى لطلبات OTP لنفس الهاتف في النافذة'),
('ai.platform_supervisor_hierarchy','true','ذكاء المنصة الأعلى يراقب جميع الأسواق والذكاء المحلي يرث سياساته'),
('global.portal.enabled','true','تفعيل بوابة هلا العالمية المحايدة عن الأسواق')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;


INSERT INTO global_portal_rails(rail_key,title_ar,ranking_code,max_items,sort_order,enabled)
VALUES
('events_top_rental','أفضل عروض التأجير في سوق المناسبات','TOP_RENTAL',12,10,true),
('events_top_rating','الأعلى تقييماً في سوق المناسبات','TOP_RATING',12,20,true),
('events_top_quality','الأعلى جودة في سوق المناسبات','TOP_QUALITY',12,30,true),
('medical_new_services','أحدث الخدمات والمنتجات الصحية','NEWEST',12,40,true),
('trade_new_services','أحدث خدمات التجارة والاستيراد والتصدير','NEWEST',12,50,true)
ON CONFLICT(rail_key) DO NOTHING;

COMMIT;
