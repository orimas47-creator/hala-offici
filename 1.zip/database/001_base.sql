-- Hala Platform Database v1.0
-- PostgreSQL + PostGIS
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE SCHEMA IF NOT EXISTS hala;
SET search_path TO hala, public;

CREATE TYPE account_type AS ENUM ('personal','agent','representative','professional');
CREATE TYPE provider_status AS ENUM ('pending','active','suspended','closed');
CREATE TYPE offer_status AS ENUM ('draft','ai_review','needs_correction','approved','published','rejected','archived');
CREATE TYPE listing_type AS ENUM ('rental','sale');
CREATE TYPE booking_status AS ENUM ('draft','hold','awaiting_payment','payment_pending','payment_verified','confirmed','alternate_activation','executing','completed','cancelled','disputed','refund_pending','refunded','expired');
CREATE TYPE payment_status AS ENUM ('created','pending','verified','failed','cancelled','refunded','partially_refunded');
CREATE TYPE payment_method AS ENUM ('wallet','bank','card','local_wallet','cash');
CREATE TYPE ledger_side AS ENUM ('debit','credit');
CREATE TYPE insurance_type AS ENUM ('cash','inkind','none');
CREATE TYPE document_status AS ENUM ('pending','verified','rejected','expired');
CREATE TYPE hold_status AS ENUM ('active','released','converted','expired');
CREATE TYPE unit_status AS ENUM ('available','reserved','maintenance','inactive','sold');

CREATE TABLE users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 phone VARCHAR(30) UNIQUE NOT NULL,
 full_name VARCHAR(200) NOT NULL,
 account_type account_type NOT NULL DEFAULT 'personal',
 password_hash TEXT,
 is_active BOOLEAN DEFAULT TRUE,
 created_at TIMESTAMPTZ DEFAULT now(),
 updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE roles (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name VARCHAR(80) UNIQUE NOT NULL, description TEXT);
CREATE TABLE permissions (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), code VARCHAR(120) UNIQUE NOT NULL, description TEXT);
CREATE TABLE user_roles (user_id UUID REFERENCES users(id) ON DELETE CASCADE, role_id UUID REFERENCES roles(id) ON DELETE CASCADE, PRIMARY KEY(user_id,role_id));
CREATE TABLE user_documents (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 document_type VARCHAR(100) NOT NULL, document_number VARCHAR(120), file_uri TEXT NOT NULL,
 status document_status DEFAULT 'pending', issued_at DATE, expires_at DATE, verified_by UUID REFERENCES users(id), verified_at TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE otp_events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID REFERENCES users(id), phone VARCHAR(30) NOT NULL,
 purpose VARCHAR(80) NOT NULL, code_hash TEXT NOT NULL, expires_at TIMESTAMPTZ NOT NULL, consumed_at TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE geographic_levels (id SMALLSERIAL PRIMARY KEY, code VARCHAR(40) UNIQUE NOT NULL, name_ar VARCHAR(100) NOT NULL);
CREATE TABLE locations (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), level_id SMALLINT NOT NULL REFERENCES geographic_levels(id),
 parent_id UUID REFERENCES locations(id), name_ar VARCHAR(200) NOT NULL, code VARCHAR(80),
 boundary GEOMETRY(MULTIPOLYGON,4326), center GEOMETRY(POINT,4326), UNIQUE(parent_id,name_ar)
);
CREATE TABLE user_locations (
 user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, location_id UUID NOT NULL REFERENCES locations(id),
 address_text TEXT, latitude NUMERIC(10,7), longitude NUMERIC(10,7)
);

CREATE TABLE providers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID UNIQUE NOT NULL REFERENCES users(id),
 business_name VARCHAR(250), status provider_status DEFAULT 'pending',
 subscription_started_at TIMESTAMPTZ, subscription_expires_at TIMESTAMPTZ,
 insurance_confirmed BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE agents (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID UNIQUE NOT NULL REFERENCES users(id),
 directorate_location_id UUID REFERENCES locations(id), status provider_status DEFAULT 'pending', created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE memberships (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), provider_id UUID NOT NULL REFERENCES providers(id),
 membership_number VARCHAR(100) UNIQUE NOT NULL, status VARCHAR(40) DEFAULT 'active', created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE serials (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), serial_number VARCHAR(120) UNIQUE NOT NULL,
 membership_id UUID REFERENCES memberships(id), owner_user_id UUID REFERENCES users(id),
 status VARCHAR(40) DEFAULT 'active', transferred_at TIMESTAMPTZ, transfer_deadline TIMESTAMPTZ
);
CREATE TABLE ownership_transfers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), serial_id UUID NOT NULL REFERENCES serials(id),
 old_owner_id UUID REFERENCES users(id), new_owner_id UUID REFERENCES users(id),
 symbolic_fee_payment_id UUID, started_at TIMESTAMPTZ DEFAULT now(), deadline_at TIMESTAMPTZ NOT NULL, completed_at TIMESTAMPTZ
);

CREATE TABLE categories (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), parent_id UUID REFERENCES categories(id),
 name_ar VARCHAR(200) NOT NULL, category_kind VARCHAR(40) NOT NULL, sort_order INT DEFAULT 0, is_active BOOLEAN DEFAULT TRUE
);
CREATE TABLE services (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), category_id UUID REFERENCES categories(id),
 name_ar VARCHAR(250) NOT NULL, description TEXT, listing_type listing_type NOT NULL, is_active BOOLEAN DEFAULT TRUE, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE manufacturers (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name_ar VARCHAR(250) NOT NULL, name_en VARCHAR(250), country VARCHAR(120), official_url TEXT);
CREATE TABLE models (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), manufacturer_id UUID REFERENCES manufacturers(id), model_name VARCHAR(250), global_code VARCHAR(150));

CREATE TABLE service_offers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), service_id UUID NOT NULL REFERENCES services(id),
 provider_id UUID NOT NULL REFERENCES providers(id), title VARCHAR(300) NOT NULL, description TEXT,
 manufacturer_id UUID REFERENCES manufacturers(id), model_id UUID REFERENCES models(id), global_code VARCHAR(150),
 status offer_status DEFAULT 'draft', rental_price NUMERIC(18,2), sale_price NUMERIC(18,2),
 insurance_price NUMERIC(18,2) DEFAULT 0, transport_price NUMERIC(18,2) DEFAULT 0,
 installation_price NUMERIC(18,2) DEFAULT 0, dismantling_price NUMERIC(18,2) DEFAULT 0,
 price_includes_contact BOOLEAN DEFAULT FALSE, ai_review_deadline TIMESTAMPTZ, published_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE offer_attributes (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id) ON DELETE CASCADE,
 attribute_name VARCHAR(150) NOT NULL, attribute_value TEXT NOT NULL, UNIQUE(offer_id,attribute_name)
);
CREATE TABLE offer_media (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id) ON DELETE CASCADE,
 media_type VARCHAR(30) NOT NULL, file_uri TEXT NOT NULL, caption TEXT, sort_order INT DEFAULT 0
);
CREATE TABLE service_units (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id) ON DELETE CASCADE,
 unit_code VARCHAR(120) NOT NULL, unit_status unit_status DEFAULT 'available', quantity NUMERIC(12,2) DEFAULT 1, UNIQUE(offer_id,unit_code)
);

CREATE TABLE ai_reviews (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id),
 review_status VARCHAR(40) DEFAULT 'pending', data_score NUMERIC(5,2), specification_score NUMERIC(5,2),
 evidence_score NUMERIC(5,2), price_score NUMERIC(5,2), similarity_score NUMERIC(5,2),
 findings JSONB, recommendation TEXT, started_at TIMESTAMPTZ DEFAULT now(), completed_at TIMESTAMPTZ
);
CREATE TABLE ai_price_checks (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID NOT NULL REFERENCES service_offers(id),
 comparable_offer_count INT DEFAULT 0, market_min NUMERIC(18,2), market_avg NUMERIC(18,2), market_max NUMERIC(18,2),
 submitted_price NUMERIC(18,2), insurance_min NUMERIC(18,2), insurance_avg NUMERIC(18,2),
 submitted_insurance NUMERIC(18,2), decision VARCHAR(40), reason TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE ai_flags (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), offer_id UUID REFERENCES service_offers(id), severity VARCHAR(30), code VARCHAR(100), message TEXT, resolved_at TIMESTAMPTZ);

CREATE TABLE availability_rules (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), unit_id UUID NOT NULL REFERENCES service_units(id) ON DELETE CASCADE,
 start_date DATE NOT NULL, end_date DATE NOT NULL, available_quantity NUMERIC(12,2) DEFAULT 1
);
CREATE TABLE maintenance_blocks (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), unit_id UUID NOT NULL REFERENCES service_units(id),
 start_at TIMESTAMPTZ NOT NULL, end_at TIMESTAMPTZ NOT NULL, reason TEXT
);
CREATE TABLE holds (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), unit_id UUID NOT NULL REFERENCES service_units(id),
 booking_id UUID, status hold_status DEFAULT 'active', start_at TIMESTAMPTZ NOT NULL, end_at TIMESTAMPTZ NOT NULL, expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE bookings (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), customer_id UUID NOT NULL REFERENCES users(id),
 service_id UUID NOT NULL REFERENCES services(id), status booking_status DEFAULT 'draft',
 event_start TIMESTAMPTZ NOT NULL, event_end TIMESTAMPTZ NOT NULL, quantity NUMERIC(12,2) DEFAULT 1,
 subtotal NUMERIC(18,2) DEFAULT 0, insurance_amount NUMERIC(18,2) DEFAULT 0, extras_amount NUMERIC(18,2) DEFAULT 0,
 total_amount NUMERIC(18,2) DEFAULT 0, insurance_type insurance_type DEFAULT 'none', notes TEXT,
 created_at TIMESTAMPTZ DEFAULT now(), updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE booking_wishes (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 wish_rank SMALLINT NOT NULL CHECK(wish_rank BETWEEN 1 AND 3), offer_id UUID NOT NULL REFERENCES service_offers(id),
 unit_id UUID REFERENCES service_units(id), status VARCHAR(40) DEFAULT 'pending', deposit_required NUMERIC(18,2) DEFAULT 0,
 UNIQUE(booking_id,wish_rank)
);
CREATE TABLE booking_events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 event_code VARCHAR(100) NOT NULL, old_status booking_status, new_status booking_status,
 actor_user_id UUID REFERENCES users(id), metadata JSONB, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE booking_state_history (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id),
 status booking_status NOT NULL, changed_by UUID REFERENCES users(id), note TEXT, created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE payments (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID REFERENCES bookings(id),
 customer_id UUID NOT NULL REFERENCES users(id), amount NUMERIC(18,2) NOT NULL,
 method payment_method NOT NULL, status payment_status DEFAULT 'created',
 provider_reference VARCHAR(200), client_reference VARCHAR(200), receipt_file_uri TEXT,
 created_at TIMESTAMPTZ DEFAULT now(), verified_at TIMESTAMPTZ, failed_at TIMESTAMPTZ
);
CREATE TABLE payment_attempts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), payment_id UUID NOT NULL REFERENCES payments(id),
 attempt_no INT NOT NULL, external_reference VARCHAR(200), request_payload JSONB, response_payload JSONB,
 status payment_status NOT NULL, started_at TIMESTAMPTZ DEFAULT now(), finished_at TIMESTAMPTZ,
 UNIQUE(payment_id,attempt_no)
);
CREATE TABLE payment_transactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), payment_id UUID NOT NULL REFERENCES payments(id),
 idempotency_key VARCHAR(200) UNIQUE NOT NULL, external_reference VARCHAR(200),
 status payment_status NOT NULL, amount NUMERIC(18,2) NOT NULL, received_at TIMESTAMPTZ, reconciled_at TIMESTAMPTZ
);
CREATE TABLE payment_locks (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID UNIQUE NOT NULL REFERENCES bookings(id),
 locked_until TIMESTAMPTZ NOT NULL, reason TEXT
);
CREATE TABLE escrow_accounts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID UNIQUE NOT NULL REFERENCES bookings(id),
 held_amount NUMERIC(18,2) DEFAULT 0, released_amount NUMERIC(18,2) DEFAULT 0,
 refunded_amount NUMERIC(18,2) DEFAULT 0, status VARCHAR(40) DEFAULT 'holding'
);

CREATE TABLE ledger_accounts (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), account_code VARCHAR(80) UNIQUE NOT NULL,
 account_name VARCHAR(200) NOT NULL, account_type VARCHAR(60) NOT NULL, owner_user_id UUID REFERENCES users(id)
);
CREATE TABLE ledger_entries (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), reference_type VARCHAR(80) NOT NULL, reference_id UUID,
 description TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE ledger_entry_lines (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), entry_id UUID NOT NULL REFERENCES ledger_entries(id) ON DELETE CASCADE,
 account_id UUID NOT NULL REFERENCES ledger_accounts(id), side ledger_side NOT NULL,
 amount NUMERIC(18,2) NOT NULL CHECK(amount>0), currency VARCHAR(10) DEFAULT 'YER'
);

CREATE TABLE commission_rules (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name VARCHAR(120) NOT NULL,
 total_rate NUMERIC(7,4) NOT NULL, platform_rate NUMERIC(7,4) NOT NULL,
 agent_rate NUMERIC(7,4) NOT NULL, is_exclusive BOOLEAN DEFAULT FALSE, active BOOLEAN DEFAULT TRUE
);
CREATE TABLE booking_commissions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id),
 rule_id UUID REFERENCES commission_rules(id), gross_amount NUMERIC(18,2) NOT NULL,
 platform_amount NUMERIC(18,2) NOT NULL, agent_amount NUMERIC(18,2) NOT NULL, provider_amount NUMERIC(18,2) NOT NULL
);
CREATE TABLE wallets (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), owner_user_id UUID UNIQUE REFERENCES users(id),
 currency VARCHAR(10) DEFAULT 'YER', status VARCHAR(30) DEFAULT 'active'
);
CREATE TABLE wallet_transactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), wallet_id UUID NOT NULL REFERENCES wallets(id),
 amount NUMERIC(18,2) NOT NULL, transaction_type VARCHAR(60) NOT NULL,
 reference_type VARCHAR(80), reference_id UUID, created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE insurance_records (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID UNIQUE NOT NULL REFERENCES bookings(id),
 type insurance_type NOT NULL, cash_amount NUMERIC(18,2) DEFAULT 0, description TEXT, evidence_uri TEXT,
 received_at TIMESTAMPTZ, returned_at TIMESTAMPTZ, status VARCHAR(40) DEFAULT 'held'
);
CREATE TABLE service_executions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID UNIQUE NOT NULL REFERENCES bookings(id),
 provider_id UUID REFERENCES providers(id), started_at TIMESTAMPTZ, completed_at TIMESTAMPTZ,
 customer_confirmation_at TIMESTAMPTZ, provider_confirmation_at TIMESTAMPTZ, notes TEXT
);

CREATE TABLE disputes (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id),
 opened_by UUID NOT NULL REFERENCES users(id), status VARCHAR(40) DEFAULT 'open',
 reason TEXT NOT NULL, resolution TEXT, opened_at TIMESTAMPTZ DEFAULT now(), resolved_at TIMESTAMPTZ
);
CREATE TABLE dispute_events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), dispute_id UUID NOT NULL REFERENCES disputes(id) ON DELETE CASCADE,
 actor_user_id UUID REFERENCES users(id), action VARCHAR(100) NOT NULL, note TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE customer_reviews (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID NOT NULL REFERENCES bookings(id),
 customer_id UUID NOT NULL REFERENCES users(id), provider_id UUID REFERENCES providers(id),
 offer_id UUID REFERENCES service_offers(id), rating NUMERIC(2,1) CHECK(rating BETWEEN 1 AND 5),
 review_text TEXT, created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE notifications (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id),
 title VARCHAR(250) NOT NULL, body TEXT NOT NULL, type VARCHAR(80),
 reference_type VARCHAR(80), reference_id UUID, read_at TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE conversations (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), booking_id UUID REFERENCES bookings(id), created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE conversation_members (conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE, user_id UUID REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY(conversation_id,user_id));
CREATE TABLE messages (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
 sender_id UUID NOT NULL REFERENCES users(id), message_type VARCHAR(30) DEFAULT 'text', body TEXT, media_uri TEXT, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE ads (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), provider_id UUID REFERENCES providers(id), title VARCHAR(250) NOT NULL,
 placement VARCHAR(80) NOT NULL, price NUMERIC(18,2), start_at TIMESTAMPTZ, end_at TIMESTAMPTZ, status VARCHAR(40) DEFAULT 'pending'
);
CREATE TABLE audit_logs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), actor_user_id UUID REFERENCES users(id), action VARCHAR(120) NOT NULL,
 entity_type VARCHAR(100) NOT NULL, entity_id UUID, before_data JSONB, after_data JSONB, ip_address INET, created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE incidents (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), type VARCHAR(100) NOT NULL, severity VARCHAR(30) NOT NULL,
 booking_id UUID REFERENCES bookings(id), payment_id UUID REFERENCES payments(id), description TEXT,
 status VARCHAR(40) DEFAULT 'open', created_at TIMESTAMPTZ DEFAULT now(), resolved_at TIMESTAMPTZ
);
CREATE TABLE policy_configs (key VARCHAR(120) PRIMARY KEY, value_json JSONB NOT NULL, description TEXT);

CREATE INDEX idx_locations_parent ON locations(parent_id);
CREATE INDEX idx_services_category ON services(category_id);
CREATE INDEX idx_offers_service_status ON service_offers(service_id,status);
CREATE INDEX idx_offers_provider ON service_offers(provider_id);
CREATE INDEX idx_availability_unit_dates ON availability_rules(unit_id,start_date,end_date);
CREATE INDEX idx_bookings_customer ON bookings(customer_id);
CREATE INDEX idx_bookings_dates ON bookings(event_start,event_end);
CREATE INDEX idx_booking_wishes_booking ON booking_wishes(booking_id);
CREATE INDEX idx_payments_booking ON payments(booking_id);
CREATE INDEX idx_payments_reference ON payments(provider_reference);
CREATE INDEX idx_ledger_lines_account ON ledger_entry_lines(account_id);
CREATE INDEX idx_notifications_user ON notifications(user_id,read_at);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type,entity_id);

INSERT INTO roles(name,description) VALUES
('customer','طالب خدمة'),('provider','منتسب'),('agent','وكيل متجر هلا في المديرية'),
('admin','إدارة'),('finance','مالية'),('ai_reviewer','مراجعة ذكية') ON CONFLICT DO NOTHING;
INSERT INTO geographic_levels(code,name_ar) VALUES
('country','الدولة'),('governorate','المحافظة'),('directorate','المديرية'),('neighborhood','الحي'),('alley','الحارة') ON CONFLICT DO NOTHING;
INSERT INTO commission_rules(name,total_rate,platform_rate,agent_rate,is_exclusive) VALUES
('عادي',15,10,5,FALSE),('حصري',25,20,5,TRUE);
INSERT INTO policy_configs(key,value_json,description) VALUES
('payment_pending_window_minutes','5','نافذة حماية التوريد المعلق'),
('offer_min_ai_review_hours','6','مراجعة موسعة للعروض'),
('offer_fast_publish_minutes','30','النشر بعد اجتياز المراجعة'),
('booking_reminder_hours','[24,18,12]','مواعيد التنبيهات'),
('serial_completion_days','10','مهلة استكمال نقل الملكية'),
('availability_horizon_days','365','جدول التوفر لمدة سنة')
ON CONFLICT(key) DO NOTHING;
