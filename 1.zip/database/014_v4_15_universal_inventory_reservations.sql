-- Hala v4.15 Universal Inventory Availability & Reservation
BEGIN;
SET search_path TO hala, public;

CREATE TABLE IF NOT EXISTS inventory_reservations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES bookings(id),
  listing_id UUID REFERENCES universal_listings(id),
  service_offer_id UUID REFERENCES service_offers(id),
  listing_unit_id UUID REFERENCES listing_units(id),
  service_unit_id UUID REFERENCES service_units(id),
  quantity NUMERIC(20,6) NOT NULL CHECK(quantity > 0),
  operation_type VARCHAR(20) NOT NULL CHECK(operation_type IN ('BUY','RENT')),
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'HELD' CHECK(status IN ('HELD','ACTIVE','RELEASED','SOLD','EXPIRED')),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((listing_id IS NOT NULL) <> (service_offer_id IS NOT NULL)),
  CHECK ((listing_unit_id IS NOT NULL) <> (service_unit_id IS NOT NULL)),
  CHECK (ends_at > starts_at)
);

CREATE INDEX IF NOT EXISTS idx_inventory_res_listing ON inventory_reservations(listing_id,status,starts_at,ends_at);
CREATE INDEX IF NOT EXISTS idx_inventory_res_service ON inventory_reservations(service_offer_id,status,starts_at,ends_at);
CREATE INDEX IF NOT EXISTS idx_inventory_res_listing_unit ON inventory_reservations(listing_unit_id,status,starts_at,ends_at);
CREATE INDEX IF NOT EXISTS idx_inventory_res_service_unit ON inventory_reservations(service_unit_id,status,starts_at,ends_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_inventory_res_booking_source_unit
  ON inventory_reservations(booking_id, COALESCE(listing_unit_id, service_unit_id));

INSERT INTO policy_configs(key,value_json,description) VALUES
('inventory.universal_reservations','true','الحجز الموحد يستخدم نظام حجز مخزون ذري مرتبط بالحجز ويمنع التداخل المتزامن'),
('inventory.require_listing_units_for_rental','true','لا يسمح بحجز الإيجار للسوق الموحد دون تعريف وحدات مخزون قابلة للحجز'),
('inventory.hold_minutes','15','مدة حجز المخزون أثناء انتظار الدفع قبل انتهاء المهلة')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;

COMMIT;
