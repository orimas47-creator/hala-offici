BEGIN;

-- Hala v4.3: extensibility + AI governance layer.
-- AI is advisory/monitoring by default and never bypasses domain controls.

CREATE TABLE IF NOT EXISTS system_modules (
  id BIGSERIAL PRIMARY KEY,
  module_key VARCHAR(120) NOT NULL UNIQUE,
  display_name VARCHAR(200) NOT NULL,
  module_type VARCHAR(50) NOT NULL DEFAULT 'feature',
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  config_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  version VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS feature_flags (
  id BIGSERIAL PRIMARY KEY,
  flag_key VARCHAR(160) NOT NULL UNIQUE,
  enabled BOOLEAN NOT NULL DEFAULT FALSE,
  rollout_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  description TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_agents (
  id BIGSERIAL PRIMARY KEY,
  agent_key VARCHAR(120) NOT NULL UNIQUE,
  display_name VARCHAR(200) NOT NULL,
  purpose VARCHAR(120) NOT NULL,
  provider VARCHAR(120),
  model VARCHAR(160),
  mode VARCHAR(30) NOT NULL DEFAULT 'advisory',
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (mode IN ('advisory','guarded_action','disabled'))
);

CREATE TABLE IF NOT EXISTS ai_events (
  id BIGSERIAL PRIMARY KEY,
  event_key VARCHAR(160) NOT NULL,
  source_module VARCHAR(120) NOT NULL,
  resource_type VARCHAR(100),
  resource_id VARCHAR(120),
  actor_id BIGINT,
  risk_score NUMERIC(6,5),
  payload_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS ai_findings (
  id BIGSERIAL PRIMARY KEY,
  event_id BIGINT REFERENCES ai_events(id) ON DELETE SET NULL,
  agent_id BIGINT REFERENCES ai_agents(id) ON DELETE SET NULL,
  severity VARCHAR(20) NOT NULL DEFAULT 'info',
  finding_type VARCHAR(120) NOT NULL,
  confidence NUMERIC(6,5),
  recommendation TEXT,
  evidence_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(30) NOT NULL DEFAULT 'OPEN',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ,
  CHECK (severity IN ('info','low','medium','high','critical')),
  CHECK (status IN ('OPEN','ACKNOWLEDGED','RESOLVED','FALSE_POSITIVE','ESCALATED'))
);

CREATE TABLE IF NOT EXISTS ai_decisions (
  id BIGSERIAL PRIMARY KEY,
  finding_id BIGINT REFERENCES ai_findings(id) ON DELETE SET NULL,
  agent_id BIGINT REFERENCES ai_agents(id) ON DELETE SET NULL,
  decision VARCHAR(80) NOT NULL,
  decision_scope VARCHAR(80) NOT NULL,
  proposed_action JSONB NOT NULL DEFAULT '{}'::jsonb,
  applied_by_rule BOOLEAN NOT NULL DEFAULT FALSE,
  applied_by_actor BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_watch_rules (
  id BIGSERIAL PRIMARY KEY,
  rule_key VARCHAR(160) NOT NULL UNIQUE,
  event_pattern VARCHAR(200) NOT NULL,
  severity VARCHAR(20) NOT NULL DEFAULT 'medium',
  threshold_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  action_policy_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ai_events_resource ON ai_events(resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_ai_events_unprocessed ON ai_events(processed_at, occurred_at);
CREATE INDEX IF NOT EXISTS idx_ai_findings_open ON ai_findings(status, severity, created_at);
CREATE INDEX IF NOT EXISTS idx_ai_decisions_finding ON ai_decisions(finding_id, created_at);

INSERT INTO system_modules(module_key, display_name, module_type, enabled, version)
VALUES
 ('ai','Hala AI Control Layer','cross_cutting',TRUE,'4.3'),
 ('policies','Policy & Configuration Engine','core',TRUE,'4.3'),
 ('catalog','Dynamic Catalog','core',TRUE,'4.3'),
 ('geography','Dynamic Geography','core',TRUE,'4.3')
ON CONFLICT (module_key) DO NOTHING;

INSERT INTO feature_flags(flag_key, enabled, description)
VALUES
 ('ai.offer_review', TRUE, 'AI review for provider offers'),
 ('ai.price_intelligence', TRUE, 'Price comparison and anomaly detection'),
 ('ai.security_monitoring', TRUE, 'Security and behavior anomaly monitoring'),
 ('ai.fraud_detection', TRUE, 'Fraud and abuse indicators'),
 ('ai.booking_monitoring', TRUE, 'Booking and wish lifecycle anomaly monitoring'),
 ('ai.media_moderation', TRUE, 'Media/content safety review'),
 ('ai.dispute_assist', TRUE, 'Evidence organization and dispute assistance')
ON CONFLICT (flag_key) DO NOTHING;

INSERT INTO ai_agents(agent_key, display_name, purpose, mode, enabled)
VALUES
 ('offer_guard','مراقب العروض','offer_review','advisory',TRUE),
 ('price_guard','مراقب الأسعار','price_intelligence','advisory',TRUE),
 ('security_guard','مراقب الأمن والسلوك','security_monitoring','guarded_action',TRUE),
 ('fraud_guard','مراقب الاحتيال','fraud_detection','guarded_action',TRUE),
 ('booking_guard','مراقب الحجز والرغبات','booking_monitoring','advisory',TRUE),
 ('media_guard','مراقب الوسائط','media_moderation','advisory',TRUE),
 ('dispute_guard','مساعد النزاعات','dispute_assist','advisory',TRUE)
ON CONFLICT (agent_key) DO NOTHING;

COMMIT;
