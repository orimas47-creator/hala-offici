-- Hala Platform Unified Database v4.2
-- PostgreSQL + PostGIS
-- هذا الملف يحافظ على قاعدة v1 الحالية ويضيف طبقة v4.2 بدلاً من استبدالها.
BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE SCHEMA IF NOT EXISTS hala;
SET search_path TO hala, public;

-- Canonical lifecycle مستقل عن enum القديم للتوافق.
DO $$ BEGIN
  CREATE TYPE booking_lifecycle_status AS ENUM ('DRAFT','PAYMENT_PENDING','PROVIDER_PENDING','CONFIRMED','IN_PROGRESS','RETURN_PENDING','INSPECTION','COMPLETED','CANCELLED','FAILED','DISPUTED','FORCE_MAJEURE','RESOLVED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS booking_timers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 timer_type VARCHAR(60) NOT NULL,
 scheduled_at TIMESTAMPTZ NOT NULL,
 processed BOOLEAN NOT NULL DEFAULT FALSE,
 processed_at TIMESTAMPTZ,
 status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
 failure_reason TEXT,
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(booking_id,timer_type)
);
CREATE INDEX IF NOT EXISTS idx_booking_timers_due ON booking_timers(processed,scheduled_at,status);
CREATE INDEX IF NOT EXISTS idx_booking_timers_booking ON booking_timers(booking_id);

ALTER TABLE bookings ADD COLUMN IF NOT EXISTS lifecycle_status booking_lifecycle_status;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS lifecycle_version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS request_id UUID;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(200);
CREATE UNIQUE INDEX IF NOT EXISTS ux_bookings_idempotency ON bookings(idempotency_key) WHERE idempotency_key IS NOT NULL;

-- تحويل آمن للحالات القديمة إلى الحالة الموحدة.
UPDATE bookings SET lifecycle_status = CASE status::text
 WHEN 'draft' THEN 'DRAFT'::booking_lifecycle_status
 WHEN 'hold' THEN 'PAYMENT_PENDING'::booking_lifecycle_status
 WHEN 'awaiting_payment' THEN 'PAYMENT_PENDING'::booking_lifecycle_status
 WHEN 'payment_pending' THEN 'PAYMENT_PENDING'::booking_lifecycle_status
 WHEN 'payment_verified' THEN 'PROVIDER_PENDING'::booking_lifecycle_status
 WHEN 'confirmed' THEN 'CONFIRMED'::booking_lifecycle_status
 WHEN 'alternate_activation' THEN 'PROVIDER_PENDING'::booking_lifecycle_status
 WHEN 'executing' THEN 'IN_PROGRESS'::booking_lifecycle_status
 WHEN 'completed' THEN 'COMPLETED'::booking_lifecycle_status
 WHEN 'cancelled' THEN 'CANCELLED'::booking_lifecycle_status
 WHEN 'disputed' THEN 'DISPUTED'::booking_lifecycle_status
 WHEN 'refund_pending' THEN 'FAILED'::booking_lifecycle_status
 WHEN 'refunded' THEN 'COMPLETED'::booking_lifecycle_status
 WHEN 'expired' THEN 'FAILED'::booking_lifecycle_status
 ELSE 'DRAFT'::booking_lifecycle_status END
WHERE lifecycle_status IS NULL;
ALTER TABLE bookings ALTER COLUMN lifecycle_status SET NOT NULL;

-- سجل موحد للدورات إذا لم يكن موجوداً.
CREATE TABLE IF NOT EXISTS booking_lifecycle_history (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
 from_status booking_lifecycle_status,
 to_status booking_lifecycle_status NOT NULL,
 actor_user_id UUID REFERENCES users(id),
 request_id UUID,
 reason TEXT,
 metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_booking_lifecycle_history_booking ON booking_lifecycle_history(booking_id,created_at);

-- Webhook Inbox يمنع إسقاط callback غير معروف أو تكراره.
CREATE TABLE IF NOT EXISTS webhook_inbox (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 provider_name VARCHAR(100) NOT NULL,
 external_event_id VARCHAR(200) NOT NULL,
 event_type VARCHAR(150) NOT NULL,
 payload JSONB NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'RECEIVED',
 received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 processed_at TIMESTAMPTZ,
 failure_reason TEXT,
 UNIQUE(provider_name,external_event_id)
);

CREATE TABLE IF NOT EXISTS idempotency_records (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 actor_user_id UUID REFERENCES users(id),
 idempotency_key VARCHAR(200) NOT NULL,
 route VARCHAR(300) NOT NULL,
 request_hash VARCHAR(128) NOT NULL,
 response_status INTEGER,
 response_body JSONB,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 expires_at TIMESTAMPTZ,
 UNIQUE(actor_user_id,idempotency_key,route)
);

-- Audit v4.2 يحافظ على audit القديم ويضيف request/result.
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS request_id UUID;
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS result VARCHAR(40);
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}'::jsonb;
CREATE INDEX IF NOT EXISTS idx_audit_request ON audit_logs(request_id);

-- إشعارات قابلة لإعادة المحاولة.
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS priority VARCHAR(30) DEFAULT 'normal';
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS delivery_status VARCHAR(30) DEFAULT 'pending';
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS sent_at TIMESTAMPTZ;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMPTZ;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS retry_count INTEGER NOT NULL DEFAULT 0;

-- سياسات قابلة للإصدار بدلاً من hard-code.
CREATE TABLE IF NOT EXISTS policy_versions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 policy_key VARCHAR(150) NOT NULL,
 version INTEGER NOT NULL,
 value_json JSONB NOT NULL,
 effective_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 approved_by UUID REFERENCES users(id),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(policy_key,version)
);

-- AI audit trail.
CREATE TABLE IF NOT EXISTS ai_review_runs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 offer_id UUID REFERENCES service_offers(id) ON DELETE CASCADE,
 model_name VARCHAR(150),
 model_version VARCHAR(100),
 input_hash VARCHAR(128),
 result VARCHAR(50) NOT NULL,
 score NUMERIC(8,5),
 findings JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- مؤشرات التوفر الأساسية.
CREATE INDEX IF NOT EXISTS idx_maintenance_blocks_unit_dates ON maintenance_blocks(unit_id,start_at,end_at);
CREATE INDEX IF NOT EXISTS idx_holds_unit_dates ON holds(unit_id,start_at,end_at,status);
CREATE INDEX IF NOT EXISTS idx_bookings_lifecycle ON bookings(lifecycle_status,event_start,event_end);
CREATE INDEX IF NOT EXISTS idx_webhook_inbox_status ON webhook_inbox(status,received_at);

-- قيود ledger: لا تسمح بمبلغ غير موجب.
ALTER TABLE ledger_entry_lines DROP CONSTRAINT IF EXISTS ledger_entry_lines_amount_check;
ALTER TABLE ledger_entry_lines ADD CONSTRAINT ledger_entry_lines_amount_check CHECK(amount > 0);

-- سياسة افتراضية فقط؛ القيم المالية النهائية يجب اعتمادها قبل الإنتاج.
INSERT INTO policy_configs(key,value_json,description) VALUES
('booking.lifecycle.version','"4.2"','الإصدار القانوني/التقني لدورة الحجز'),
('booking.timer.types','["PAYMENT_DEADLINE","SUPPLIER_CONFIRMATION","MILESTONE_24H","MILESTONE_18H","MILESTONE_12H","MILESTONE_6H","ALTERNATIVE_HOLD_EXPIRY","INSURANCE_REFUND"]','أنواع المؤقتات'),
('ai.fast_publish_minutes','30','هدف تشغيلي لا يعني موافقة تلقائية'),
('ai.extended_review_hours','6','نافذة البحث الإضافي'),
('availability.horizon_days','365','أفق التوفر'),
('payment.lock_minutes','5','نافذة حماية الدفع'),
('ownership.transfer_completion_days','10','مهلة استكمال نقل الملكية')
ON CONFLICT(key) DO NOTHING;

COMMIT;
