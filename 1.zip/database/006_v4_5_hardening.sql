-- Hala Universal Market Database v4.5 Hardening
-- Apply AFTER: base schema + v4.2 + v4.3 + v4.4 Universal Market
-- Purpose: close integration gaps for simple supply/demand, lifecycle history,
-- pricing/rental periods, matching, multilingual presentation, and governed publishing.
BEGIN;
SET search_path TO hala, public;

-- 1) Stronger listing kind relation and lifecycle history
ALTER TABLE universal_listings
  ADD COLUMN IF NOT EXISTS listing_kind_id UUID REFERENCES listing_kinds(id),
  ADD COLUMN IF NOT EXISTS language_code VARCHAR(16) DEFAULT 'ar',
  ADD COLUMN IF NOT EXISTS country_code VARCHAR(3),
  ADD COLUMN IF NOT EXISTS visibility VARCHAR(30) NOT NULL DEFAULT 'PUBLIC',
  ADD COLUMN IF NOT EXISTS moderation_reason TEXT,
  ADD COLUMN IF NOT EXISTS published_by UUID REFERENCES users(id),
  ADD COLUMN IF NOT EXISTS policy_version VARCHAR(120);

UPDATE universal_listings ul
SET listing_kind_id = lk.id
FROM listing_kinds lk
WHERE ul.listing_kind_id IS NULL AND ul.listing_kind = lk.code;

ALTER TABLE universal_listings
  ADD CONSTRAINT chk_universal_listing_visibility
  CHECK (visibility IN ('PUBLIC','PRIVATE','MATCH_ONLY','SUSPENDED'));

CREATE INDEX IF NOT EXISTS idx_universal_listings_visibility
  ON universal_listings(visibility,listing_status,market_id);

CREATE TABLE IF NOT EXISTS universal_listing_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  old_status VARCHAR(40),
  new_status VARCHAR(40) NOT NULL,
  reason VARCHAR(500),
  actor_user_id UUID REFERENCES users(id),
  request_id VARCHAR(200),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_universal_listing_history_listing
  ON universal_listing_history(listing_id,created_at DESC);

-- 2) Multilingual display values without duplicating the listing
CREATE TABLE IF NOT EXISTS listing_translations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  language_code VARCHAR(16) NOT NULL,
  title VARCHAR(500),
  short_description TEXT,
  long_description TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(listing_id,language_code,version)
);
CREATE INDEX IF NOT EXISTS idx_listing_translations_lookup
  ON listing_translations(listing_id,language_code,version DESC);

-- 3) Demand: a customer can request something even when no listing exists.
CREATE TABLE IF NOT EXISTS demand_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES users(id),
  market_id UUID REFERENCES markets(id),
  section_id UUID REFERENCES market_sections(id),
  category_id UUID REFERENCES categories(id),
  operation_type VARCHAR(40) NOT NULL,
  title VARCHAR(500) NOT NULL,
  description TEXT,
  requested_attributes JSONB NOT NULL DEFAULT '{}'::jsonb,
  quantity NUMERIC(20,6),
  unit_code VARCHAR(40),
  budget_min NUMERIC(20,6),
  budget_max NUMERIC(20,6),
  currency_code VARCHAR(3),
  needed_from TIMESTAMPTZ,
  needed_to TIMESTAMPTZ,
  location_id UUID REFERENCES locations(id),
  location_requirements JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(40) NOT NULL DEFAULT 'OPEN',
  visibility VARCHAR(30) NOT NULL DEFAULT 'MATCHED_PROVIDERS',
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (operation_type IN ('BUY','RENT','BUY_OR_RENT','SERVICE','QUOTE')),
  CHECK (status IN ('DRAFT','OPEN','MATCHING','OFFERED','NEGOTIATING','FULFILLED','CANCELLED','EXPIRED')),
  CHECK (visibility IN ('MATCHED_PROVIDERS','PUBLIC','PRIVATE')),
  CHECK (budget_min IS NULL OR budget_min >= 0),
  CHECK (budget_max IS NULL OR budget_max >= 0),
  CHECK (budget_min IS NULL OR budget_max IS NULL OR budget_min <= budget_max),
  CHECK (needed_to IS NULL OR needed_from IS NULL OR needed_to > needed_from)
);
CREATE INDEX IF NOT EXISTS idx_demand_requests_matching
  ON demand_requests(market_id,category_id,operation_type,status,needed_from,needed_to);
CREATE INDEX IF NOT EXISTS idx_demand_requests_attrs_gin
  ON demand_requests USING GIN(requested_attributes);

-- 4) Provider responses to demand; response is not a booking until customer accepts.
CREATE TABLE IF NOT EXISTS demand_offers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  demand_request_id UUID NOT NULL REFERENCES demand_requests(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES providers(id),
  listing_id UUID REFERENCES universal_listings(id),
  proposed_title VARCHAR(500),
  proposed_price NUMERIC(20,6),
  currency_code VARCHAR(3),
  proposed_terms JSONB NOT NULL DEFAULT '{}'::jsonb,
  availability_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(40) NOT NULL DEFAULT 'SUBMITTED',
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (status IN ('SUBMITTED','UNDER_REVIEW','ACCEPTED','DECLINED','EXPIRED','WITHDRAWN'))
);
CREATE INDEX IF NOT EXISTS idx_demand_offers_request
  ON demand_offers(demand_request_id,status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_demand_offers_provider
  ON demand_offers(provider_id,status);

-- 5) Explicit matching records: explainable and auditable, not an opaque AI-only decision.
CREATE TABLE IF NOT EXISTS supply_demand_matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  demand_request_id UUID NOT NULL REFERENCES demand_requests(id) ON DELETE CASCADE,
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  match_method VARCHAR(40) NOT NULL,
  score NUMERIC(8,5),
  matched_factors JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(30) NOT NULL DEFAULT 'PROPOSED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(demand_request_id,listing_id),
  CHECK (match_method IN ('RULES','AI','HYBRID','MANUAL')),
  CHECK (status IN ('PROPOSED','SHOWN','DISMISSED','CONTACTED','CONVERTED','EXPIRED'))
);
CREATE INDEX IF NOT EXISTS idx_supply_demand_matches_demand
  ON supply_demand_matches(demand_request_id,status,score DESC);

-- 6) Rental periods / operational pricing. Keeps price data separate from catalog identity.
CREATE TABLE IF NOT EXISTS listing_rental_terms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  duration_unit VARCHAR(30) NOT NULL,
  minimum_duration NUMERIC(20,6) NOT NULL,
  maximum_duration NUMERIC(20,6),
  billing_rule VARCHAR(40) NOT NULL DEFAULT 'PER_UNIT',
  deposit_required BOOLEAN NOT NULL DEFAULT FALSE,
  cancellation_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  conditions JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  CHECK (minimum_duration > 0),
  CHECK (maximum_duration IS NULL OR maximum_duration >= minimum_duration),
  CHECK (billing_rule IN ('PER_UNIT','PER_PERIOD','PRO_RATA','QUOTE'))
);
CREATE INDEX IF NOT EXISTS idx_listing_rental_terms
  ON listing_rental_terms(listing_id,enabled);

-- 7) Keep provider/source evidence separate from publication decision.
CREATE TABLE IF NOT EXISTS listing_source_evidence (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  source_type VARCHAR(50) NOT NULL,
  source_reference VARCHAR(1000),
  evidence_hash VARCHAR(128),
  verification_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
  verified_by UUID REFERENCES users(id),
  verified_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (verification_status IN ('PENDING','VERIFIED','REJECTED','EXPIRED'))
);
CREATE INDEX IF NOT EXISTS idx_listing_source_evidence
  ON listing_source_evidence(listing_id,verification_status);

-- 8) Global unit-of-measure registry; avoids hard-coded units in future markets.
CREATE TABLE IF NOT EXISTS unit_registry (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_code VARCHAR(60) UNIQUE NOT NULL,
  dimension_code VARCHAR(60) NOT NULL,
  symbol VARCHAR(40),
  name_ar VARCHAR(160),
  name_en VARCHAR(160),
  conversion_to_base NUMERIC(40,20),
  base_unit_code VARCHAR(60),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 9) Matching/visibility policies are configuration, not hard-coded behavior.
INSERT INTO policy_configs(key,value_json,description) VALUES
('market.supply_demand.enabled','true','تمكين مسار العرض والطلب العام'),
('market.supply_demand.simple_customer_flow','true','العميل يطلب أو يعرض دون معرفة بنية البيانات الداخلية'),
('market.supply_demand.matching_methods','["RULES","AI","HYBRID","MANUAL"]','طرق المطابقة المسموح بها'),
('market.listing.universal_scope','true','السوق قادر على تمثيل أي عرض قانوني للبيع أو التأجير أو الخدمة'),
('market.listing.publish_requires_review','true','لا يصبح العرض منشوراً إلا بعد بوابة المراجعة المعتمدة')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json, description=EXCLUDED.description;

COMMIT;
