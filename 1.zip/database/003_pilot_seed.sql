-- Hala Pilot Seed v4.2.1
-- Safe demo data only. No real customer/provider/payment information.
SET search_path TO hala, public;

INSERT INTO geographic_levels(code,name_ar) VALUES
 ('country','الدولة'),('governorate','المحافظة'),('directorate','المديرية'),('neighborhood','الحي'),('alley','الحارة')
ON CONFLICT(code) DO NOTHING;

INSERT INTO roles(name,description) VALUES
 ('customer','عميل تجريبي'),('provider','منتسب/مقدم خدمة تجريبي'),('agent','وكيل تجريبي'),('admin','إدارة تجريبية')
ON CONFLICT(name) DO NOTHING;

INSERT INTO permissions(code,description) VALUES
 ('booking.create','إنشاء حجز'),('booking.read.own','قراءة حجوزات العميل'),
 ('booking.manage.provider','إدارة حجوزات المنتسب'),('booking.manage.agent','متابعة حجوزات نطاق الوكيل'),
 ('finance.read.own','قراءة الحساب المالي الخاص'),('admin.all','صلاحيات الإدارة التجريبية')
ON CONFLICT(code) DO NOTHING;

INSERT INTO policy_configs(key,value_json,description) VALUES
 ('pilot.enabled','true','تفعيل بيئة الاختبار التجريبية فقط'),
 ('pilot.real_money','false','لا توجد أموال حقيقية في بيئة Pilot'),
 ('pilot.payment_provider','sandbox','مزود دفع وهمي/اختباري'),
 ('pilot.sms','console','OTP يعرض في سجل Backend التجريبي')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;
