-- =========================================================
-- Hala Universal Market Database Extension v4.4
-- Purpose: make the catalog capable of representing ANY legally
-- permitted thing/service that can be offered for sale or rental,
-- without requiring a new table/column for every future category.
-- This is an extension layer; the financial/security/core lifecycle
-- remains strict and governed.
-- PostgreSQL + PostGIS
-- =========================================================

BEGIN;

-- ---------------------------------------------------------
-- 1) Universal listing taxonomy
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_kinds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(40) UNIQUE NOT NULL,
  display_name VARCHAR(160) NOT NULL,
  description TEXT,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO listing_kinds(code,display_name,description) VALUES
('SALE','بيع','عرض أصل/منتج/بضاعة للبيع'),
('RENTAL','تأجير','عرض أصل/منتج/معدات/مكان للتأجير'),
('SALE_RENTAL','بيع وتأجير','العرض متاح للبيع والتأجير'),
('SERVICE','خدمة','خدمة قابلة للحجز والتنفيذ'),
('BUNDLE','حزمة','مجموعة عناصر أو خدمات كوحدة عرض'),
('SUBSCRIPTION','اشتراك','استخدام متكرر/دوري وفق سياسة السوق')
ON CONFLICT(code) DO NOTHING;

-- ---------------------------------------------------------
-- 2) Universal catalog item (one flexible representation)
--    Core searchable fields are normalized; future-specific
--    properties live in structured JSONB + templates.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS universal_listings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id),
  section_id UUID REFERENCES market_sections(id),
  category_id UUID REFERENCES categories(id),
  provider_id UUID REFERENCES providers(id),
  service_id UUID REFERENCES services(id),
  offer_id UUID REFERENCES service_offers(id),
  parent_listing_id UUID REFERENCES universal_listings(id),

  title VARCHAR(500) NOT NULL,
  short_description TEXT,
  long_description TEXT,
  listing_kind VARCHAR(40) NOT NULL,
  listing_status VARCHAR(40) NOT NULL DEFAULT 'DRAFT',

  brand VARCHAR(250),
  manufacturer_name VARCHAR(300),
  model_name VARCHAR(300),
  model_year INTEGER,
  condition_code VARCHAR(60),
  country_of_origin VARCHAR(3),

  quantity NUMERIC(20,6),
  unit_code VARCHAR(40),
  min_order_quantity NUMERIC(20,6),
  max_order_quantity NUMERIC(20,6),

  base_currency VARCHAR(3),
  base_price NUMERIC(20,6),
  pricing_model VARCHAR(60),

  searchable_text TEXT,
  tags JSONB NOT NULL DEFAULT '[]'::jsonb,
  attributes JSONB NOT NULL DEFAULT '{}'::jsonb,
  specifications JSONB NOT NULL DEFAULT '{}'::jsonb,
  usage_constraints JSONB NOT NULL DEFAULT '{}'::jsonb,
  service_capabilities JSONB NOT NULL DEFAULT '{}'::jsonb,
  compatibility JSONB NOT NULL DEFAULT '{}'::jsonb,

  source_type VARCHAR(40) NOT NULL DEFAULT 'PROVIDER',
  source_reference VARCHAR(500),
  version INTEGER NOT NULL DEFAULT 1,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CHECK (listing_kind IN ('SALE','RENTAL','SALE_RENTAL','SERVICE','BUNDLE','SUBSCRIPTION')),
  CHECK (listing_status IN ('DRAFT','AI_REVIEW','HUMAN_REVIEW','APPROVED','PUBLISHED','SUSPENDED','ARCHIVED','REJECTED'))
);

CREATE INDEX IF NOT EXISTS idx_universal_listings_market_section
  ON universal_listings(market_id,section_id,listing_status);
CREATE INDEX IF NOT EXISTS idx_universal_listings_category
  ON universal_listings(category_id,listing_status);
CREATE INDEX IF NOT EXISTS idx_universal_listings_provider
  ON universal_listings(provider_id,listing_status);
CREATE INDEX IF NOT EXISTS idx_universal_listings_kind
  ON universal_listings(listing_kind,listing_status);
CREATE INDEX IF NOT EXISTS idx_universal_listings_attributes_gin
  ON universal_listings USING GIN(attributes);
CREATE INDEX IF NOT EXISTS idx_universal_listings_specs_gin
  ON universal_listings USING GIN(specifications);
CREATE INDEX IF NOT EXISTS idx_universal_listings_tags_gin
  ON universal_listings USING GIN(tags);

-- ---------------------------------------------------------
-- 3) Universal product/service variants
--    One listing may represent many configurations.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_variants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  variant_code VARCHAR(160),
  barcode VARCHAR(160),
  sku VARCHAR(160),
  serial_number VARCHAR(240),
  external_identifier VARCHAR(240),
  variant_name VARCHAR(300),
  attributes JSONB NOT NULL DEFAULT '{}'::jsonb,
  dimensions JSONB NOT NULL DEFAULT '{}'::jsonb,
  technical_specifications JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(listing_id,variant_code)
);

CREATE INDEX IF NOT EXISTS idx_listing_variants_listing
  ON listing_variants(listing_id,status);
CREATE INDEX IF NOT EXISTS idx_listing_variants_barcode
  ON listing_variants(barcode);

-- ---------------------------------------------------------
-- 4) Physical/digital/service units
--    Allows an offer to point to the actual rentable/sellable unit.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  variant_id UUID REFERENCES listing_variants(id) ON DELETE SET NULL,
  unit_code VARCHAR(180),
  asset_identifier VARCHAR(240),
  unit_type VARCHAR(80),
  quantity NUMERIC(20,6) NOT NULL DEFAULT 1,
  status VARCHAR(40) NOT NULL DEFAULT 'AVAILABLE',
  condition_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  technical_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  location_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_units_listing_status
  ON listing_units(listing_id,status);

-- ---------------------------------------------------------
-- 5) Flexible attribute definitions and values per market/category
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_attribute_definitions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_id UUID REFERENCES markets(id) ON DELETE CASCADE,
  section_id UUID REFERENCES market_sections(id) ON DELETE CASCADE,
  category_id UUID REFERENCES categories(id) ON DELETE CASCADE,
  attribute_code VARCHAR(160) NOT NULL,
  display_name VARCHAR(300) NOT NULL,
  data_type VARCHAR(40) NOT NULL,
  unit_code VARCHAR(40),
  required BOOLEAN NOT NULL DEFAULT FALSE,
  searchable BOOLEAN NOT NULL DEFAULT FALSE,
  filterable BOOLEAN NOT NULL DEFAULT FALSE,
  sortable BOOLEAN NOT NULL DEFAULT FALSE,
  validation_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  allowed_values JSONB NOT NULL DEFAULT '[]'::jsonb,
  display_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(market_id,section_id,category_id,attribute_code,version)
);

CREATE INDEX IF NOT EXISTS idx_listing_attribute_defs_scope
  ON listing_attribute_definitions(market_id,section_id,category_id,enabled);

CREATE TABLE IF NOT EXISTS listing_attribute_values (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  attribute_definition_id UUID NOT NULL REFERENCES listing_attribute_definitions(id),
  value_text TEXT,
  value_number NUMERIC(30,10),
  value_boolean BOOLEAN,
  value_date DATE,
  value_datetime TIMESTAMPTZ,
  value_json JSONB,
  value_unit_code VARCHAR(40),
  normalized_value JSONB,
  source VARCHAR(40) NOT NULL DEFAULT 'PROVIDER',
  confidence NUMERIC(6,5),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_attr_values_listing
  ON listing_attribute_values(listing_id,attribute_definition_id);
CREATE INDEX IF NOT EXISTS idx_listing_attr_values_number
  ON listing_attribute_values(attribute_definition_id,value_number);

-- ---------------------------------------------------------
-- 6) Global identifiers / standards / references
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_identifiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  identifier_type VARCHAR(80) NOT NULL,
  identifier_value VARCHAR(500) NOT NULL,
  issuing_country VARCHAR(3),
  issuer VARCHAR(250),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(identifier_type,identifier_value)
);

CREATE INDEX IF NOT EXISTS idx_listing_identifiers_listing
  ON listing_identifiers(listing_id,identifier_type);

-- ---------------------------------------------------------
-- 7) Listing media / technical documents metadata
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  asset_type VARCHAR(60) NOT NULL,
  storage_key VARCHAR(1000) NOT NULL,
  mime_type VARCHAR(160),
  file_size_bytes BIGINT,
  content_hash VARCHAR(128),
  language_code VARCHAR(16),
  title VARCHAR(500),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  moderation_status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_assets_listing
  ON listing_assets(listing_id,asset_type,moderation_status);

-- ---------------------------------------------------------
-- 8) Universal pricing rules
--    Pricing remains data/policy-driven, not hard-coded.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  price_type VARCHAR(60) NOT NULL,
  currency_code VARCHAR(3) NOT NULL,
  amount NUMERIC(20,6) NOT NULL,
  billing_unit VARCHAR(60),
  minimum_quantity NUMERIC(20,6),
  maximum_quantity NUMERIC(20,6),
  minimum_duration NUMERIC(20,6),
  duration_unit VARCHAR(40),
  valid_from TIMESTAMPTZ,
  valid_to TIMESTAMPTZ,
  conditions JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_prices_active
  ON listing_prices(listing_id,enabled,valid_from,valid_to);

-- ---------------------------------------------------------
-- 9) Geographic / delivery / service coverage constraints
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_service_coverage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  coverage_type VARCHAR(40) NOT NULL,
  location_id UUID REFERENCES locations(id) ON DELETE SET NULL,
  geometry_json JSONB,
  radius_meters NUMERIC(20,6),
  rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_coverage_listing
  ON listing_service_coverage(listing_id,enabled);

-- ---------------------------------------------------------
-- 10) Compliance / safety / eligibility data
--     Policy-driven and reviewable; does not grant approval by itself.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS listing_compliance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  compliance_type VARCHAR(100) NOT NULL,
  jurisdiction_code VARCHAR(32),
  status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
  reference_number VARCHAR(300),
  expires_at TIMESTAMPTZ,
  evidence JSONB NOT NULL DEFAULT '{}'::jsonb,
  reviewer_actor_id UUID,
  reviewed_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_listing_compliance_scope
  ON listing_compliance(listing_id,compliance_type,jurisdiction_code,status);

-- ---------------------------------------------------------
-- 11) Listing versions / audit snapshot
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS universal_listing_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID NOT NULL REFERENCES universal_listings(id) ON DELETE CASCADE,
  version INTEGER NOT NULL,
  snapshot JSONB NOT NULL,
  change_reason VARCHAR(500),
  actor_user_id UUID,
  request_id VARCHAR(200),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(listing_id,version)
);

CREATE INDEX IF NOT EXISTS idx_universal_listing_versions_listing
  ON universal_listing_versions(listing_id,version DESC);

-- ---------------------------------------------------------
-- 12) Extension registry
--     Allows future technologies/standards/connectors to be registered
--     without altering the core ledger/security schema.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS extension_registry (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  extension_key VARCHAR(180) UNIQUE NOT NULL,
  extension_type VARCHAR(80) NOT NULL,
  version VARCHAR(80) NOT NULL,
  vendor_name VARCHAR(300),
  capabilities JSONB NOT NULL DEFAULT '{}'::jsonb,
  configuration_schema JSONB NOT NULL DEFAULT '{}'::jsonb,
  compatibility JSONB NOT NULL DEFAULT '{}'::jsonb,
  status VARCHAR(40) NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------
-- 13) Marketplace-wide policy flag
-- ---------------------------------------------------------
INSERT INTO policy_configs(key,value_json,description) VALUES
('platform.universal_market.enabled','true','قاعدة هلا قادرة على تمثيل أي سلعة/أصل/معدة/مكان/خدمة/حزمة/اشتراك قابل للبيع أو للتأجير وفق السياسة والقانون'),
('platform.universal_market.dynamic_attributes','true','خصائص الأصناف والأسواق ديناميكية ولا تتطلب إضافة أعمدة لكل نوع جديد'),
('platform.universal_market.dynamic_variants','true','دعم المتغيرات والمواصفات والتجهيزات المختلفة داخل العرض الواحد'),
('platform.universal_market.dynamic_standards','true','دعم المعرفات والمعايير الدولية عبر سجل مرن دون تغيير النواة'),
('platform.universal_market.dynamic_extensions','true','دعم تقنيات وموصلات وامتدادات مستقبلية عبر Extension Registry'),
('platform.core.strict_finance_security','true','النواة المالية والأمنية والصلاحيات والحالات الحرجة تبقى محكومة وليست ديناميكية بلا ضوابط')
ON CONFLICT(key) DO NOTHING;

COMMIT;
