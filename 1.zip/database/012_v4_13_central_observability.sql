-- Hala v4.13 central observability coverage.
BEGIN;
SET search_path TO hala, public;
INSERT INTO policy_configs(key,value_json,description) VALUES
('ai.platform_supervisor.observe_auth','true','المشرف المركزي يتلقى أحداث محاولات الدخول وOTP والحسابات الحساسة'),
('ai.platform_supervisor.observe_bookings','true','المشرف المركزي يتلقى أحداث دورة الحجز'),
('ai.platform_supervisor.observe_providers','true','المشرف المركزي يتلقى تغييرات واعتمادات المنتسبين'),
('ai.platform_supervisor.observe_demands','true','المشرف المركزي يتلقى أحداث الطلب والمطابقة'),
('ai.platform_supervisor.observe_disputes','true','المشرف المركزي يتلقى فتح النزاعات'),
('ai.platform_supervisor.telemetry_fail_open','true','فشل التسجيل التحليلي لا يوقف العملية التجارية الأساسية، ويُسجل كعطل مراقبة')
ON CONFLICT(key) DO UPDATE SET value_json=EXCLUDED.value_json,description=EXCLUDED.description;
COMMIT;
