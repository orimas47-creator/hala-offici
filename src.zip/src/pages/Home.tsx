/*
 * Design reminder: «ليالي صنعاء الملكية» — Neo-Moorish digital editorial.
 * Keep the RTL council-and-axes layout, antique gold #E8B85B, midnight navy,
 * Tajawal typography, subtle geometric motifs, and explicit prototype feedback.
 */
import {
  ArrowLeft,
  ArrowUpRight,
  BadgeCheck,
  Building2,
  CalendarDays,
  Camera,
  Check,
  ChevronDown,
  ChevronLeft,
  CircleHelp,
  Clock3,
  Crown,
  Gem,
  Gift,
  HandHeart,
  HeartHandshake,
  Home as HomeIcon,
  LayoutGrid,
  Mail,
  MapPin,
  Menu,
  Moon,
  Phone,
  Search,
  Shirt,
  ShoppingBag,
  Sparkles,
  Star,
  Store,
  TentTree,
  UserRound,
  Users,
  Utensils,
  X,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { toast } from "sonner";

type SectionKey =
  | "packages"
  | "newWeek"
  | "exclusive"
  | "occasions"
  | "menClothing"
  | "womenClothing"
  | "menAccessories"
  | "womenAccessories"
  | "religiousEvents"
  | "menServices"
  | "womenServices"
  | "commonServices"
  | "traditionalServices"
  | "markets"
  | "categories"
  | "providers"
  | "offers"
  | "about";

type SectionDefinition = {
  key: SectionKey;
  title: string;
  eyebrow: string;
  icon: LucideIcon;
  description: string;
};

type CatalogItem = {
  title: string;
  subtitle: string;
  price?: string;
  meta?: string;
  badge?: string;
  badgeTone?: "gold" | "green" | "red" | "blue";
  image?: string;
  emoji?: string;
  art?: string;
};

const ASSETS = {
  hero: "/manus-storage/hala-hero-night_b2617cd2.jpg",
  package: "/manus-storage/hala-package-maqeel_b92a547d.jpg",
  men: "/manus-storage/hala-mens-style_b8fe9e8b.jpg",
  women: "/manus-storage/hala-womens-style_579334a4.jpg",
  mark: "/manus-storage/hala-mark_04423eb0.png",
};

const sectionDefinitions: SectionDefinition[] = [
  { key: "packages", title: "الباقات الخاصة", eyebrow: "اختيارات هلا", icon: Gift, description: "حلول متكاملة تختصر عليك وقت تجهيز المناسبة." },
  { key: "newWeek", title: "جديد الأسبوع", eyebrow: "وصل حديثًا", icon: Sparkles, description: "خدمات ومنتجات جديدة تستحق أن تكون في قائمتك." },
  { key: "exclusive", title: "حصري للمنصة", eyebrow: "مختارات موثوقة", icon: Crown, description: "تجارب مختارة بعناية من شركائنا في مختلف المديريات." },
  { key: "occasions", title: "المناسبات", eyebrow: "اختر مناسبتك", icon: CalendarDays, description: "ابدأ من المناسبة، وسنقودك إلى كل ما يلزمها." },
  { key: "menClothing", title: "تأجير الملابس الرجالية", eyebrow: "إطلالة الرجل", icon: Shirt, description: "أثواب وجنابي وشالات للمظهر اليمني الأصيل." },
  { key: "womenClothing", title: "تأجير الملابس النسائية", eyebrow: "إطلالة المرأة", icon: Sparkles, description: "تراث صنعاني وعدني وحضرمي بلمسة معاصرة." },
  { key: "menAccessories", title: "إكسسوارات رجالية", eyebrow: "تفاصيل تكمّل الزي", icon: Gem, description: "من العقال إلى الساعة، تفاصيل تصنع الفرق." },
  { key: "womenAccessories", title: "إكسسوارات نسائية", eyebrow: "لمعة المناسبة", icon: Gem, description: "ذهب ولؤلؤ وتيجان وحقائب لليلة لا تنسى." },
  { key: "religiousEvents", title: "المناسبات الدينية", eyebrow: "مواسم مباركة", icon: Moon, description: "تنظيم المولد ورمضان والحج وغيرها من المناسبات." },
  { key: "menServices", title: "خدمات الرجال", eyebrow: "مجلس الرجل", icon: HandHeart, description: "تجهيز المقايل والبرعة والمنشدين وصالون العريس." },
  { key: "womenServices", title: "خدمات النساء", eyebrow: "تفاصيل أنيقة", icon: HeartHandshake, description: "حناء وتجميل وكوشة ومضيفات ومطربات نسائية." },
  { key: "commonServices", title: "خدمات مشتركة", eyebrow: "لكل المناسبة", icon: Building2, description: "قاعات وخيام ومطاعم ومصورون في مكان واحد." },
  { key: "traditionalServices", title: "خدمات تراثية", eyebrow: "روح اليمن", icon: TentTree, description: "قهوة وقشر وطبخ يمني وليلة غمرة أصيلة." },
  { key: "markets", title: "الأسواق والمولات", eyebrow: "تسوّق قريب", icon: Store, description: "هدايا وعطور وعسل ومكسرات ولوازم الضيافة." },
  { key: "categories", title: "أقسام المتجر", eyebrow: "تصفح حسب المجال", icon: LayoutGrid, description: "خريطة مختصرة لكل ما توفره منصة هلا." },
  { key: "providers", title: "مقدمو الخدمات", eyebrow: "شركاؤنا", icon: Users, description: "اكتشف مقدمي الخدمة حسب المدينة والتخصص." },
  { key: "offers", title: "العروض", eyebrow: "فرص هذا الأسبوع", icon: Star, description: "باقات وامتيازات تجريبية متاحة للاستكشاف." },
  { key: "about", title: "من نحن", eyebrow: "حكاية هلا", icon: CircleHelp, description: "تعرف على الفكرة التي تجمع تفاصيل المناسبة في مكان واحد." },
];

const mainNav = [
  { label: "الرئيسية", target: "top" },
  { label: "المناسبات", target: "occasions" },
  { label: "الخدمات", target: "commonServices" },
  { label: "مقدمو الخدمات", target: "providers" },
  { label: "العروض", target: "offers" },
  { label: "من نحن", target: "about" },
] as const;

const sidebarGroups = [
  { title: "نقطة البداية", items: [{ label: "نظرة عامة", target: "top", icon: HomeIcon }] },
  {
    title: "للرجل والمرأة",
    items: [
      { label: "أزياء رجالية", target: "menClothing", icon: Shirt },
      { label: "أزياء نسائية", target: "womenClothing", icon: Sparkles },
      { label: "إكسسوارات رجالية", target: "menAccessories", icon: Gem },
      { label: "إكسسوارات نسائية", target: "womenAccessories", icon: Gem },
    ],
  },
  {
    title: "الخدمات",
    items: [
      { label: "خدمات الرجال", target: "menServices", icon: HandHeart },
      { label: "خدمات النساء", target: "womenServices", icon: HeartHandshake },
      { label: "الخدمات المشتركة", target: "commonServices", icon: Building2 },
      { label: "الخدمات التراثية", target: "traditionalServices", icon: TentTree },
    ],
  },
  {
    title: "وجهات التسوق",
    items: [
      { label: "الأسواق والمولات", target: "markets", icon: Store },
      { label: "مقدمو الخدمات", target: "providers", icon: Users },
      { label: "المناسبات الدينية", target: "religiousEvents", icon: Moon },
    ],
  },
] as const;

const heroSlides = [
  { kicker: "باقة المقيل", title: "تجهيز كامل للمقايل", description: "فرش، مجالس، قهوة، قشر، وصبابين بالزي التقليدي", cta: "استكشف الباقة", target: "packages" as const, price: "80,000 ريال", image: ASSETS.package },
  { kicker: "ليلة الغمرة", title: "حناء وأزياء وضيافة", description: "تفاصيل نسائية دافئة تُرتب لك ليلة الغمرة من أول فكرة", cta: "شاهد خدمات النساء", target: "womenServices" as const, price: "120,000 ريال", image: ASSETS.women },
  { kicker: "الزفاف الكامل", title: "قاعة وديكور وتصوير", description: "ضيافة وترفيه وتفاصيل متناسقة في باقة واحدة", cta: "استكشف القاعات", target: "commonServices" as const, price: "450,000 ريال", image: ASSETS.hero },
  { kicker: "أناقة الرجل", title: "أفخم الثياب اليمنية", description: "أثواب وبدلات وشال صوف وجنابي للمناسبات الكبيرة", cta: "تصفح الأزياء", target: "menClothing" as const, price: "من 18,000 ريال", image: ASSETS.men },
  { kicker: "تفاصيل المناسبة", title: "من أول فنجان قهوة", description: "اجمع كل ما تحتاجه لمناسبتك في مسار واحد واضح", cta: "افتح التنقل السريع", target: "quick" as const, price: "15 قسمًا رئيسيًا", image: ASSETS.hero },
];

const catalog: Record<SectionKey, CatalogItem[]> = {
  packages: [
    { title: "باقة المقيل المتكاملة", subtitle: "مجلس وفرش وضيافة", price: "80,000 ريال", meta: "متاحة في صنعاء", badge: "الأكثر طلبًا", badgeTone: "gold", image: ASSETS.package },
    { title: "باقة ليلة الغمرة", subtitle: "حناء وأزياء وحلويات", price: "120,000 ريال", meta: "منسقة بالكامل", badge: "جديد", badgeTone: "green", image: ASSETS.women },
    { title: "باقة الزفاف الكامل", subtitle: "قاعة وديكور وتصوير", price: "450,000 ريال", meta: "اختيار فاخر", badge: "حصري", badgeTone: "gold", image: ASSETS.hero },
    { title: "باقة العريس", subtitle: "صالون وملابس وتصوير", price: "95,000 ريال", meta: "مرنة حسب العدد", badge: "مميز", badgeTone: "blue", emoji: "👔", art: "art-cobalt" },
  ],
  newWeek: [
    { title: "تصميم كوشة القمر", subtitle: "تنسيق وإضاءة ناعمة", price: "35,000 ريال", meta: "4.9 تقييم تجريبي", badge: "وصل حديثًا", badgeTone: "green", emoji: "🌙", art: "art-teal" },
    { title: "مصور لحظتك", subtitle: "تغطية فوتوغرافية", price: "28,000 ريال", meta: "8 ساعات", badge: "جديد", badgeTone: "green", emoji: "📸", art: "art-rose" },
    { title: "مضيفات الندى", subtitle: "ضيافة نسائية", price: "22,000 ريال", meta: "حسب عدد الضيوف", badge: "متاح", badgeTone: "blue", emoji: "🤍", art: "art-plum" },
    { title: "فرقة برعة صنعانية", subtitle: "عرض تراثي حي", price: "45,000 ريال", meta: "للمناسبات الكبيرة", badge: "جديد", badgeTone: "green", emoji: "🥁", art: "art-olive" },
  ],
  exclusive: [
    { title: "فستان الستارة الصنعانية", subtitle: "تأجير 24 ساعة", price: "32,000 ريال", meta: "صنعاء القديمة", badge: "حصري", badgeTone: "gold", image: ASSETS.women },
    { title: "جلسة تصوير السطح", subtitle: "إطلالة بانورامية", price: "18,000 ريال", meta: "مع مصور محترف", badge: "حصري", badgeTone: "gold", emoji: "📷", art: "art-sand" },
    { title: "طقم الجنبية الملكية", subtitle: "إكسسوار للعريس", price: "60,000 ريال", meta: "قطع محدودة", badge: "حصري", badgeTone: "gold", image: ASSETS.men },
    { title: "حلوى المولد الفاخرة", subtitle: "تغليف احتفالي", price: "12,000 ريال", meta: "صندوق 25 قطعة", badge: "حصري", badgeTone: "gold", emoji: "🍰", art: "art-amber" },
  ],
  occasions: [
    { title: "الزفاف", subtitle: "كل تفاصيل ليلة العمر", emoji: "💍", art: "art-gold" },
    { title: "الخطوبة", subtitle: "بداية الحكاية", emoji: "🌿", art: "art-olive" },
    { title: "ليلة الغمرة", subtitle: "احتفال نسائي أصيل", emoji: "🌙", art: "art-plum" },
    { title: "المولد النبوي", subtitle: "مناسبة دينية", emoji: "🕌", art: "art-teal" },
    { title: "التخرج", subtitle: "لحظة تستحق الاحتفال", emoji: "🎓", art: "art-cobalt" },
    { title: "العودة من الحج", subtitle: "ضيافة واستقبال", emoji: "🤍", art: "art-sand" },
  ],
  menClothing: [
    { title: "ثوب يمني أبيض", subtitle: "قماش فاخر بقصة مريحة", price: "15,000 ريال / يوم", meta: "مقاسات متعددة", badge: "متاح", badgeTone: "blue", image: ASSETS.men },
    { title: "بدلة العريس", subtitle: "تفصيل رسمي مع شال", price: "25,000 ريال / يوم", meta: "تشمل التعديلات", badge: "مميز", badgeTone: "gold", emoji: "🧵", art: "art-cobalt" },
    { title: "شال صوف حضرمي", subtitle: "تفصيل يدوي", price: "9,000 ريال / يوم", meta: "ألوان موسمية", emoji: "🧣", art: "art-plum" },
    { title: "طقم البرعة", subtitle: "زي تراثي كامل", price: "18,000 ريال / يوم", meta: "للعروض الجماعية", emoji: "🇾🇪", art: "art-red" },
  ],
  womenClothing: [
    { title: "ستارة صنعانية", subtitle: "تطريز مستوحى من التراث", price: "32,000 ريال / يوم", meta: "مع إكسسوارات", badge: "فاخر", badgeTone: "gold", image: ASSETS.women },
    { title: "لبس عدني", subtitle: "ألوان حيوية وقصة عصرية", price: "22,000 ريال / يوم", meta: "تجربة قبل الاستلام", emoji: "👗", art: "art-rose" },
    { title: "طقم حضرمي", subtitle: "قماش خفيف وتفاصيل ذهبية", price: "28,000 ريال / يوم", meta: "مناسب للغمرة", emoji: "✨", art: "art-amber" },
    { title: "فستان السهرة", subtitle: "اختيار عصري", price: "20,000 ريال / يوم", meta: "حجز مسبق", emoji: "💃", art: "art-teal" },
  ],
  menAccessories: [
    { title: "طقم جنبية فضية", subtitle: "حزام وخنجر بلمعة هادئة", price: "60,000 ريال", meta: "قطعة مميزة", image: ASSETS.men },
    { title: "عقال وغترة", subtitle: "تنسيق يوم المناسبة", price: "7,500 ريال", meta: "توصيل داخل المدينة", emoji: "👳", art: "art-sand" },
    { title: "ساعة المناسبات", subtitle: "تصميم كلاسيكي", price: "14,000 ريال", meta: "علبة هدية", emoji: "⌚", art: "art-cobalt" },
    { title: "حزام جلدي", subtitle: "تفصيل يدوي", price: "5,000 ريال", meta: "ألوان متعددة", emoji: "🤎", art: "art-olive" },
  ],
  womenAccessories: [
    { title: "تاج اللؤلؤ", subtitle: "لمسة ناعمة للعروس", price: "18,000 ريال", meta: "مع علبة حفظ", image: ASSETS.women },
    { title: "طقم أساور ذهبية", subtitle: "تنسيق للغمرة", price: "35,000 ريال", meta: "تأجير يومين", emoji: "💛", art: "art-gold" },
    { title: "حقيبة السهرة", subtitle: "ساتان وتفاصيل معدنية", price: "8,000 ريال", meta: "ألوان مختارة", emoji: "👜", art: "art-rose" },
    { title: "خلخال تراثي", subtitle: "تفصيل مستوحى من اليمن", price: "12,000 ريال", meta: "قطعة محدودة", emoji: "✨", art: "art-teal" },
  ],
  religiousEvents: [
    { title: "المولد النبوي", subtitle: "ضيافة وإنارة وتزيين", price: "من 35,000 ريال", meta: "خطة حسب العدد", emoji: "🕌", art: "art-teal" },
    { title: "رمضان المبارك", subtitle: "إفطار عائلي متكامل", price: "من 25,000 ريال", meta: "مطاعم موثوقة", emoji: "🌙", art: "art-plum" },
    { title: "العودة من الحج", subtitle: "حلويات وتغليف وهدايا", price: "من 15,000 ريال", meta: "طلبات جماعية", emoji: "🤍", art: "art-sand" },
    { title: "الإسراء والمعراج", subtitle: "تجهيز مجلس الضيافة", price: "من 20,000 ريال", meta: "متاح للحجز", emoji: "✨", art: "art-cobalt" },
  ],
  menServices: [
    { title: "تجهيز المقيل", subtitle: "فرش وقهوة وقشر وصبابين", price: "من 18,000 ريال", meta: "حسب السعة", image: ASSETS.package },
    { title: "فرقة البرعة", subtitle: "عرض تراثي للمناسبة", price: "من 45,000 ريال", meta: "فريق 6 أفراد", emoji: "🥁", art: "art-red" },
    { title: "منشد ومغني عود", subtitle: "جلسة طرب حية", price: "من 30,000 ريال", meta: "3 ساعات", emoji: "🎶", art: "art-olive" },
    { title: "صالون العريس", subtitle: "تجهيز كامل قبل الاحتفال", price: "من 12,000 ريال", meta: "زيارة منزلية", emoji: "✂️", art: "art-cobalt" },
  ],
  womenServices: [
    { title: "نقاشة حناء", subtitle: "تصاميم يمنية وعصرية", price: "من 15,000 ريال", meta: "تصل إلى المنزل", image: ASSETS.women },
    { title: "خبيرة تجميل", subtitle: "إطلالة العروس والضيفات", price: "من 25,000 ريال", meta: "تجربة قبل المناسبة", emoji: "💄", art: "art-rose" },
    { title: "تصميم كوشة", subtitle: "مقترحات وألوان وتنفيذ", price: "من 35,000 ريال", meta: "تصميم مخصص", emoji: "🌸", art: "art-plum" },
    { title: "مضيفات ومطربات", subtitle: "ضيافة وفقرات نسائية", price: "من 22,000 ريال", meta: "حسب عدد الضيوف", emoji: "🎤", art: "art-teal" },
  ],
  commonServices: [
    { title: "قاعات الأفراح", subtitle: "صالات مجهزة بمقاسات مختلفة", price: "من 120,000 ريال", meta: "أكثر من 50 قاعة", emoji: "🏛️", art: "art-gold" },
    { title: "الخيام الشعبية", subtitle: "مجالس مفتوحة بطابع يمني", price: "من 60,000 ريال", meta: "تركيب وفك", emoji: "⛺", art: "art-olive" },
    { title: "مطاعم الولائم", subtitle: "زربيان ومندي وكبسة", price: "من 18,000 ريال", meta: "قوائم حسب العدد", emoji: "🍛", art: "art-amber" },
    { title: "التصوير والفيديو", subtitle: "توثيق كامل للمناسبة", price: "من 28,000 ريال", meta: "صور وفيلم قصير", emoji: "📸", art: "art-cobalt" },
  ],
  traditionalServices: [
    { title: "مقايل القات", subtitle: "فرش وضيافة يمنية", price: "من 20,000 ريال", meta: "مكونات أصيلة", image: ASSETS.package },
    { title: "قهوة وقشر", subtitle: "تقديم تقليدي على أصوله", price: "من 8,000 ريال", meta: "للمناسبات العائلية", emoji: "☕", art: "art-amber" },
    { title: "طبخ يمني أصيل", subtitle: "سلتة وفحسة ومندي", price: "من 15,000 ريال", meta: "طهاة متخصصون", emoji: "🍲", art: "art-red" },
    { title: "ليلة الغمرة الشعبية", subtitle: "تفاصيل تراثية كاملة", price: "من 90,000 ريال", meta: "تنسيق شامل", emoji: "🌙", art: "art-plum" },
  ],
  markets: [
    { title: "سوق الهدايا", subtitle: "تغليف وتذكارات", price: "تصفح المتاجر", meta: "هدايا لكل مناسبة", emoji: "🎁", art: "art-gold" },
    { title: "سوق العطور", subtitle: "بخور وعنبر وعطور عربية", price: "تصفح المتاجر", meta: "مختارات محلية", emoji: "🪔", art: "art-rose" },
    { title: "العسل والمكسرات", subtitle: "ضيافة بطابع يمني", price: "تصفح المتاجر", meta: "طلبات المناسبات", emoji: "🍯", art: "art-amber" },
    { title: "الإكسسوارات", subtitle: "تفاصيل صغيرة بأثر كبير", price: "تصفح المتاجر", meta: "شحن داخل المدينة", emoji: "💎", art: "art-teal" },
  ],
  categories: [
    { title: "الأزياء", subtitle: "رجالية ونسائية", emoji: "👗", art: "art-plum" },
    { title: "الخدمات", subtitle: "من التخطيط للتنفيذ", emoji: "🤝", art: "art-cobalt" },
    { title: "الضيافة", subtitle: "قهوة وطعام وهدايا", emoji: "☕", art: "art-amber" },
    { title: "التصوير", subtitle: "حفظ اللحظة", emoji: "📸", art: "art-teal" },
    { title: "القاعات", subtitle: "أماكن تناسب عددك", emoji: "🏛️", art: "art-gold" },
    { title: "التراث", subtitle: "روح اليمن الأصيلة", emoji: "🇾🇪", art: "art-red" },
  ],
  providers: [
    { title: "دار السعيدة", subtitle: "تنظيم وتنسيق مناسبات", meta: "صنعاء · 12 سنة خبرة", badge: "موثوق", badgeTone: "green", emoji: "🏛️", art: "art-gold" },
    { title: "لمسة حناء", subtitle: "جمال وحناء نسائية", meta: "إب · حجز مسبق", badge: "متاح", badgeTone: "blue", emoji: "🌸", art: "art-rose" },
    { title: "مجالس اليمن", subtitle: "مقايل وخيام شعبية", meta: "تعز · تجهيز كامل", badge: "حصري", badgeTone: "gold", emoji: "⛺", art: "art-olive" },
    { title: "عدسة هلا", subtitle: "تصوير وفيديو", meta: "صنعاء · فريق 4 أفراد", badge: "موثوق", badgeTone: "green", emoji: "📸", art: "art-cobalt" },
  ],
  offers: [
    { title: "تنسيق الباقة الذهبية", subtitle: "خصم محاكاة 15% على الخدمات المجمعة", price: "حتى 15%", meta: "ساري هذا الأسبوع", badge: "عرض", badgeTone: "red", emoji: "🎁", art: "art-gold" },
    { title: "توصيل الإكسسوارات", subtitle: "توصيل مجاني داخل المدينة", price: "مجاني", meta: "للطلبات فوق 20,000", badge: "عرض", badgeTone: "red", emoji: "🚚", art: "art-teal" },
    { title: "جلسة استشارة", subtitle: "مكالمة أولية مع منسق مناسبات", price: "بدون رسوم", meta: "20 دقيقة", badge: "جديد", badgeTone: "green", emoji: "📞", art: "art-cobalt" },
  ],
  about: [
    { title: "فكرة تجمعنا", subtitle: "منصة يمنية لخدمات المناسبات", meta: "تجربة محاكاة", emoji: "✨", art: "art-gold" },
    { title: "رحلة واضحة", subtitle: "من اختيار المناسبة إلى تفاصيلها", meta: "تنقل سهل", emoji: "🧭", art: "art-teal" },
    { title: "شراكات محلية", subtitle: "نقرّبك من مقدمي الخدمة", meta: "حسب مدينتك", emoji: "🤝", art: "art-olive" },
  ],
};

const quickNavItems = sectionDefinitions.slice(0, 15);

function getItemStyle(item: CatalogItem): CSSProperties {
  if (item.image) return { backgroundImage: `linear-gradient(180deg, rgba(10,3,24,.06), rgba(10,3,24,.88)), url(${item.image})` };
  return {};
}

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand-lockup ${compact ? "brand-lockup-compact" : ""}`}>
      <img src={ASSETS.mark} alt="شعار هلا" className="brand-mark" />
      <div>
        <span className="brand-name">هلا</span>
        {!compact && <span className="brand-subtitle">المتعاهد الشامل</span>}
      </div>
    </div>
  );
}

function PrototypeStamp() {
  return <span className="prototype-stamp"><span className="stamp-dot" /> نسخة تجريبية</span>;
}

function SectionHeading({ section, onSeeAll }: { section: SectionDefinition; onSeeAll: (key: SectionKey) => void }) {
  const Icon = section.icon;
  return (
    <div className="section-heading">
      <div className="heading-copy">
        <div className="eyebrow"><Icon size={14} /> {section.eyebrow}</div>
        <h2><span className="heading-rule" />{section.title}</h2>
        <p>{section.description}</p>
      </div>
      <button className="see-all" onClick={() => onSeeAll(section.key)}>عرض الكل <ArrowLeft size={15} /></button>
    </div>
  );
}

function CatalogCard({ item, onOpen }: { item: CatalogItem; onOpen: (item: CatalogItem) => void }) {
  return (
    <button className="catalog-card" onClick={() => onOpen(item)}>
      <div className={`card-art ${item.art ?? ""}`} style={getItemStyle(item)}>
        {!item.image && <span className="card-emoji">{item.emoji}</span>}
        {item.badge && <span className={`card-badge badge-${item.badgeTone ?? "gold"}`}>{item.badge}</span>}
        <span className="card-open"><ArrowUpRight size={16} /></span>
      </div>
      <div className="card-body">
        <div className="card-title-row"><h3>{item.title}</h3><span className="card-dot" /></div>
        <p>{item.subtitle}</p>
        <div className="card-meta-row">
          {item.price ? <strong>{item.price}</strong> : <span>{item.meta}</span>}
          {item.price && <span>{item.meta}</span>}
        </div>
      </div>
    </button>
  );
}

function MiniCategory({ item, onOpen }: { item: CatalogItem; onOpen: (item: CatalogItem) => void }) {
  return (
    <button className={`mini-category ${item.art ?? ""}`} onClick={() => onOpen(item)}>
      <span className="mini-icon">{item.emoji}</span>
      <span><strong>{item.title}</strong><small>{item.subtitle}</small></span>
      <ChevronLeft size={16} />
    </button>
  );
}

export default function Home() {
  const [activeTarget, setActiveTarget] = useState("top");
  const [activeSlide, setActiveSlide] = useState(0);
  const [quickNavOpen, setQuickNavOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<CatalogItem | null>(null);
  const [query, setQuery] = useState("");

  const filteredSections = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return sectionDefinitions;
    return sectionDefinitions.filter((section) => `${section.title} ${section.description}`.toLowerCase().includes(normalized));
  }, [query]);

  useEffect(() => {
    const timer = window.setInterval(() => setActiveSlide((current) => (current + 1) % heroSlides.length), 6500);
    return () => window.clearInterval(timer);
  }, []);

  const navigateTo = (target: string) => {
    setActiveTarget(target);
    setQuickNavOpen(false);
    setMobileNavOpen(false);
    setSearchOpen(false);
    if (target === "quick") {
      setQuickNavOpen(true);
      return;
    }
    window.requestAnimationFrame(() => {
      if (target === "top") window.scrollTo({ top: 0, behavior: "smooth" });
      else document.getElementById(target)?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  };

  const openItem = (item: CatalogItem) => setSelectedItem(item);
  const showComingSoon = (label: string) => toast(`${label} — هذه نسخة محاكاة، وسيتم تفعيل الإجراء في النسخة القادمة.`);

  return (
    <div className="hala-app">
      <header className="topbar">
        <div className="topbar-inner">
          <div className="topbar-start">
            <button className="mobile-menu-btn" aria-label="فتح القائمة" onClick={() => setMobileNavOpen(true)}><Menu size={20} /></button>
            <button className="quick-launch" onClick={() => setQuickNavOpen(true)}><LayoutGrid size={17} /><span>التنقل السريع</span></button>
            <button className="search-trigger" aria-label="بحث" onClick={() => setSearchOpen(true)}><Search size={19} /></button>
          </div>
          <nav className="top-nav" aria-label="التنقل الرئيسي">
            {mainNav.map((item) => <button key={item.target} className={activeTarget === item.target ? "active" : ""} onClick={() => navigateTo(item.target)}>{item.label}</button>)}
          </nav>
          <div className="topbar-end">
            <button className="login-button" onClick={() => setLoginOpen(true)}><UserRound size={17} /> تسجيل الدخول</button>
            <button className="register-button" onClick={() => setLoginOpen(true)}>انضم إلى هلا <ArrowLeft size={16} /></button>
            <BrandMark compact />
          </div>
        </div>
      </header>

      <div className="app-shell">
        <main className="content-column">
          <section className="hero" id="top">
            <div className="hero-backdrop" style={{ backgroundImage: `linear-gradient(90deg, rgba(10,3,24,.97) 0%, rgba(10,3,24,.68) 42%, rgba(10,3,24,.12) 100%), url(${heroSlides[activeSlide].image})` }} />
            <div className="hero-ornament ornament-top" /><div className="hero-ornament ornament-bottom" />
            <div className="hero-content">
              <div className="hero-overline"><PrototypeStamp /><span>منصة تجهيز المناسبات اليمنية</span></div>
              <h1>{heroSlides[activeSlide].title}</h1>
              <p>{heroSlides[activeSlide].description}</p>
              <div className="hero-actions"><button className="gold-button" onClick={() => navigateTo(heroSlides[activeSlide].target)}>{heroSlides[activeSlide].cta} <ArrowLeft size={17} /></button><span className="hero-price">{heroSlides[activeSlide].price}</span></div>
              <div className="hero-trust"><span><BadgeCheck size={15} /> مزودون مختارون</span><span><MapPin size={15} /> جميع المديريات</span></div>
            </div>
            <div className="hero-side-note"><span className="side-note-line" /><span>يجمعنا</span><small>01 / 05</small></div>
            <div className="hero-dots">{heroSlides.map((slide, index) => <button key={slide.title} aria-label={`الشريحة ${index + 1}`} className={activeSlide === index ? "active" : ""} onClick={() => setActiveSlide(index)} />)}</div>
          </section>

          <div className="mobile-section-picker">
            <button onClick={() => setQuickNavOpen(true)}><LayoutGrid size={18} /> اختر قسمًا للتصفح <ChevronDown size={17} /></button>
          </div>

          <section className="section-block featured-strip" id="offers">
            <div className="feature-intro"><span className="eyebrow"><Star size={14} /> لفتة هذا الأسبوع</span><h2>تفاصيل صغيرة، <em>أثر كبير.</em></h2><p>تعرّف على العروض التجريبية المختارة، ثم افتح أي بطاقة لتشاهد كيف ستبدو رحلة الحجز.</p><button className="text-button" onClick={() => navigateTo("offers")}>كل العروض <ArrowLeft size={15} /></button></div>
            <div className="feature-stat"><strong>15</strong><span>قسمًا رئيسيًا<br />قابلًا للاستكشاف</span></div>
            <div className="feature-stat"><strong>50+</strong><span>قاعة ومكان<br />في مختلف المديريات</span></div>
          </section>

          <section className="section-block" id="packages"><SectionHeading section={sectionDefinitions.find((item) => item.key === "packages")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.packages.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="newWeek"><SectionHeading section={sectionDefinitions.find((item) => item.key === "newWeek")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.newWeek.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="exclusive"><SectionHeading section={sectionDefinitions.find((item) => item.key === "exclusive")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.exclusive.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>

          <section className="section-block occasion-section" id="occasions"><SectionHeading section={sectionDefinitions.find((item) => item.key === "occasions")!} onSeeAll={(key) => navigateTo(key)} /><div className="mini-grid">{catalog.occasions.map((item) => <MiniCategory key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="menClothing"><SectionHeading section={sectionDefinitions.find((item) => item.key === "menClothing")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.menClothing.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="womenClothing"><SectionHeading section={sectionDefinitions.find((item) => item.key === "womenClothing")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.womenClothing.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="menAccessories"><SectionHeading section={sectionDefinitions.find((item) => item.key === "menAccessories")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.menAccessories.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="womenAccessories"><SectionHeading section={sectionDefinitions.find((item) => item.key === "womenAccessories")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.womenAccessories.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="religiousEvents"><SectionHeading section={sectionDefinitions.find((item) => item.key === "religiousEvents")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.religiousEvents.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="menServices"><SectionHeading section={sectionDefinitions.find((item) => item.key === "menServices")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.menServices.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="womenServices"><SectionHeading section={sectionDefinitions.find((item) => item.key === "womenServices")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.womenServices.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="commonServices"><SectionHeading section={sectionDefinitions.find((item) => item.key === "commonServices")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.commonServices.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="traditionalServices"><SectionHeading section={sectionDefinitions.find((item) => item.key === "traditionalServices")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.traditionalServices.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>
          <section className="section-block" id="markets"><SectionHeading section={sectionDefinitions.find((item) => item.key === "markets")!} onSeeAll={(key) => navigateTo(key)} /><div className="catalog-scroll">{catalog.markets.map((item) => <CatalogCard key={item.title} item={item} onOpen={openItem} />)}</div></section>

          <section className="section-block category-section" id="categories"><SectionHeading section={sectionDefinitions.find((item) => item.key === "categories")!} onSeeAll={(key) => navigateTo(key)} /><div className="category-grid">{catalog.categories.map((item) => <button key={item.title} className={`category-tile ${item.art ?? ""}`} onClick={() => openItem(item)}><span className="category-icon">{item.emoji}</span><span><strong>{item.title}</strong><small>{item.subtitle}</small></span><ArrowUpRight size={18} /></button>)}</div></section>

          <section className="editorial-section" id="providers"><div className="editorial-copy"><span className="eyebrow"><Users size={14} /> شركاؤنا في الطريق</span><h2>مقدمو الخدمة<br /><em>يصنعون الفرق.</em></h2><p>تصفح شبكة منسقي المناسبات، المصورين، الطهاة، ومصممي الأزياء. كل بطاقة هنا تفتح لك نبذة أولية عن الشريك ومساره.</p><button className="gold-button" onClick={() => navigateTo("providers")}>اكتشف الشركاء <ArrowLeft size={17} /></button></div><div className="provider-stack">{catalog.providers.map((item, index) => <button key={item.title} className={`provider-card provider-${index + 1}`} onClick={() => openItem(item)}><span className={`provider-avatar ${item.art}`}>{item.emoji}</span><span><strong>{item.title}</strong><small>{item.subtitle}</small><em>{item.meta}</em></span><ChevronLeft size={17} /></button>)}</div></section>

          <section className="about-section" id="about"><div className="about-mark"><img src={ASSETS.mark} alt="" /></div><div><span className="eyebrow"><CircleHelp size={14} /> حكاية هلا</span><h2>منصة تقول لك: <em>هلا.</em></h2><p>هلا مساحة تجريبية تجمع تجهيزات المناسبات اليمنية في تجربة واحدة. الهدف ليس أن نزيد الخيارات، بل أن نجعل الطريق بينها أقصر، وأوضح، وأقرب إلى روح المناسبة.</p><div className="about-points"><span><Check size={15} /> تنقل منظم</span><span><Check size={15} /> أقسام واضحة</span><span><Check size={15} /> محاكاة صريحة</span></div></div><button className="outline-button" onClick={() => showComingSoon("تواصل معنا")}>تحدث مع فريق هلا <ArrowLeft size={16} /></button></section>

          <footer className="footer"><div><BrandMark /><p>منصة يمنية شاملة تجمع مزودي خدمات المناسبات في مكان واحد.</p></div><div className="footer-links"><button onClick={() => navigateTo("top")}>الرئيسية</button><button onClick={() => navigateTo("offers")}>العروض</button><button onClick={() => navigateTo("providers")}>مقدمو الخدمات</button><button onClick={() => showComingSoon("مركز المساعدة")}>مركز المساعدة</button></div><div className="footer-contact"><span><Phone size={14} /> 777 000 000</span><span><Mail size={14} /> hello@hala.example</span></div><small className="footer-note">جميع الأزرار والبيانات في هذه الصفحة لأغراض المحاكاة.</small></footer>
        </main>

        <aside className="sidebar" aria-label="الأقسام">
          <div className="sidebar-brand"><BrandMark /><p>كل تفاصيل مناسبتك<br />تبدأ من هنا.</p></div>
          <button className="sidebar-quick" onClick={() => setQuickNavOpen(true)}><span className="quick-icon"><LayoutGrid size={18} /></span><span><strong>التنقل السريع</strong><small>افتح خريطة الأقسام</small></span><ArrowLeft size={16} /></button>
          <div className="sidebar-groups">{sidebarGroups.map((group) => <div className="sidebar-group" key={group.title}><div className="sidebar-group-title">{group.title}</div>{group.items.map((item) => { const Icon = item.icon; return <button key={item.target} className={activeTarget === item.target ? "active" : ""} onClick={() => navigateTo(item.target)}><Icon size={17} /><span>{item.label}</span>{activeTarget === item.target && <span className="active-indicator" />}</button>; })}</div>)}</div>
          <div className="sidebar-help"><div className="help-icon"><Phone size={16} /></div><span><strong>تحتاج مساعدة؟</strong><small>منسق هلا جاهز للإجابة</small></span><button aria-label="اتصل بنا" onClick={() => showComingSoon("الاتصال بالمنسق")}><ChevronLeft size={16} /></button></div>
        </aside>
      </div>

      {mobileNavOpen && <div className="overlay mobile-overlay" onClick={() => setMobileNavOpen(false)}><aside className="mobile-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-header"><BrandMark compact /><button onClick={() => setMobileNavOpen(false)} aria-label="إغلاق"><X size={21} /></button></div><div className="drawer-quick"><button onClick={() => navigateTo("quick")}><LayoutGrid size={18} /> التنقل السريع <ArrowLeft size={17} /></button></div>{sidebarGroups.map((group) => <div className="drawer-group" key={group.title}><span>{group.title}</span>{group.items.map((item) => { const Icon = item.icon; return <button key={item.target} onClick={() => navigateTo(item.target)}><Icon size={17} /> {item.label}<ChevronLeft size={15} /></button>; })}</div>)}</aside></div>}

      {quickNavOpen && <div className="overlay" onClick={() => setQuickNavOpen(false)}><div className="quick-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setQuickNavOpen(false)} aria-label="إغلاق"><X size={20} /></button><div className="modal-kicker"><LayoutGrid size={15} /> خريطة التجربة</div><h2>افتح أي قسم<br /><em>بلمسة واحدة.</em></h2><p>كل الروابط هنا تقودك مباشرة إلى الجزء المقابل في الواجهة.</p><div className="quick-grid">{quickNavItems.map((item, index) => { const Icon = item.icon; return <button key={item.key} onClick={() => navigateTo(item.key)}><span className="quick-number">{String(index + 1).padStart(2, "0")}</span><Icon size={19} /><span>{item.title}</span><ArrowUpRight size={15} /></button>; })}</div></div></div>}

      {searchOpen && <div className="overlay" onClick={() => setSearchOpen(false)}><div className="search-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setSearchOpen(false)} aria-label="إغلاق"><X size={20} /></button><div className="modal-kicker"><Search size={15} /> بحث داخل الأقسام</div><div className="search-field"><Search size={19} /><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث عن مناسبة، خدمة، أو قسم..." /></div><div className="search-results">{filteredSections.length ? filteredSections.slice(0, 8).map((section) => { const Icon = section.icon; return <button key={section.key} onClick={() => navigateTo(section.key)}><span><Icon size={18} /><strong>{section.title}</strong></span><ChevronLeft size={16} /></button>; }) : <div className="empty-search">لا توجد نتائج بعد. جرّب كلمة أخرى.</div>}</div></div></div>}

      {loginOpen && <div className="overlay" onClick={() => setLoginOpen(false)}><div className="login-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setLoginOpen(false)} aria-label="إغلاق"><X size={20} /></button><div className="login-mark"><img src={ASSETS.mark} alt="" /></div><span className="modal-kicker">مساحتك في هلا</span><h2>مرحبًا بك من جديد.</h2><p>سجّل الدخول لمتابعة اختياراتك وحفظ تفاصيل مناسبتك.</p><label>رقم الهاتف أو البريد الإلكتروني<input placeholder="أدخل بياناتك هنا" /></label><label>كلمة المرور<input type="password" placeholder="••••••••" /></label><button className="gold-button full" onClick={() => { setLoginOpen(false); showComingSoon("تسجيل الدخول"); }}>تسجيل الدخول <ArrowLeft size={16} /></button><button className="modal-text-button" onClick={() => showComingSoon("إنشاء حساب")}>ليس لديك حساب؟ انضم إلى هلا</button></div></div>}

      {selectedItem && <div className="overlay" onClick={() => setSelectedItem(null)}><div className="detail-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setSelectedItem(null)} aria-label="إغلاق"><X size={20} /></button><div className={`detail-art ${selectedItem.art ?? ""}`} style={getItemStyle(selectedItem)}>{!selectedItem.image && <span>{selectedItem.emoji}</span>}</div><div className="detail-content">{selectedItem.badge && <span className={`card-badge badge-${selectedItem.badgeTone ?? "gold"}`}>{selectedItem.badge}</span>}<h2>{selectedItem.title}</h2><p className="detail-subtitle">{selectedItem.subtitle}</p><div className="detail-facts"><span><MapPin size={15} /> متاح في المديريات الرئيسية</span><span><Clock3 size={15} /> استجابة خلال 24 ساعة</span><span><BadgeCheck size={15} /> بيانات محاكاة</span></div>{selectedItem.price && <strong className="detail-price">{selectedItem.price}</strong>}<button className="gold-button full" onClick={() => { setSelectedItem(null); showComingSoon(`طلب ${selectedItem.title}`); }}>اطلب التفاصيل <ArrowLeft size={16} /></button></div></div></div>}
    </div>
  );
}
