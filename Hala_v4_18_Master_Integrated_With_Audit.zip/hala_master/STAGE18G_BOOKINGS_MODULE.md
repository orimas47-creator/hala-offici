# Stage 18G — BookingsModule

Implemented as a real NestJS module and connected to InventoryModule.

## Dependency chain
Auth -> Markets/Providers/Listings -> Availability -> Inventory -> Bookings -> (next) Payments/Escrow/Timers/Notifications

## Atomicity
The critical lifecycle operations use one TypeORM QueryRunner transaction:
- PAYMENT_PENDING: reserve inventory + lifecycle update + history + audit + timer creation.
- PROVIDER_PENDING/CONFIRMED/IN_PROGRESS/RETURN_PENDING/INSPECTION: activate inventory + lifecycle update + history + audit.
- CANCELLED/FAILED/COMPLETED: release/sell inventory + lifecycle update + history + audit.

## Security
- UUID validation and DTO validation.
- Authenticated actor only.
- Booking access derived from customer/provider relationship or privileged role.
- No client-supplied total is trusted.
- Idempotency support.
- Optimistic lifecycle versioning.
- Row-level transaction locks.
- No direct wallet/ledger mutations.

## Extensibility
The booking source is abstracted to legacy service offers or universal listings, allowing future markets to reuse the same booking engine without new application code.
