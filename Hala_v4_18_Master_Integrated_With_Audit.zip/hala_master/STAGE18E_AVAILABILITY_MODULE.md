# Hala v4.18 — Stage 18E AvailabilityModule

## Implemented
- NestJS `AvailabilityModule`, controller, service, DTO and contract test.
- Preserves the legacy `/api/v1/services/:id/availability` route.
- Preserves the universal `/api/v1/listings/:id/availability` route with BUY/RENT.
- Checks maintenance blocks, active holds, inventory reservations and active booking wishes.
- Universal inventory preview uses PostgreSQL advisory transaction locking and row locks before allocation preview.
- Read-only availability endpoints do not insert reservations.
- Uses the canonical v4.17 database tables and does not create a parallel inventory model.

## Verification
- TypeScript transpile check: PASS (0 diagnostics for backend module sources).
- Legacy Node syntax check: PASS.
- Existing Node contract suite: 82/82 PASS.
- PostgreSQL runtime/E2E: NOT CERTIFIED in this environment because PostgreSQL/Docker and installed npm dependencies are unavailable.
