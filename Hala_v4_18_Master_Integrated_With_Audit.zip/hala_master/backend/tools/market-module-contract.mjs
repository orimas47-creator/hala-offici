import fs from 'node:fs';
import path from 'node:path';

const root = new URL('..', import.meta.url).pathname;
const controller = fs.readFileSync(path.join(root, 'src/modules/markets/markets.controller.ts'), 'utf8');
const service = fs.readFileSync(path.join(root, 'src/modules/markets/markets.service.ts'), 'utf8');
const app = fs.readFileSync(path.join(root, 'src/app.module.ts'), 'utf8');

const requiredControllerRoutes = [
  "'markets/:marketKey/config'",
  "'admin/markets'",
  "'admin/markets/:id'",
  "'admin/markets/:id/reference'",
  "'admin/markets/:id/activate'",
  "'admin/markets/:id/pause'",
  "'admin/markets/:id/archive'",
  "'admin/markets/:id/restore'",
  "'admin/markets/:id/delete'",
  "'admin/markets/:id/sections'",
  "'admin/markets/:id/attributes'",
  "'admin/markets/:id/operations'",
  "'admin/markets/:id/ui-configs'",
  "'admin/market-sections/:id'",
  "'admin/market-attributes/:id'",
  "'admin/market-ui-configs/:id'",
  "'admin/market-ui-configs/:id/publish'",
  "'admin/markets/:id/providers'",
  "'admin/market-provider-memberships/:id/suspend'",
];

for (const route of requiredControllerRoutes) {
  if (!controller.includes(route)) throw new Error(`Missing market route contract: ${route}`);
}

for (const method of [
  'createMarket(', 'getMarket(', 'updateMarket(', 'setReferenceTemplate(', 'activateMarket(', 'pauseMarket(', 'archiveMarket(',
  'softDeleteMarket(', 'restoreMarket(', 'createSection(', 'createAttribute(', 'upsertOperation(', 'createUiConfig(',
  'updateSection(', 'updateAttribute(', 'updateUiConfig(', 'publishUiConfig(', 'addProvider(', 'suspendProvider(', 'getPublicMarketConfig(',
]) {
  if (!service.includes(method)) throw new Error(`Missing market service contract: ${method}`);
}

if (!app.includes('MarketsModule')) throw new Error('MarketsModule is not wired into AppModule');

console.log(`Market module contract OK: ${requiredControllerRoutes.length} routes + service wiring`);

const dockerfile = fs.readFileSync(path.join(root, 'Dockerfile'), 'utf8');
if (!dockerfile.includes('npm run build')) throw new Error('Docker image does not build NestJS dist output');
if (!dockerfile.includes('CMD ["node","dist/main.js"]')) throw new Error('Docker image is not configured to start NestJS main');

const compose = fs.readFileSync(path.join(root, '..', 'infra/docker/docker-compose.yml'), 'utf8');
if (!compose.includes('HALA_CORS_ORIGINS:')) throw new Error('Compose is not aligned with NestJS CORS environment variable');
