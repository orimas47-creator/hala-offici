import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ActorContext } from '../../common/decorators/actor.decorator.js';
import { HalaAuthGuard, RequireActorGuard } from '../../common/guards/hala-auth.guard.js';
import type { AuthRequestContext } from '../auth/auth.types.js';
import {
  AddMarketProviderDto,
  CreateAttributeDto,
  CreateMarketDto,
  CreateSectionDto,
  CreateUiConfigDto,
  UpdateAttributeDto,
  UpdateMarketDto,
  UpdateSectionDto,
  UpdateUiConfigDto,
  UpsertOperationDto,
} from './dto/market.dto.js';
import { MarketsService } from './markets.service.js';

@Controller('api/v1')
@UseGuards(HalaAuthGuard)
export class MarketsController {
  constructor(private readonly markets: MarketsService) {}

  @Get('markets/:marketKey/config')
  getPublicMarketConfig(@Param('marketKey') marketKey: string) {
    return this.markets.getPublicMarketConfig(marketKey);
  }

  @UseGuards(RequireActorGuard)
  @Get('admin/markets')
  listMarkets(@ActorContext() ctx: AuthRequestContext) {
    return this.markets.listMarkets(ctx.actorId);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets')
  createMarket(@Body() dto: CreateMarketDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.createMarket(ctx.actorId, dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Get('admin/markets/:id')
  getMarket(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.getMarket(ctx.actorId, id);
  }

  @UseGuards(RequireActorGuard)
  @Patch('admin/markets/:id')
  updateMarket(@Param('id') id: string, @Body() dto: UpdateMarketDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.updateMarket(ctx.actorId, id, dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/reference')
  setReferenceTemplate(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.setReferenceTemplate(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/activate')
  activateMarket(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.activateMarket(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/pause')
  pauseMarket(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.pauseMarket(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/archive')
  archiveMarket(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.archiveMarket(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/restore')
  restoreMarket(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.restoreMarket(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Delete('admin/markets/:id/delete')
  softDeleteMarket(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.softDeleteMarket(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/sections')
  createSection(@Param('id') id: string, @Body() dto: CreateSectionDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.createSection(ctx.actorId, id, dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/attributes')
  createAttribute(@Param('id') id: string, @Body() dto: CreateAttributeDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.createAttribute(ctx.actorId, id, dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/operations')
  upsertOperation(@Param('id') id: string, @Body() dto: UpsertOperationDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.upsertOperation(ctx.actorId, id, dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/ui-configs')
  createUiConfig(@Param('id') id: string, @Body() dto: CreateUiConfigDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.createUiConfig(ctx.actorId, id, dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Patch('admin/market-sections/:id')
  updateSection(@Param('id') id: string, @Body() dto: UpdateSectionDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.updateSection(ctx.actorId, id, dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Delete('admin/market-sections/:id')
  archiveSection(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.archiveSection(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Patch('admin/market-attributes/:id')
  updateAttribute(@Param('id') id: string, @Body() dto: UpdateAttributeDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.updateAttribute(ctx.actorId, id, dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Delete('admin/market-attributes/:id')
  archiveAttribute(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.archiveAttribute(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Patch('admin/market-ui-configs/:id')
  updateUiConfig(@Param('id') id: string, @Body() dto: UpdateUiConfigDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.updateUiConfig(ctx.actorId, id, dto, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Delete('admin/market-ui-configs/:id')
  archiveUiConfig(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.archiveUiConfig(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/market-ui-configs/:id/publish')
  publishUiConfig(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.publishUiConfig(ctx.actorId, id, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/markets/:id/providers')
  addProvider(@Param('id') id: string, @Body() dto: AddMarketProviderDto, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.addProvider(ctx.actorId, id, dto.providerId, ctx);
  }

  @UseGuards(RequireActorGuard)
  @Post('admin/market-provider-memberships/:id/suspend')
  suspendProvider(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.markets.suspendProvider(ctx.actorId, id, ctx);
  }
}
