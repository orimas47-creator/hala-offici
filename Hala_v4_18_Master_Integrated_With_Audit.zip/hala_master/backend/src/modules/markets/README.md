# MarketsModule — Stage 18C

This module migrates the v4.6/v4.17 Market Builder into NestJS while preserving the universal-market contract.

## What is implemented
- Generic market create/update/list/detail.
- Reference-template selection.
- Template cloning: sections, categories, services, dynamic attributes, operation configs, published UI configs, approved policies.
- Market lifecycle: activate, pause, archive, soft-delete, restore.
- Dynamic sections and listing-attribute definitions.
- Versioned operation configuration.
- Versioned UI configuration with draft/publish/archive flow.
- Market-provider membership add/suspend.
- Public market configuration endpoint with no provider identity/address exposure.
- Transactional writes + row locking + market audit log + platform audit log.
- Central AI binding is attached when a market is created, when the supervisor exists.

## Invariants
- A market cannot activate without at least one enabled operation.
- Only active, non-deleted markets are public.
- Template source must be active and non-deleted.
- Section/category cross-market references are rejected.
- Financial tables and balances are not modified by the Market Builder.
