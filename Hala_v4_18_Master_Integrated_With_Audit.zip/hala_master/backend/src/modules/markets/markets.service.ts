import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { DataSource, QueryRunner } from 'typeorm';
import type { AuthRequestContext } from '../auth/auth.types.js';
import type {
  CreateAttributeDto,
  CreateMarketDto,
  CreateSectionDto,
  CreateUiConfigDto,
  UpdateAttributeDto,
  UpdateMarketDto,
  UpdateSectionDto,
  UpdateUiConfigDto,
  UpsertOperationDto,
} from './dto/market.dto.js';

const UUID_RX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ADMIN_ROLES = ['admin', 'super_admin', 'administrator'];
const OPERATIONS = ['BUY', 'RENT', 'BUY_OR_RENT', 'SERVICE', 'QUOTE'] as const;
const MARKET_STATUSES = ['DRAFT', 'ACTIVE', 'PAUSED', 'ARCHIVED'] as const;

@Injectable()
export class MarketsService {
  constructor(private readonly dataSource: DataSource) {}

  private requireActor(actorId: string | null): asserts actorId is string {
    if (!actorId) throw new UnauthorizedException('ACTOR_REQUIRED');
  }

  private assertUuid(value: string, code: string): void {
    if (!UUID_RX.test(String(value ?? ''))) throw new BadRequestException(code);
  }

  private normalizeMarketKey(value: string): string {
    const key = String(value ?? '').trim().toLowerCase().replace(/\s+/g, '-');
    if (!/^[a-z0-9][a-z0-9_-]{1,119}$/.test(key)) throw new BadRequestException('INVALID_MARKET_KEY');
    return key;
  }

  private async hasAnyRole(actorId: string, roles: string[], runner?: QueryRunner): Promise<boolean> {
    const executor = runner?.query.bind(runner) ?? this.dataSource.query.bind(this.dataSource);
    const rows = await executor(
      `SELECT 1
         FROM hala.user_roles ur
         JOIN hala.roles r ON r.id=ur.role_id
        WHERE ur.user_id=$1 AND lower(r.name)=ANY($2::text[])
        LIMIT 1`,
      [actorId, roles.map((role) => role.toLowerCase())],
    );
    return rows.length > 0;
  }

  private async requireManager(actorId: string, runner?: QueryRunner): Promise<void> {
    const executor = runner?.query.bind(runner) ?? this.dataSource.query.bind(this.dataSource);
    const rows = await executor(
      `SELECT 1
         FROM hala.users u
        WHERE u.id=$1 AND u.is_active=true
          AND (
            EXISTS (
              SELECT 1 FROM hala.user_roles ur
              JOIN hala.roles r ON r.id=ur.role_id
              WHERE ur.user_id=u.id AND lower(r.name)=ANY($2::text[])
            )
            OR EXISTS (
              SELECT 1 FROM hala.user_roles ur
              JOIN hala.role_permissions rp ON rp.role_id=ur.role_id
              JOIN hala.permissions p ON p.id=rp.permission_id
              WHERE ur.user_id=u.id AND p.code='market.builder.manage'
            )
          )
        LIMIT 1`,
      [actorId, ADMIN_ROLES],
    );
    if (rows.length === 0) throw new ForbiddenException('FORBIDDEN_MARKET_BUILDER');
  }

  private async audit(
    runner: QueryRunner,
    input: {
      marketId: string | null;
      actorId: string;
      objectType: string;
      objectId?: string | null;
      action: string;
      requestId?: string;
      before?: unknown;
      after?: unknown;
    },
  ): Promise<void> {
    await runner.query(
      `INSERT INTO hala.market_change_log
        (market_id,actor_user_id,object_type,object_id,action,request_id,before_json,after_json)
       VALUES($1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb)`,
      [
        input.marketId,
        input.actorId,
        input.objectType,
        input.objectId ?? null,
        input.action,
        input.requestId ?? null,
        input.before == null ? null : JSON.stringify(input.before),
        input.after == null ? null : JSON.stringify(input.after),
      ],
    );

    await runner.query(
      `INSERT INTO hala.audit_logs
        (actor_user_id,action,entity_type,entity_id,before_data,after_data,request_id,result,metadata)
       VALUES($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7,'SUCCESS',$8::jsonb)`,
      [
        input.actorId,
        `MARKET_${input.action}`,
        input.objectType,
        input.objectId ?? null,
        input.before == null ? null : JSON.stringify(input.before),
        input.after == null ? null : JSON.stringify(input.after),
        input.requestId ?? null,
        JSON.stringify({ marketId: input.marketId }),
      ],
    );
  }

  private async runTransaction<T>(fn: (runner: QueryRunner) => Promise<T>): Promise<T> {
    const runner = this.dataSource.createQueryRunner();
    await runner.connect();
    await runner.startTransaction();
    try {
      const result = await fn(runner);
      await runner.commitTransaction();
      return result;
    } catch (error) {
      if (runner.isTransactionActive) await runner.rollbackTransaction();
      throw error;
    } finally {
      await runner.release();
    }
  }

  async createMarket(actorId: string | null, dto: CreateMarketDto, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const marketKey = this.normalizeMarketKey(dto.marketKey);

      const duplicate = await runner.query(`SELECT id FROM hala.markets WHERE market_key=$1 LIMIT 1`, [marketKey]);
      if (duplicate.length > 0) throw new ConflictException('MARKET_KEY_EXISTS');

      let template: any = null;
      if (dto.templateMarketId) {
        this.assertUuid(dto.templateMarketId, 'INVALID_TEMPLATE_MARKET_ID');
        const rows = await runner.query(
          `SELECT * FROM hala.markets
            WHERE id=$1 AND status='ACTIVE' AND is_deleted=false
            FOR SHARE`,
          [dto.templateMarketId],
        );
        if (rows.length === 0) throw new ConflictException('TEMPLATE_MARKET_NOT_ACTIVE');
        template = rows[0];
      } else {
        const rows = await runner.query(
          `SELECT * FROM hala.markets
            WHERE is_reference_template=true AND status='ACTIVE' AND is_deleted=false
            ORDER BY updated_at DESC LIMIT 1`,
        );
        template = rows[0] ?? null;
      }

      const configuration = template?.configuration ?? dto.configuration ?? {};
      const complianceProfile = template?.compliance_profile ?? dto.complianceProfile ?? {};
      const createdRows = await runner.query(
        `INSERT INTO hala.markets
          (market_key,name_ar,name_en,description,status,configuration,compliance_profile,sort_order,created_by,updated_by,template_market_id)
         VALUES($1,$2,$3,$4,'DRAFT',$5::jsonb,$6::jsonb,$7,$8,$8,$9)
         RETURNING *`,
        [
          marketKey,
          dto.nameAr.trim(),
          dto.nameEn?.trim() || null,
          dto.description ?? null,
          JSON.stringify(configuration),
          JSON.stringify(complianceProfile),
          dto.sortOrder ?? 0,
          actorId,
          template?.id ?? null,
        ],
      );
      const market = createdRows[0];

      if (template) await this.cloneTemplate(runner, template.id, market.id, actorId);

      await runner.query(
        `INSERT INTO hala.ai_market_bindings
          (market_id,supervisor_id,local_ai_enabled,local_ai_policy,inheritance_mode)
         SELECT $1,id,true,'{}'::jsonb,'INHERIT_AND_RESTRICT'
           FROM hala.ai_supervisor_configs
          WHERE supervisor_key='platform_supervisor'
         ON CONFLICT(market_id) DO NOTHING`,
        [market.id],
      );

      await this.audit(runner, {
        marketId: market.id,
        actorId,
        objectType: 'market',
        objectId: market.id,
        action: 'CREATE',
        requestId: ctx.requestId,
        after: market,
      });

      return market;
    });
  }

  private async cloneTemplate(runner: QueryRunner, templateId: string, marketId: string, actorId: string): Promise<void> {
    const sections = await runner.query(
      `WITH RECURSIVE tree AS (
         SELECT ms.*,0 AS depth FROM hala.market_sections ms WHERE ms.market_id=$1 AND ms.parent_id IS NULL
         UNION ALL
         SELECT ms.*,tree.depth+1
           FROM hala.market_sections ms
           JOIN tree ON tree.id=ms.parent_id
          WHERE ms.market_id=$1
       )
       SELECT * FROM tree ORDER BY depth,sort_order,name_ar`,
      [templateId],
    );
    const sectionMap = new Map<string, string>();
    for (const row of sections) {
      const parentId = row.parent_id ? sectionMap.get(row.parent_id) ?? null : null;
      const inserted = await runner.query(
        `INSERT INTO hala.market_sections
          (market_id,parent_id,section_key,name_ar,name_en,configuration,sort_order,is_active)
         VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,$8) RETURNING id`,
        [marketId, parentId, row.section_key, row.name_ar, row.name_en, JSON.stringify(row.configuration ?? {}), row.sort_order, row.is_active],
      );
      sectionMap.set(row.id, inserted[0].id);
    }

    const categories = await runner.query(
      `WITH RECURSIVE tree AS (
         SELECT c.*,0 AS depth FROM hala.categories c WHERE c.market_id=$1 AND c.parent_id IS NULL
         UNION ALL
         SELECT c.*,tree.depth+1 FROM hala.categories c JOIN tree ON tree.id=c.parent_id WHERE c.market_id=$1
       )
       SELECT * FROM tree ORDER BY depth,sort_order,name_ar`,
      [templateId],
    );
    const categoryMap = new Map<string, string>();
    for (const row of categories) {
      const parentId = row.parent_id ? categoryMap.get(row.parent_id) ?? null : null;
      const inserted = await runner.query(
        `INSERT INTO hala.categories(market_id,parent_id,name_ar,category_kind,sort_order,is_active)
         VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,
        [marketId, parentId, row.name_ar, row.category_kind, row.sort_order, row.is_active],
      );
      categoryMap.set(row.id, inserted[0].id);
    }

    const services = await runner.query(
      `SELECT * FROM hala.services WHERE market_id=$1 ORDER BY created_at,id`,
      [templateId],
    );
    for (const service of services) {
      await runner.query(
        `INSERT INTO hala.services(market_id,category_id,name_ar,description,listing_type,is_active)
         VALUES($1,$2,$3,$4,$5,$6)`,
        [marketId, service.category_id ? categoryMap.get(service.category_id) ?? null : null, service.name_ar, service.description, service.listing_type, service.is_active],
      );
    }

    const attributes = await runner.query(
      `SELECT * FROM hala.listing_attribute_definitions WHERE market_id=$1 AND enabled=true ORDER BY attribute_code,version`,
      [templateId],
    );
    for (const attribute of attributes) {
      await runner.query(
        `INSERT INTO hala.listing_attribute_definitions
          (market_id,section_id,category_id,attribute_code,display_name,data_type,unit_code,required,searchable,filterable,sortable,validation_rules,allowed_values,display_rules,version,enabled)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12::jsonb,$13::jsonb,$14::jsonb,1,true)`,
        [
          marketId,
          attribute.section_id ? sectionMap.get(attribute.section_id) ?? null : null,
          attribute.category_id ? categoryMap.get(attribute.category_id) ?? null : null,
          attribute.attribute_code,
          attribute.display_name,
          attribute.data_type,
          attribute.unit_code,
          attribute.required,
          attribute.searchable,
          attribute.filterable,
          attribute.sortable,
          JSON.stringify(attribute.validation_rules ?? {}),
          JSON.stringify(attribute.allowed_values ?? []),
          JSON.stringify(attribute.display_rules ?? {}),
        ],
      );
    }

    const operations = await runner.query(
      `SELECT DISTINCT ON(operation_code) *
         FROM hala.market_operation_configs
        WHERE market_id=$1
        ORDER BY operation_code,version DESC`,
      [templateId],
    );
    for (const operation of operations) {
      await runner.query(
        `INSERT INTO hala.market_operation_configs
          (market_id,operation_code,enabled,label_ar,label_en,settings,version)
         VALUES($1,$2,$3,$4,$5,$6::jsonb,1)`,
        [marketId, operation.operation_code, operation.enabled, operation.label_ar, operation.label_en, JSON.stringify(operation.settings ?? {})],
      );
    }

    const uiConfigs = await runner.query(
      `SELECT DISTINCT ON(config_key,language_code) *
         FROM hala.market_ui_configs
        WHERE market_id=$1 AND status='PUBLISHED'
        ORDER BY config_key,language_code,version DESC`,
      [templateId],
    );
    for (const ui of uiConfigs) {
      await runner.query(
        `INSERT INTO hala.market_ui_configs
          (market_id,config_key,language_code,config_json,status,version,created_by,published_by,published_at,updated_at)
         VALUES($1,$2,$3,$4::jsonb,'PUBLISHED',1,$5,$5,now(),now())`,
        [marketId, ui.config_key, ui.language_code, JSON.stringify(ui.config_json ?? {}), actorId],
      );
    }

    const policies = await runner.query(
      `SELECT DISTINCT ON(policy_key) *
         FROM hala.market_policy_configs
        WHERE market_id=$1 AND status='APPROVED'
        ORDER BY policy_key,version DESC`,
      [templateId],
    );
    for (const policy of policies) {
      await runner.query(
        `INSERT INTO hala.market_policy_configs
          (market_id,policy_key,policy_json,version,status,created_by,approved_by,approved_at,updated_at)
         VALUES($1,$2,$3::jsonb,1,'APPROVED',$4,$4,now(),now())`,
        [marketId, policy.policy_key, JSON.stringify(policy.policy_json ?? {}), actorId],
      );
    }
  }

  async listMarkets(actorId: string | null) {
    this.requireActor(actorId);
    await this.requireManager(actorId);
    return this.dataSource.query(
      `SELECT * FROM hala.markets WHERE is_deleted=false ORDER BY sort_order,name_ar`,
    );
  }

  async getMarket(actorId: string | null, marketId: string) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    await this.requireManager(actorId);

    const marketRows = await this.dataSource.query(`SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false LIMIT 1`, [marketId]);
    if (marketRows.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');

    const [sections, attributes, operations, uiConfigs, policies, memberships] = await Promise.all([
      this.dataSource.query(`SELECT * FROM hala.market_sections WHERE market_id=$1 ORDER BY sort_order,name_ar`, [marketId]),
      this.dataSource.query(`SELECT * FROM hala.listing_attribute_definitions WHERE market_id=$1 AND enabled=true ORDER BY attribute_code,version DESC`, [marketId]),
      this.dataSource.query(`SELECT * FROM hala.market_operation_configs WHERE market_id=$1 ORDER BY operation_code,version DESC`, [marketId]),
      this.dataSource.query(`SELECT DISTINCT ON(config_key,language_code) * FROM hala.market_ui_configs WHERE market_id=$1 AND status='PUBLISHED' ORDER BY config_key,language_code,version DESC`, [marketId]),
      this.dataSource.query(`SELECT DISTINCT ON(policy_key) * FROM hala.market_policy_configs WHERE market_id=$1 AND status='APPROVED' ORDER BY policy_key,version DESC`, [marketId]),
      this.dataSource.query(`SELECT * FROM hala.market_provider_memberships WHERE market_id=$1 ORDER BY created_at DESC`, [marketId]),
    ]);

    return {
      ...marketRows[0],
      sections,
      attributes,
      operations,
      uiConfigs,
      policies,
      providers: memberships,
    };
  }

  async updateMarket(actorId: string | null, marketId: string, dto: UpdateMarketDto, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false FOR UPDATE`, [marketId]);
      if (rows.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');
      const before = rows[0];
      const afterRows = await runner.query(
        `UPDATE hala.markets
            SET name_ar=$2,
                name_en=$3,
                description=$4,
                configuration=$5::jsonb,
                compliance_profile=$6::jsonb,
                sort_order=$7,
                updated_by=$8,
                version=version+1,
                updated_at=now()
          WHERE id=$1
          RETURNING *`,
        [
          marketId,
          dto.nameAr ?? before.name_ar,
          dto.nameEn ?? before.name_en,
          dto.description ?? before.description,
          JSON.stringify(dto.configuration ?? before.configuration ?? {}),
          JSON.stringify(dto.complianceProfile ?? before.compliance_profile ?? {}),
          dto.sortOrder ?? before.sort_order,
          actorId,
        ],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'market', objectId: marketId, action: 'UPDATE', requestId: ctx.requestId, before, after: afterRows[0] });
      return afterRows[0];
    });
  }

  async setReferenceTemplate(actorId: string | null, marketId: string, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false FOR UPDATE`, [marketId]);
      if (rows.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');
      if (rows[0].status !== 'ACTIVE') throw new ConflictException('REFERENCE_MARKET_MUST_BE_ACTIVE');
      await runner.query(`UPDATE hala.markets SET is_reference_template=false WHERE is_reference_template=true AND id<>$1`, [marketId]);
      const result = await runner.query(
        `UPDATE hala.markets SET is_reference_template=true,updated_by=$2,updated_at=now(),version=version+1 WHERE id=$1 RETURNING *`,
        [marketId, actorId],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'market', objectId: marketId, action: 'UPDATE', requestId: ctx.requestId, before: rows[0], after: result[0] });
      return result[0];
    });
  }

  private async setStatus(actorId: string | null, marketId: string, status: typeof MARKET_STATUSES[number], action: 'ACTIVATE' | 'PAUSE' | 'ARCHIVE', ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false FOR UPDATE`, [marketId]);
      if (rows.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');
      if (status === 'ACTIVE') {
        const enabledOperation = await runner.query(`SELECT 1 FROM hala.market_operation_configs WHERE market_id=$1 AND enabled=true LIMIT 1`, [marketId]);
        if (enabledOperation.length === 0) throw new ConflictException('MARKET_NEEDS_ENABLED_OPERATION');
      }
      const updated = await runner.query(
        `UPDATE hala.markets
            SET status=$2,is_deleted=false,deleted_at=NULL,updated_by=$3,version=version+1,updated_at=now()
          WHERE id=$1 RETURNING *`,
        [marketId, status, actorId],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'market', objectId: marketId, action, requestId: ctx.requestId, before: rows[0], after: updated[0] });
      return updated[0];
    });
  }

  activateMarket(a: string | null, id: string, c: AuthRequestContext) { return this.setStatus(a, id, 'ACTIVE', 'ACTIVATE', c); }
  pauseMarket(a: string | null, id: string, c: AuthRequestContext) { return this.setStatus(a, id, 'PAUSED', 'PAUSE', c); }
  archiveMarket(a: string | null, id: string, c: AuthRequestContext) { return this.setStatus(a, id, 'ARCHIVED', 'ARCHIVE', c); }

  async softDeleteMarket(actorId: string | null, marketId: string, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=false FOR UPDATE`, [marketId]);
      if (rows.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');
      const result = await runner.query(
        `UPDATE hala.markets
            SET is_deleted=true,status='ARCHIVED',deleted_at=now(),updated_by=$2,version=version+1,updated_at=now()
          WHERE id=$1 RETURNING *`,
        [marketId, actorId],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'market', objectId: marketId, action: 'SOFT_DELETE', requestId: ctx.requestId, before: rows[0], after: result[0] });
      return result[0];
    });
  }

  async restoreMarket(actorId: string | null, marketId: string, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.markets WHERE id=$1 AND is_deleted=true FOR UPDATE`, [marketId]);
      if (rows.length === 0) throw new NotFoundException('DELETED_MARKET_NOT_FOUND');
      const result = await runner.query(
        `UPDATE hala.markets SET is_deleted=false,deleted_at=NULL,status='DRAFT',updated_by=$2,version=version+1,updated_at=now() WHERE id=$1 RETURNING *`,
        [marketId, actorId],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'market', objectId: marketId, action: 'RESTORE', requestId: ctx.requestId, before: rows[0], after: result[0] });
      return result[0];
    });
  }

  async upsertOperation(actorId: string | null, marketId: string, dto: UpsertOperationDto, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    if (!(OPERATIONS as readonly string[]).includes(dto.operationCode)) throw new BadRequestException('INVALID_OPERATION_CODE');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const market = await runner.query(`SELECT id FROM hala.markets WHERE id=$1 AND is_deleted=false LIMIT 1`, [marketId]);
      if (market.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');
      const result = await runner.query(
        `INSERT INTO hala.market_operation_configs
          (market_id,operation_code,enabled,label_ar,label_en,settings,version)
         VALUES($1,$2,$3,$4,$5,$6::jsonb,COALESCE((SELECT max(version)+1 FROM hala.market_operation_configs WHERE market_id=$1 AND operation_code=$2),1))
         RETURNING *`,
        [marketId, dto.operationCode, dto.enabled !== false, dto.labelAr ?? null, dto.labelEn ?? null, JSON.stringify(dto.settings ?? {})],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'market_operation_config', objectId: result[0].id, action: 'CREATE', requestId: ctx.requestId, after: result[0] });
      return result[0];
    });
  }

  async createSection(actorId: string | null, marketId: string, dto: CreateSectionDto, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const market = await runner.query(`SELECT id FROM hala.markets WHERE id=$1 AND is_deleted=false`, [marketId]);
      if (market.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');

      if (dto.parentId) {
        this.assertUuid(dto.parentId, 'INVALID_PARENT_SECTION_ID');
        const parent = await runner.query(`SELECT id FROM hala.market_sections WHERE id=$1 AND market_id=$2 LIMIT 1`, [dto.parentId, marketId]);
        if (parent.length === 0) throw new BadRequestException('PARENT_SECTION_OUTSIDE_MARKET');
      }

      const result = await runner.query(
        `INSERT INTO hala.market_sections
          (market_id,parent_id,section_key,name_ar,name_en,configuration,sort_order,is_active)
         VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,$8) RETURNING *`,
        [marketId, dto.parentId ?? null, dto.sectionKey.trim(), dto.nameAr.trim(), dto.nameEn?.trim() ?? null, JSON.stringify(dto.configuration ?? {}), dto.sortOrder ?? 0, dto.isActive !== false],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'market_section', objectId: result[0].id, action: 'CREATE', requestId: ctx.requestId, after: result[0] });
      return result[0];
    });
  }

  async createAttribute(actorId: string | null, marketId: string, dto: CreateAttributeDto, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const market = await runner.query(`SELECT id FROM hala.markets WHERE id=$1 AND is_deleted=false`, [marketId]);
      if (market.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');

      if (dto.sectionId) {
        this.assertUuid(dto.sectionId, 'INVALID_SECTION_ID');
        const section = await runner.query(`SELECT id FROM hala.market_sections WHERE id=$1 AND market_id=$2 LIMIT 1`, [dto.sectionId, marketId]);
        if (section.length === 0) throw new BadRequestException('SECTION_OUTSIDE_MARKET');
      }
      if (dto.categoryId) {
        this.assertUuid(dto.categoryId, 'INVALID_CATEGORY_ID');
        const category = await runner.query(`SELECT id FROM hala.categories WHERE id=$1 AND market_id=$2 LIMIT 1`, [dto.categoryId, marketId]);
        if (category.length === 0) throw new BadRequestException('CATEGORY_OUTSIDE_MARKET');
      }

      const result = await runner.query(
        `INSERT INTO hala.listing_attribute_definitions
          (market_id,section_id,category_id,attribute_code,display_name,data_type,unit_code,required,searchable,filterable,sortable,validation_rules,allowed_values,display_rules,version,enabled)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12::jsonb,$13::jsonb,$14::jsonb,
          COALESCE((SELECT max(version)+1 FROM hala.listing_attribute_definitions WHERE market_id=$1 AND section_id IS NOT DISTINCT FROM $2 AND category_id IS NOT DISTINCT FROM $3 AND attribute_code=$4),1),true)
         RETURNING *`,
        [
          marketId,
          dto.sectionId ?? null,
          dto.categoryId ?? null,
          dto.attributeCode.trim(),
          dto.displayName.trim(),
          dto.dataType.trim(),
          dto.unitCode ?? null,
          dto.required === true,
          dto.searchable === true,
          dto.filterable === true,
          dto.sortable === true,
          JSON.stringify(dto.validationRules ?? {}),
          JSON.stringify(dto.allowedValues ?? []),
          JSON.stringify(dto.displayRules ?? {}),
        ],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'listing_attribute_definition', objectId: result[0].id, action: 'CREATE', requestId: ctx.requestId, after: result[0] });
      return result[0];
    });
  }

  async updateSection(actorId: string | null, sectionId: string, dto: UpdateSectionDto, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(sectionId, 'INVALID_SECTION_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.market_sections WHERE id=$1 FOR UPDATE`, [sectionId]);
      if (rows.length === 0) throw new NotFoundException('SECTION_NOT_FOUND');
      const before = rows[0];
      const result = await runner.query(
        `UPDATE hala.market_sections
            SET name_ar=COALESCE($2,name_ar),
                name_en=COALESCE($3,name_en),
                configuration=COALESCE($4::jsonb,configuration),
                sort_order=COALESCE($5,sort_order),
                is_active=COALESCE($6,is_active)
          WHERE id=$1 RETURNING *`,
        [
          sectionId,
          dto.nameAr ?? null,
          dto.nameEn ?? null,
          dto.configuration ? JSON.stringify(dto.configuration) : null,
          dto.sortOrder ?? null,
          dto.isActive ?? null,
        ],
      );
      await this.audit(runner, { marketId: result[0].market_id, actorId, objectType: 'market_section', objectId: sectionId, action: 'UPDATE', requestId: ctx.requestId, before, after: result[0] });
      return result[0];
    });
  }

  archiveSection(actorId: string | null, sectionId: string, ctx: AuthRequestContext) {
    return this.updateSection(actorId, sectionId, { isActive: false }, ctx);
  }

  async updateAttribute(actorId: string | null, attributeId: string, dto: UpdateAttributeDto, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(attributeId, 'INVALID_ATTRIBUTE_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.listing_attribute_definitions WHERE id=$1 FOR UPDATE`, [attributeId]);
      if (rows.length === 0) throw new NotFoundException('ATTRIBUTE_NOT_FOUND');
      const before = rows[0];
      const result = await runner.query(
        `UPDATE hala.listing_attribute_definitions
            SET display_name=COALESCE($2,display_name),
                data_type=COALESCE($3,data_type),
                unit_code=COALESCE($4,unit_code),
                required=COALESCE($5,required),
                searchable=COALESCE($6,searchable),
                filterable=COALESCE($7,filterable),
                sortable=COALESCE($8,sortable),
                validation_rules=COALESCE($9::jsonb,validation_rules),
                allowed_values=COALESCE($10::jsonb,allowed_values),
                display_rules=COALESCE($11::jsonb,display_rules),
                enabled=COALESCE($12,enabled),
                version=version+1
          WHERE id=$1 RETURNING *`,
        [
          attributeId,
          dto.displayName ?? null,
          dto.dataType ?? null,
          dto.unitCode ?? null,
          dto.required ?? null,
          dto.searchable ?? null,
          dto.filterable ?? null,
          dto.sortable ?? null,
          dto.validationRules ? JSON.stringify(dto.validationRules) : null,
          dto.allowedValues ? JSON.stringify(dto.allowedValues) : null,
          dto.displayRules ? JSON.stringify(dto.displayRules) : null,
          dto.enabled ?? null,
        ],
      );
      await this.audit(runner, { marketId: result[0].market_id, actorId, objectType: 'listing_attribute_definition', objectId: attributeId, action: 'UPDATE', requestId: ctx.requestId, before, after: result[0] });
      return result[0];
    });
  }

  archiveAttribute(actorId: string | null, attributeId: string, ctx: AuthRequestContext) {
    return this.updateAttribute(actorId, attributeId, { enabled: false }, ctx);
  }

  async createUiConfig(actorId: string | null, marketId: string, dto: CreateUiConfigDto, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const market = await runner.query(`SELECT id FROM hala.markets WHERE id=$1 AND is_deleted=false`, [marketId]);
      if (market.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');
      const result = await runner.query(
        `INSERT INTO hala.market_ui_configs
          (market_id,config_key,language_code,config_json,version,status,created_by)
         VALUES($1,$2,$3,$4::jsonb,COALESCE((SELECT max(version)+1 FROM hala.market_ui_configs WHERE market_id=$1 AND config_key=$2 AND language_code=$3),1),'DRAFT',$5)
         RETURNING *`,
        [marketId, dto.configKey.trim(), dto.languageCode ?? 'ar', JSON.stringify(dto.configJson), actorId],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'market_ui_config', objectId: result[0].id, action: 'CREATE', requestId: ctx.requestId, after: result[0] });
      return result[0];
    });
  }

  async updateUiConfig(actorId: string | null, configId: string, dto: UpdateUiConfigDto, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(configId, 'INVALID_UI_CONFIG_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.market_ui_configs WHERE id=$1 FOR UPDATE`, [configId]);
      if (rows.length === 0) throw new NotFoundException('UI_CONFIG_NOT_FOUND');
      const before = rows[0];
      const result = await runner.query(
        `UPDATE hala.market_ui_configs SET config_json=$2::jsonb,version=version+1,status='DRAFT',updated_at=now() WHERE id=$1 RETURNING *`,
        [configId, JSON.stringify(dto.configJson)],
      );
      await this.audit(runner, { marketId: result[0].market_id, actorId, objectType: 'market_ui_config', objectId: configId, action: 'UPDATE', requestId: ctx.requestId, before, after: result[0] });
      return result[0];
    });
  }

  archiveUiConfig(actorId: string | null, configId: string, ctx: AuthRequestContext) {
    return this.updateUiConfigArchive(actorId, configId, ctx);
  }

  private async updateUiConfigArchive(actorId: string | null, configId: string, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(configId, 'INVALID_UI_CONFIG_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.market_ui_configs WHERE id=$1 FOR UPDATE`, [configId]);
      if (rows.length === 0) throw new NotFoundException('UI_CONFIG_NOT_FOUND');
      const result = await runner.query(`UPDATE hala.market_ui_configs SET status='ARCHIVED',updated_at=now() WHERE id=$1 RETURNING *`, [configId]);
      await this.audit(runner, { marketId: result[0].market_id, actorId, objectType: 'market_ui_config', objectId: configId, action: 'UPDATE', requestId: ctx.requestId, before: rows[0], after: result[0] });
      return result[0];
    });
  }

  async publishUiConfig(actorId: string | null, configId: string, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(configId, 'INVALID_UI_CONFIG_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.market_ui_configs WHERE id=$1 FOR UPDATE`, [configId]);
      if (rows.length === 0) throw new NotFoundException('UI_CONFIG_NOT_FOUND');
      if (rows[0].status === 'ARCHIVED') throw new ConflictException('ARCHIVED_UI_CONFIG_NOT_PUBLISHABLE');
      const result = await runner.query(
        `UPDATE hala.market_ui_configs SET status='PUBLISHED',published_by=$2,published_at=now(),updated_at=now() WHERE id=$1 RETURNING *`,
        [configId, actorId],
      );
      await this.audit(runner, { marketId: result[0].market_id, actorId, objectType: 'market_ui_config', objectId: configId, action: 'UPDATE', requestId: ctx.requestId, before: rows[0], after: result[0] });
      return result[0];
    });
  }

  async addProvider(actorId: string | null, marketId: string, providerId: string, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(marketId, 'INVALID_MARKET_ID');
    this.assertUuid(providerId, 'INVALID_PROVIDER_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const market = await runner.query(`SELECT id FROM hala.markets WHERE id=$1 AND is_deleted=false`, [marketId]);
      if (market.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');
      const provider = await runner.query(`SELECT id FROM hala.providers WHERE id=$1 LIMIT 1`, [providerId]);
      if (provider.length === 0) throw new NotFoundException('PROVIDER_NOT_FOUND');
      const result = await runner.query(
        `INSERT INTO hala.market_provider_memberships(market_id,provider_id,status,joined_at)
         VALUES($1,$2,'ACTIVE',now())
         ON CONFLICT(market_id,provider_id)
         DO UPDATE SET status='ACTIVE',joined_at=COALESCE(hala.market_provider_memberships.joined_at,now()),suspended_at=NULL,updated_at=now()
         RETURNING *`,
        [marketId, providerId],
      );
      await this.audit(runner, { marketId, actorId, objectType: 'market_provider_membership', objectId: result[0].id, action: 'CREATE', requestId: ctx.requestId, after: result[0] });
      return result[0];
    });
  }

  async suspendProvider(actorId: string | null, membershipId: string, ctx: AuthRequestContext) {
    this.requireActor(actorId);
    this.assertUuid(membershipId, 'INVALID_MEMBERSHIP_ID');
    return this.runTransaction(async (runner) => {
      await this.requireManager(actorId, runner);
      const rows = await runner.query(`SELECT * FROM hala.market_provider_memberships WHERE id=$1 FOR UPDATE`, [membershipId]);
      if (rows.length === 0) throw new NotFoundException('MEMBERSHIP_NOT_FOUND');
      const result = await runner.query(`UPDATE hala.market_provider_memberships SET status='SUSPENDED',suspended_at=now(),updated_at=now() WHERE id=$1 RETURNING *`, [membershipId]);
      await this.audit(runner, { marketId: result[0].market_id, actorId, objectType: 'market_provider_membership', objectId: membershipId, action: 'UPDATE', requestId: ctx.requestId, before: rows[0], after: result[0] });
      return result[0];
    });
  }

  async getPublicMarketConfig(marketKey: string) {
    const key = this.normalizeMarketKey(marketKey);
    const markets = await this.dataSource.query(
      `SELECT id,market_key,name_ar,name_en,description,configuration,compliance_profile,sort_order,status
         FROM hala.markets
        WHERE market_key=$1 AND status='ACTIVE' AND is_deleted=false
        LIMIT 1`,
      [key],
    );
    if (markets.length === 0) throw new NotFoundException('MARKET_NOT_FOUND');
    const market = markets[0];

    const [sections, operations, ui, attributes] = await Promise.all([
      this.dataSource.query(`SELECT id,parent_id,section_key,name_ar,name_en,configuration,sort_order FROM hala.market_sections WHERE market_id=$1 AND is_active=true ORDER BY sort_order,name_ar`, [market.id]),
      this.dataSource.query(`SELECT DISTINCT ON(operation_code) operation_code,enabled,label_ar,label_en,settings,version FROM hala.market_operation_configs WHERE market_id=$1 ORDER BY operation_code,version DESC`, [market.id]),
      this.dataSource.query(`SELECT DISTINCT ON(config_key,language_code) config_key,language_code,config_json,version FROM hala.market_ui_configs WHERE market_id=$1 AND status='PUBLISHED' ORDER BY config_key,language_code,version DESC`, [market.id]),
      this.dataSource.query(`SELECT id,section_id,category_id,attribute_code,display_name,data_type,unit_code,required,searchable,filterable,sortable,validation_rules,allowed_values,display_rules,version FROM hala.listing_attribute_definitions WHERE market_id=$1 AND enabled=true ORDER BY attribute_code,version DESC`, [market.id]),
    ]);

    return { ...market, sections, operations, ui, attributes };
  }
}
