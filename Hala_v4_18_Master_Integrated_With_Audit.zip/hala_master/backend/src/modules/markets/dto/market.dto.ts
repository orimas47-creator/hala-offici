import { IsBoolean, IsIn, IsInt, IsJSON, IsObject, IsOptional, IsString, IsUUID, Length, Matches, Min } from 'class-validator';

export class CreateMarketDto {
  @IsString()
  @Length(2, 120)
  @Matches(/^[A-Za-z0-9][A-Za-z0-9 _-]*$/)
  marketKey!: string;

  @IsString()
  @Length(2, 250)
  nameAr!: string;

  @IsOptional()
  @IsString()
  @Length(2, 250)
  nameEn?: string;

  @IsOptional()
  @IsString()
  @Length(0, 5000)
  description?: string;

  @IsOptional()
  @IsObject()
  configuration?: Record<string, unknown>;

  @IsOptional()
  @IsObject()
  complianceProfile?: Record<string, unknown>;

  @IsOptional()
  @IsInt()
  sortOrder?: number;

  @IsOptional()
  @IsUUID()
  templateMarketId?: string;
}

export class UpdateMarketDto {
  @IsOptional()
  @IsString()
  @Length(2, 250)
  nameAr?: string;

  @IsOptional()
  @IsString()
  @Length(2, 250)
  nameEn?: string;

  @IsOptional()
  @IsString()
  @Length(0, 5000)
  description?: string;

  @IsOptional()
  @IsObject()
  configuration?: Record<string, unknown>;

  @IsOptional()
  @IsObject()
  complianceProfile?: Record<string, unknown>;

  @IsOptional()
  @IsInt()
  sortOrder?: number;
}

export class CreateSectionDto {
  @IsString()
  @Length(2, 160)
  @Matches(/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/)
  sectionKey!: string;

  @IsString()
  @Length(2, 250)
  nameAr!: string;

  @IsOptional()
  @IsString()
  @Length(2, 250)
  nameEn?: string;

  @IsOptional()
  @IsUUID()
  parentId?: string;

  @IsOptional()
  @IsObject()
  configuration?: Record<string, unknown>;

  @IsOptional()
  @IsInt()
  sortOrder?: number;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class UpdateSectionDto {
  @IsOptional()
  @IsString()
  @Length(2, 250)
  nameAr?: string;

  @IsOptional()
  @IsString()
  @Length(2, 250)
  nameEn?: string;

  @IsOptional()
  @IsObject()
  configuration?: Record<string, unknown>;

  @IsOptional()
  @IsInt()
  sortOrder?: number;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class UpsertOperationDto {
  @IsIn(['BUY', 'RENT', 'BUY_OR_RENT', 'SERVICE', 'QUOTE'])
  operationCode!: string;

  @IsOptional()
  @IsBoolean()
  enabled?: boolean;

  @IsOptional()
  @IsString()
  @Length(1, 160)
  labelAr?: string;

  @IsOptional()
  @IsString()
  @Length(1, 160)
  labelEn?: string;

  @IsOptional()
  @IsObject()
  settings?: Record<string, unknown>;
}

export class CreateAttributeDto {
  @IsOptional()
  @IsUUID()
  sectionId?: string;

  @IsOptional()
  @IsUUID()
  categoryId?: string;

  @IsString()
  @Length(2, 160)
  @Matches(/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/)
  attributeCode!: string;

  @IsString()
  @Length(2, 300)
  displayName!: string;

  @IsString()
  @Length(1, 40)
  dataType!: string;

  @IsOptional()
  @IsString()
  @Length(1, 40)
  unitCode?: string;

  @IsOptional()
  @IsBoolean()
  required?: boolean;

  @IsOptional()
  @IsBoolean()
  searchable?: boolean;

  @IsOptional()
  @IsBoolean()
  filterable?: boolean;

  @IsOptional()
  @IsBoolean()
  sortable?: boolean;

  @IsOptional()
  @IsObject()
  validationRules?: Record<string, unknown>;

  @IsOptional()
  allowedValues?: unknown[];

  @IsOptional()
  @IsObject()
  displayRules?: Record<string, unknown>;
}

export class UpdateAttributeDto {
  @IsOptional()
  @IsString()
  @Length(2, 300)
  displayName?: string;

  @IsOptional()
  @IsString()
  @Length(1, 40)
  dataType?: string;

  @IsOptional()
  @IsString()
  @Length(1, 40)
  unitCode?: string;

  @IsOptional()
  @IsBoolean()
  required?: boolean;

  @IsOptional()
  @IsBoolean()
  searchable?: boolean;

  @IsOptional()
  @IsBoolean()
  filterable?: boolean;

  @IsOptional()
  @IsBoolean()
  sortable?: boolean;

  @IsOptional()
  @IsObject()
  validationRules?: Record<string, unknown>;

  @IsOptional()
  allowedValues?: unknown[];

  @IsOptional()
  @IsObject()
  displayRules?: Record<string, unknown>;

  @IsOptional()
  @IsBoolean()
  enabled?: boolean;
}

export class CreateUiConfigDto {
  @IsString()
  @Length(1, 160)
  @Matches(/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/)
  configKey!: string;

  @IsOptional()
  @IsString()
  @Length(2, 16)
  languageCode?: string;

  @IsObject()
  configJson!: Record<string, unknown>;
}

export class UpdateUiConfigDto {
  @IsObject()
  configJson!: Record<string, unknown>;
}

export class AddMarketProviderDto {
  @IsUUID()
  providerId!: string;
}
