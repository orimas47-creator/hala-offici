import { IsObject, IsOptional, IsString, IsUUID, Length } from 'class-validator';

export class CreateProviderApplicationDto {
  @IsOptional()
  @IsUUID()
  marketId?: string;

  @IsOptional()
  @IsString()
  @Length(2, 200)
  businessName?: string;

  @IsOptional()
  @IsObject()
  applicationData?: Record<string, unknown>;
}

export class ReviewProviderApplicationDto {
  @IsOptional()
  insuranceConfirmed?: boolean;

  @IsOptional()
  @IsString()
  @Length(0, 1000)
  reason?: string;
}
