import { IsUUID } from 'class-validator';

export class ProviderApplicationIdDto {
  @IsUUID()
  id!: string;
}
