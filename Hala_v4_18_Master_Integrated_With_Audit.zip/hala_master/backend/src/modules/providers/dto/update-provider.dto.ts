import { IsBoolean, IsDateString, IsIn, IsOptional, IsString, IsUUID, Length } from 'class-validator';

export class UpdateProviderDto {
  @IsOptional()
  @IsString()
  @Length(2, 200)
  businessName?: string;

  @IsOptional()
  @IsDateString()
  subscriptionStartedAt?: string;

  @IsOptional()
  @IsDateString()
  subscriptionExpiresAt?: string;

  @IsOptional()
  @IsBoolean()
  insuranceConfirmed?: boolean;

  @IsOptional()
  @IsIn(['pending', 'active', 'suspended', 'closed'])
  status?: string;
}
