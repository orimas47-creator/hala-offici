import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ActorContext } from '../../common/decorators/actor.decorator.js';
import { HalaAuthGuard, RequireActorGuard } from '../../common/guards/hala-auth.guard.js';
import type { AuthRequestContext } from '../auth/auth.types.js';
import { CreateProviderApplicationDto, ReviewProviderApplicationDto } from './dto/provider-application.dto.js';
import { UpdateProviderDto } from './dto/update-provider.dto.js';
import { ProvidersService } from './providers.service.js';

@Controller('api/v1')
@UseGuards(HalaAuthGuard, RequireActorGuard)
export class ProvidersController {
  constructor(private readonly providers: ProvidersService) {}

  @Post('provider-applications')
  createApplication(
    @Body() dto: CreateProviderApplicationDto,
    @ActorContext() ctx: AuthRequestContext,
  ) {
    return this.providers.createApplication(ctx.actorId, dto);
  }

  @Get('admin/provider-applications')
  listApplications(
    @Query('status') status: string | undefined,
    @ActorContext() ctx: AuthRequestContext,
  ) {
    return this.providers.listApplications(ctx.actorId, status);
  }

  @Post('admin/provider-applications/:id/approve')
  approveApplication(
    @Param('id') id: string,
    @Body() dto: ReviewProviderApplicationDto,
    @ActorContext() ctx: AuthRequestContext,
  ) {
    return this.providers.approveApplication(ctx.actorId, id, dto);
  }

  @Post('admin/provider-applications/:id/reject')
  rejectApplication(
    @Param('id') id: string,
    @Body() dto: ReviewProviderApplicationDto,
    @ActorContext() ctx: AuthRequestContext,
  ) {
    return this.providers.rejectApplication(ctx.actorId, id, dto.reason);
  }

  @Get('providers/:id')
  getProvider(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.providers.getProvider(ctx.actorId, id);
  }

  @Patch('providers/:id')
  updateProvider(
    @Param('id') id: string,
    @Body() dto: UpdateProviderDto,
    @ActorContext() ctx: AuthRequestContext,
  ) {
    return this.providers.updateProvider(ctx.actorId, id, dto);
  }
}
