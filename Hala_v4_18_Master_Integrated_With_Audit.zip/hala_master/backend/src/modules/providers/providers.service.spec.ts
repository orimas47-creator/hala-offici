import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { ProvidersService } from './providers.service.js';

describe('ProvidersService', () => {
  function makeDb(queryImpl: (sql: string, params: unknown[]) => Promise<any[]>) {
    return { query: jest.fn(queryImpl) } as any;
  }

  it('requires a valid provider UUID before querying', async () => {
    const db = makeDb(async () => []);
    const service = new ProvidersService(db);
    await expect(service.getProvider('user-1', 'bad-id')).rejects.toBeInstanceOf(BadRequestException);
    expect(db.query).not.toHaveBeenCalled();
  });

  it('rejects a provider owner mismatch without staff role', async () => {
    const db = makeDb(async (sql) => {
      if (sql.includes('FROM hala.providers')) return [{ id: 'provider-1', user_id: 'owner-1' }];
      if (sql.includes('FROM hala.user_roles')) return [];
      return [];
    });
    const service = new ProvidersService(db);
    await expect(service.getProvider('other-user', '123e4567-e89b-12d3-a456-426614174000'))
      .rejects.toBeInstanceOf(ForbiddenException);
  });

  it('returns not found when provider does not exist', async () => {
    const db = makeDb(async (sql) => {
      if (sql.includes('FROM hala.providers')) return [];
      return [];
    });
    const service = new ProvidersService(db);
    await expect(service.getProvider('user-1', '123e4567-e89b-12d3-a456-426614174000'))
      .rejects.toBeInstanceOf(NotFoundException);
  });
});
