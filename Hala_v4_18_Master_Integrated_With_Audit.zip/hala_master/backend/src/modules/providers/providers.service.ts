import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { DataSource, QueryRunner } from 'typeorm';
import type { AuthRequestContext } from '../auth/auth.types.js';
import { CreateProviderApplicationDto, ReviewProviderApplicationDto } from './dto/provider-application.dto.js';
import { UpdateProviderDto } from './dto/update-provider.dto.js';

const UUID_RX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ADMIN_ROLES = ['admin', 'super_admin', 'administrator'];
const STAFF_PROVIDER_ROLES = [...ADMIN_ROLES, 'agent'];

@Injectable()
export class ProvidersService {
  constructor(private readonly dataSource: DataSource) {}

  private requireActor(actorId: string | null): asserts actorId is string {
    if (!actorId) throw new UnauthorizedException('ACTOR_REQUIRED');
  }

  private assertUuid(value: string, code: string): void {
    if (!UUID_RX.test(String(value ?? ''))) throw new BadRequestException(code);
  }

  private async hasAnyRole(actorId: string, roles: string[], runner?: QueryRunner): Promise<boolean> {
    const executor = runner?.query.bind(runner) ?? this.dataSource.query.bind(this.dataSource);
    const rows = await executor(
      `SELECT 1
         FROM hala.user_roles ur
         JOIN hala.roles r ON r.id=ur.role_id
        WHERE ur.user_id=$1
          AND lower(r.name)=ANY($2::text[])
        LIMIT 1`,
      [actorId, roles.map((role) => role.toLowerCase())],
    );
    return rows.length > 0;
  }

  private async requireAdmin(actorId: string, runner?: QueryRunner): Promise<void> {
    if (!(await this.hasAnyRole(actorId, ADMIN_ROLES, runner))) {
      throw new ForbiddenException('FORBIDDEN');
    }
  }

  private async ensureActiveUser(executor: DataSource | QueryRunner, userId: string): Promise<void> {
    const rows = await executor.query(
      `SELECT id FROM hala.users WHERE id=$1 AND is_active=true LIMIT 1`,
      [userId],
    );
    if (rows.length === 0) throw new NotFoundException('USER_NOT_FOUND');
  }

  async getProvider(actorId: string | null, providerId: string) {
    this.requireActor(actorId);
    this.assertUuid(providerId, 'INVALID_PROVIDER_ID');

    const rows = await this.dataSource.query(
      `SELECT p.*,u.phone,u.full_name
         FROM hala.providers p
         JOIN hala.users u ON u.id=p.user_id
        WHERE p.id=$1
        LIMIT 1`,
      [providerId],
    );
    if (rows.length === 0) throw new NotFoundException('PROVIDER_NOT_FOUND');

    const provider = rows[0];
    const own = String(provider.user_id) === actorId;
    const staff = await this.hasAnyRole(actorId, STAFF_PROVIDER_ROLES);
    if (!own && !staff) throw new ForbiddenException('FORBIDDEN');

    return provider;
  }

  async createApplication(actorId: string | null, dto: CreateProviderApplicationDto) {
    this.requireActor(actorId);
    const marketId = dto.marketId ?? null;
    if (marketId) this.assertUuid(marketId, 'INVALID_MARKET_ID');

    const runner = this.dataSource.createQueryRunner();
    await runner.connect();
    await runner.startTransaction();
    try {
      await this.ensureActiveUser(runner, actorId);

      const existing = await runner.query(
        `SELECT id,status
           FROM hala.provider_applications
          WHERE user_id=$1
            AND status IN ('PENDING','UNDER_REVIEW')
          ORDER BY created_at DESC
          LIMIT 1`,
        [actorId],
      );
      if (existing.length > 0) {
        await runner.commitTransaction();
        return existing[0];
      }

      if (marketId) {
        const market = await runner.query(
          `SELECT id
             FROM hala.markets
            WHERE id=$1 AND status='ACTIVE' AND is_deleted=false
            LIMIT 1`,
          [marketId],
        );
        if (market.length === 0) throw new BadRequestException('MARKET_NOT_ACTIVE');
      }

      const businessName = dto.businessName?.trim() || null;
      const applicationData = dto.applicationData ?? {};
      const rows = await runner.query(
        `INSERT INTO hala.provider_applications
          (user_id,market_id,business_name,application_data,status)
         VALUES($1,$2,$3,$4::jsonb,'PENDING')
         RETURNING *`,
        [actorId, marketId, businessName, JSON.stringify(applicationData)],
      );

      await runner.query(
        `INSERT INTO hala.audit_logs
          (actor_user_id,action,entity_type,entity_id,after_data,result)
         VALUES($1,'PROVIDER_APPLICATION_CREATED','provider_application',$2,$3::jsonb,'SUCCESS')`,
        [actorId, rows[0].id, JSON.stringify({ marketId, businessName })],
      );

      await runner.commitTransaction();
      return rows[0];
    } catch (error) {
      if (runner.isTransactionActive) await runner.rollbackTransaction();
      throw error;
    } finally {
      await runner.release();
    }
  }

  async listApplications(actorId: string | null, status?: string | null) {
    this.requireActor(actorId);
    await this.requireAdmin(actorId);
    const normalized = status ? String(status).toUpperCase() : null;

    return this.dataSource.query(
      `SELECT pa.*,u.phone,u.full_name,m.name_ar AS market_name
         FROM hala.provider_applications pa
         JOIN hala.users u ON u.id=pa.user_id
         LEFT JOIN hala.markets m ON m.id=pa.market_id
        WHERE ($1::text IS NULL OR pa.status=$1)
        ORDER BY pa.created_at DESC
        LIMIT 200`,
      [normalized],
    );
  }

  async approveApplication(
    actorId: string | null,
    applicationId: string,
    dto: ReviewProviderApplicationDto,
  ) {
    this.requireActor(actorId);
    this.assertUuid(applicationId, 'INVALID_APPLICATION_ID');

    const runner = this.dataSource.createQueryRunner();
    await runner.connect();
    await runner.startTransaction();
    try {
      await this.requireAdmin(actorId, runner);

      const rows = await runner.query(
        `SELECT * FROM hala.provider_applications WHERE id=$1 FOR UPDATE`,
        [applicationId],
      );
      if (rows.length === 0) throw new NotFoundException('APPLICATION_NOT_FOUND');
      const application = rows[0];
      if (application.status === 'APPROVED') {
        throw new BadRequestException('APPLICATION_ALREADY_APPROVED');
      }
      if (['REJECTED', 'CANCELLED'].includes(String(application.status))) {
        throw new BadRequestException('APPLICATION_NOT_APPROVABLE');
      }

      const existing = await runner.query(
        `SELECT * FROM hala.providers WHERE user_id=$1 FOR UPDATE`,
        [application.user_id],
      );

      let provider: any;
      const insuranceConfirmed = dto.insuranceConfirmed === true;
      if (existing.length > 0) {
        provider = existing[0];
        await runner.query(
          `UPDATE hala.providers
              SET business_name=COALESCE($2,business_name),
                  status='active',
                  insurance_confirmed=$3,
                  updated_at=now()
            WHERE id=$1`,
          [provider.id, application.business_name || null, insuranceConfirmed],
        );
      } else {
        const created = await runner.query(
          `INSERT INTO hala.providers(user_id,business_name,status,insurance_confirmed)
           VALUES($1,$2,'active',$3)
           RETURNING *`,
          [application.user_id, application.business_name || null, insuranceConfirmed],
        );
        provider = created[0];
      }

      if (application.market_id) {
        await runner.query(
          `INSERT INTO hala.market_provider_memberships(market_id,provider_id,status)
           VALUES($1,$2,'ACTIVE')
           ON CONFLICT(market_id,provider_id)
           DO UPDATE SET status='ACTIVE',updated_at=now()`,
          [application.market_id, provider.id],
        );
      }

      await runner.query(
        `UPDATE hala.provider_applications
            SET status='APPROVED',reviewed_by=$2,reviewed_at=now(),provider_id=$3
          WHERE id=$1`,
        [applicationId, actorId, provider.id],
      );

      await runner.query(
        `INSERT INTO hala.audit_logs
          (actor_user_id,action,entity_type,entity_id,after_data,result)
         VALUES($1,'PROVIDER_APPLICATION_APPROVED','provider_application',$2,$3::jsonb,'SUCCESS')`,
        [actorId, applicationId, JSON.stringify({ providerId: provider.id, marketId: application.market_id })],
      );

      await runner.commitTransaction();
      return provider;
    } catch (error) {
      if (runner.isTransactionActive) await runner.rollbackTransaction();
      throw error;
    } finally {
      await runner.release();
    }
  }

  async rejectApplication(actorId: string | null, applicationId: string, reason?: string) {
    this.requireActor(actorId);
    this.assertUuid(applicationId, 'INVALID_APPLICATION_ID');
    const runner = this.dataSource.createQueryRunner();
    await runner.connect();
    await runner.startTransaction();
    try {
      await this.requireAdmin(actorId, runner);
      const result = await runner.query(
        `UPDATE hala.provider_applications
            SET status='REJECTED',reviewed_by=$2,reviewed_at=now(),review_reason=$3
          WHERE id=$1 AND status IN ('PENDING','UNDER_REVIEW')
          RETURNING *`,
        [applicationId, actorId, reason?.trim() || null],
      );
      if (result.length === 0) throw new BadRequestException('APPLICATION_NOT_REJECTABLE');
      await runner.query(
        `INSERT INTO hala.audit_logs
          (actor_user_id,action,entity_type,entity_id,after_data,result)
         VALUES($1,'PROVIDER_APPLICATION_REJECTED','provider_application',$2,$3::jsonb,'SUCCESS')`,
        [actorId, applicationId, JSON.stringify({ reason: reason?.trim() || null })],
      );
      await runner.commitTransaction();
      return result[0];
    } catch (error) {
      if (runner.isTransactionActive) await runner.rollbackTransaction();
      throw error;
    } finally {
      await runner.release();
    }
  }

  async updateProvider(actorId: string | null, providerId: string, dto: UpdateProviderDto) {
    this.requireActor(actorId);
    this.assertUuid(providerId, 'INVALID_PROVIDER_ID');

    const runner = this.dataSource.createQueryRunner();
    await runner.connect();
    await runner.startTransaction();
    try {
      const currentRows = await runner.query(
        `SELECT * FROM hala.providers WHERE id=$1 FOR UPDATE`,
        [providerId],
      );
      if (currentRows.length === 0) throw new NotFoundException('PROVIDER_NOT_FOUND');
      const current = currentRows[0];
      const own = String(current.user_id) === actorId;
      if (!own) await this.requireAdmin(actorId, runner);

      const restricted =
        dto.subscriptionStartedAt !== undefined ||
        dto.subscriptionExpiresAt !== undefined ||
        dto.insuranceConfirmed !== undefined ||
        dto.status !== undefined;
      if (restricted) await this.requireAdmin(actorId, runner);

      const rows = await runner.query(
        `UPDATE hala.providers
            SET business_name=COALESCE($2,business_name),
                subscription_started_at=COALESCE($3::timestamptz,subscription_started_at),
                subscription_expires_at=COALESCE($4::timestamptz,subscription_expires_at),
                insurance_confirmed=COALESCE($5::boolean,insurance_confirmed),
                status=COALESCE($6,status),
                updated_at=now()
          WHERE id=$1
          RETURNING *`,
        [
          providerId,
          dto.businessName === undefined ? null : dto.businessName.trim() || null,
          dto.subscriptionStartedAt ?? null,
          dto.subscriptionExpiresAt ?? null,
          dto.insuranceConfirmed === undefined ? null : dto.insuranceConfirmed,
          dto.status ?? null,
        ],
      );

      await runner.query(
        `INSERT INTO hala.audit_logs
          (actor_user_id,action,entity_type,entity_id,before_data,after_data,result)
         VALUES($1,'PROVIDER_UPDATED','provider',$2,$3::jsonb,$4::jsonb,'SUCCESS')`,
        [actorId, providerId, JSON.stringify(current), JSON.stringify(rows[0])],
      );

      await runner.commitTransaction();
      return rows[0];
    } catch (error) {
      if (runner.isTransactionActive) await runner.rollbackTransaction();
      throw error;
    } finally {
      await runner.release();
    }
  }
}
