# ProvidersModule — Hala v4.18

وحدة NestJS الفعلية لإدارة طلبات الانتساب والمنتسبين، مع الحفاظ على المسارات القديمة في v4.17.

## المسارات
- `POST /api/v1/provider-applications`
- `GET /api/v1/admin/provider-applications`
- `POST /api/v1/admin/provider-applications/:id/approve`
- `POST /api/v1/admin/provider-applications/:id/reject`
- `GET /api/v1/providers/:id`
- `PATCH /api/v1/providers/:id`

## قواعد الحماية
- كل المسارات تتطلب جلسة Auth صالحة.
- فحص الإدارة يتم داخل Domain Service، وليس من الواجهة.
- العميل/المنتسب يعدل اسمه التجاري فقط في ملفه؛ تغييرات الاشتراك والتأمين والحالة إدارية.
- الموافقة والرفض والتعديل تسجل Audit Log.
- عمليات الإنشاء/الموافقة/الرفض/التعديل تستخدم معاملات PostgreSQL مع lock عند الحاجة.

`server.mjs` يبقى مؤقتًا كـLegacy Compatibility Layer حتى تثبت Route Parity كاملة.
