import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { DataSource, QueryRunner } from 'typeorm';

const ACTIVE = `status IN ('HELD','ACTIVE','SOLD')`;
type Operation = 'BUY' | 'RENT';
type Source = 'listing' | 'service';

function fail(code: string, status = 409): never {
  if (status === 404) throw new NotFoundException(code);
  if (status === 403) throw new ForbiddenException(code);
  if (status === 400) throw new BadRequestException(code);
  throw new ConflictException(code);
}

function assertUuid(value: string, code: string): void {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) fail(code, 400);
}

function assertWindow(start: unknown, end: unknown): void {
  const s = new Date(String(start)).getTime();
  const e = new Date(String(end)).getTime();
  if (!Number.isFinite(s) || !Number.isFinite(e) || e <= s) fail('INVALID_INVENTORY_WINDOW', 400);
}

@Injectable()
export class InventoryService {
  constructor(private readonly dataSource: DataSource) {}

  private async lockSource(runner: QueryRunner, source: Source, sourceId: string) {
    await runner.query(`SELECT pg_advisory_xact_lock(hashtextextended($1,0))`, [`inventory:${source}:${sourceId}`]);
  }

  /**
   * Atomically allocates inventory for a booking. Call this inside the caller's
   * transaction when booking/payment state must change in the same commit.
   */
  async reserveBookingInventoryInTransaction(runner: QueryRunner, bookingId: string) {
    assertUuid(bookingId, 'INVALID_BOOKING_ID');
    const rows = await runner.query(`SELECT * FROM hala.bookings WHERE id=$1 FOR UPDATE`, [bookingId]);
    const booking = rows[0];
    if (!booking) fail('BOOKING_NOT_FOUND', 404);
    assertWindow(booking.event_start, booking.event_end);

    const operation = String(booking.operation_type ?? 'RENT').toUpperCase() as Operation;
    if (!['BUY', 'RENT'].includes(operation)) return { reserved: false, reason: 'NON_INVENTORY_OPERATION' };

    const source: Source = booking.universal_listing_id ? 'listing' : 'service';
    const sourceId = booking.universal_listing_id
      ? booking.universal_listing_id
      : (await runner.query(`SELECT offer_id FROM hala.booking_wishes WHERE booking_id=$1 ORDER BY wish_rank LIMIT 1`, [bookingId]))[0]?.offer_id;
    if (!sourceId) fail('INVENTORY_SOURCE_NOT_FOUND', 400);
    await this.lockSource(runner, source, sourceId);

    const existing = await runner.query(
      `SELECT * FROM hala.inventory_reservations
       WHERE booking_id=$1 AND ${source === 'listing' ? 'listing_id=$2' : 'service_offer_id=$2'}
         AND status IN ('HELD','ACTIVE','SOLD')
       LIMIT 1`,
      [bookingId, sourceId],
    );
    if (existing.length) return { reserved: true, existing: true, reservations: existing };

    const units = source === 'listing'
      ? await runner.query(
          `SELECT lu.id,lu.quantity,lu.unit_code,lu.unit_type
           FROM hala.listing_units lu
           JOIN hala.universal_listings ul ON ul.id=lu.listing_id
           JOIN hala.markets m ON m.id=ul.market_id
           WHERE lu.listing_id=$1 AND lu.status='AVAILABLE' AND lu.quantity>0
             AND ul.listing_status='PUBLISHED' AND m.status='ACTIVE' AND m.is_deleted=false
           ORDER BY lu.id FOR UPDATE`,
          [sourceId],
        )
      : await runner.query(
          `SELECT su.id,su.quantity,su.unit_code
           FROM hala.service_units su
           JOIN hala.service_offers so ON so.id=su.offer_id
           WHERE su.offer_id=$1 AND su.unit_status='available' AND su.quantity>0
           ORDER BY su.id FOR UPDATE`,
          [sourceId],
        );

    if (!units.length) fail(source === 'listing' ? 'LISTING_INVENTORY_NOT_CONFIGURED' : 'SERVICE_INVENTORY_NOT_CONFIGURED');

    let remaining = Number(booking.quantity ?? 1);
    if (!Number.isFinite(remaining) || remaining <= 0) fail('INVALID_BOOKING_QUANTITY', 400);
    const allocations: Array<{ unitId: string; quantity: number }> = [];

    for (const unit of units) {
      if (remaining <= 0) break;
      if (source === 'service') {
        const maintenance = await runner.query(
          `SELECT 1 FROM hala.maintenance_blocks WHERE unit_id=$1 AND start_at<$3 AND end_at>$2 LIMIT 1`,
          [unit.id, booking.event_start, booking.event_end],
        );
        if (maintenance.length) continue;
      }
      const reserved = await runner.query(
        `SELECT COALESCE(SUM(quantity),0)::numeric AS reserved
         FROM hala.inventory_reservations
         WHERE ${source === 'listing' ? 'listing_unit_id=$1' : 'service_unit_id=$1'}
           AND ${ACTIVE}
           AND (operation_type='BUY' OR $4='BUY' OR (starts_at<$3 AND ends_at>$2))`,
        [unit.id, booking.event_start, booking.event_end, operation],
      );
      const free = Math.max(0, Number(unit.quantity) - Number(reserved[0]?.reserved ?? 0));
      if (free <= 0) continue;
      const take = Math.min(free, remaining);
      allocations.push({ unitId: unit.id, quantity: take });
      remaining -= take;
    }

    if (remaining > 0) fail('INSUFFICIENT_INVENTORY');

    for (const allocation of allocations) {
      await runner.query(
        `INSERT INTO hala.inventory_reservations
          (booking_id,listing_id,service_offer_id,listing_unit_id,service_unit_id,quantity,operation_type,starts_at,ends_at,status,expires_at)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,'HELD',now()+interval '15 minutes')`,
        [
          bookingId,
          source === 'listing' ? sourceId : null,
          source === 'service' ? sourceId : null,
          source === 'listing' ? allocation.unitId : null,
          source === 'service' ? allocation.unitId : null,
          allocation.quantity,
          operation,
          booking.event_start,
          booking.event_end,
        ],
      );
    }

    return { reserved: true, existing: false, reservations: allocations };
  }

  async previewListingAllocation(
    runner: QueryRunner,
    listingId: string,
    start: string,
    end: string,
    operation: Operation,
    requestedQuantity: number,
  ) {
    assertUuid(listingId, 'INVALID_LISTING_ID');
    assertWindow(start, end);
    if (!['BUY', 'RENT'].includes(operation)) fail('UNSUPPORTED_INVENTORY_OPERATION', 400);
    if (!Number.isFinite(requestedQuantity) || requestedQuantity <= 0) fail('INVALID_QUANTITY', 400);
    await this.lockSource(runner, 'listing', listingId);
    const units = await runner.query(
      `SELECT lu.id,lu.quantity,lu.unit_code,lu.unit_type
       FROM hala.listing_units lu
       JOIN hala.universal_listings ul ON ul.id=lu.listing_id
       JOIN hala.markets m ON m.id=ul.market_id
       WHERE lu.listing_id=$1 AND lu.status='AVAILABLE' AND lu.quantity>0
         AND ul.listing_status='PUBLISHED' AND m.status='ACTIVE' AND m.is_deleted=false
       ORDER BY lu.id FOR UPDATE`,
      [listingId],
    );
    if (!units.length) fail('LISTING_INVENTORY_NOT_CONFIGURED', 404);
    let remaining = requestedQuantity;
    const allocations: Array<{ unitId: string; unitCode: string; quantity: number }> = [];
    for (const unit of units) {
      if (remaining <= 0) break;
      const reserved = await runner.query(
        `SELECT COALESCE(SUM(quantity),0)::numeric AS reserved
         FROM hala.inventory_reservations
         WHERE listing_unit_id=$1 AND ${ACTIVE}
           AND (operation_type='BUY' OR $4='BUY' OR (starts_at<$3 AND ends_at>$2))`,
        [unit.id, start, end, operation],
      );
      const free = Math.max(0, Number(unit.quantity) - Number(reserved[0]?.reserved ?? 0));
      if (free <= 0) continue;
      const take = Math.min(free, remaining);
      allocations.push({ unitId: unit.id, unitCode: unit.unit_code, quantity: take });
      remaining -= take;
    }
    if (remaining > 0) fail('INSUFFICIENT_INVENTORY');
    return { available: true, requestedQuantity, allocations };
  }

  async reserveBookingInventory(bookingId: string) {
    const runner = this.dataSource.createQueryRunner();
    await runner.connect();
    await runner.startTransaction();
    try {
      const result = await this.reserveBookingInventoryInTransaction(runner, bookingId);
      await runner.commitTransaction();
      return result;
    } catch (error) {
      await runner.rollbackTransaction();
      throw error;
    } finally {
      await runner.release();
    }
  }

  async activateBookingInventoryInTransaction(runner: QueryRunner, bookingId: string) {
    assertUuid(bookingId, 'INVALID_BOOKING_ID');
    const booking = (await runner.query(`SELECT id,lifecycle_status FROM hala.bookings WHERE id=$1 FOR UPDATE`, [bookingId]))[0];
    if (!booking) fail('BOOKING_NOT_FOUND', 404);
    if (!['PROVIDER_PENDING','CONFIRMED','IN_PROGRESS','RETURN_PENDING','INSPECTION'].includes(String(booking.lifecycle_status))) fail('INVALID_INVENTORY_ACTIVATION_STATE', 409);
    const result = await runner.query(`UPDATE hala.inventory_reservations SET status='ACTIVE',expires_at=NULL,updated_at=now() WHERE booking_id=$1 AND status='HELD' RETURNING id`, [bookingId]);
    return { activated: result.length, bookingId };
  }

  async activateBookingInventory(bookingId: string, actorId?: string) {
    if (actorId) await this.requireAdmin(actorId);
    assertUuid(bookingId, 'INVALID_BOOKING_ID');
    const runner = this.dataSource.createQueryRunner();
    await runner.connect();
    await runner.startTransaction();
    try {
      const booking = (await runner.query(`SELECT id,lifecycle_status FROM hala.bookings WHERE id=$1 FOR UPDATE`, [bookingId]))[0];
      if (!booking) fail('BOOKING_NOT_FOUND', 404);
      if (!['PROVIDER_PENDING','CONFIRMED','IN_PROGRESS','RETURN_PENDING','INSPECTION'].includes(String(booking.lifecycle_status))) {
        fail('INVALID_INVENTORY_ACTIVATION_STATE', 409);
      }
      const result = await runner.query(
        `UPDATE hala.inventory_reservations
         SET status='ACTIVE',expires_at=NULL,updated_at=now()
         WHERE booking_id=$1 AND status='HELD'
         RETURNING id`,
        [bookingId],
      );
      if (actorId) {
        await runner.query(`INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,after_data,result)
          VALUES($1,'INVENTORY_ACTIVATE','booking',$2,$3,'SUCCESS')`, [actorId, bookingId, JSON.stringify({ activated: result.length })]);
      }
      await runner.commitTransaction();
      return { activated: result.length, bookingId };
    } catch (error) {
      await runner.rollbackTransaction();
      throw error;
    } finally {
      await runner.release();
    }
  }

  async releaseBookingInventoryInTransaction(runner: QueryRunner, bookingId: string, finalStatus: string) {
    assertUuid(bookingId, 'INVALID_BOOKING_ID');
    const normalized = String(finalStatus).toUpperCase();
    if (!['CANCELLED','FAILED','COMPLETED'].includes(normalized)) fail('INVALID_INVENTORY_RELEASE_STATE', 400);
    const booking = (await runner.query(`SELECT id,lifecycle_status FROM hala.bookings WHERE id=$1 FOR UPDATE`, [bookingId]))[0];
    if (!booking) fail('BOOKING_NOT_FOUND', 404);
    if (String(booking.lifecycle_status).toUpperCase() !== normalized && normalized !== 'COMPLETED') fail('INVENTORY_RELEASE_STATUS_MISMATCH', 409);
    const result = normalized === 'COMPLETED'
      ? await runner.query(`UPDATE hala.inventory_reservations SET status=CASE WHEN operation_type='BUY' THEN 'SOLD' ELSE 'RELEASED' END,expires_at=NULL,updated_at=now() WHERE booking_id=$1 AND status IN ('HELD','ACTIVE') RETURNING id,status`, [bookingId])
      : await runner.query(`UPDATE hala.inventory_reservations SET status='RELEASED',expires_at=NULL,updated_at=now() WHERE booking_id=$1 AND status IN ('HELD','ACTIVE') RETURNING id,status`, [bookingId]);
    return { released: result.length, bookingId, finalStatus: normalized };
  }

  async releaseBookingInventory(bookingId: string, finalStatus: string, actorId?: string) {
    if (actorId) await this.requireAdmin(actorId);
    assertUuid(bookingId, 'INVALID_BOOKING_ID');
    const normalized = String(finalStatus).toUpperCase();
    if (!['CANCELLED','FAILED','COMPLETED'].includes(normalized)) fail('INVALID_INVENTORY_RELEASE_STATE', 400);
    const runner = this.dataSource.createQueryRunner();
    await runner.connect();
    await runner.startTransaction();
    try {
      const booking = (await runner.query(`SELECT id,lifecycle_status FROM hala.bookings WHERE id=$1 FOR UPDATE`, [bookingId]))[0];
      if (!booking) fail('BOOKING_NOT_FOUND', 404);
      if (String(booking.lifecycle_status).toUpperCase() !== normalized && normalized !== 'COMPLETED') {
        fail('INVENTORY_RELEASE_STATUS_MISMATCH', 409);
      }
      const result = normalized === 'COMPLETED'
        ? await runner.query(
            `UPDATE hala.inventory_reservations
             SET status=CASE WHEN operation_type='BUY' THEN 'SOLD' ELSE 'RELEASED' END,
                 expires_at=NULL,updated_at=now()
             WHERE booking_id=$1 AND status IN ('HELD','ACTIVE')
             RETURNING id,status`,
            [bookingId],
          )
        : await runner.query(
            `UPDATE hala.inventory_reservations
             SET status='RELEASED',expires_at=NULL,updated_at=now()
             WHERE booking_id=$1 AND status IN ('HELD','ACTIVE')
             RETURNING id,status`,
            [bookingId],
          );
      if (actorId) {
        await runner.query(`INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,after_data,result)
          VALUES($1,'INVENTORY_RELEASE','booking',$2,$3,'SUCCESS')`, [actorId, bookingId, JSON.stringify({ released: result.length, finalStatus: normalized })]);
      }
      await runner.commitTransaction();
      return { released: result.length, bookingId, finalStatus: normalized };
    } catch (error) {
      await runner.rollbackTransaction();
      throw error;
    } finally {
      await runner.release();
    }
  }

  async expireInventoryReservations(actorId?: string) {
    if (actorId) await this.requireAdmin(actorId);
    const result = await this.dataSource.query(
      `UPDATE hala.inventory_reservations
       SET status='EXPIRED',updated_at=now()
       WHERE status='HELD' AND expires_at IS NOT NULL AND expires_at<=now()
       RETURNING id,booking_id`,
    );
    return { expired: result.length, reservations: result };
  }

  private async requireAdmin(actorId: string): Promise<void> {
    assertUuid(actorId, 'INVALID_ACTOR_ID');
    const rows = await this.dataSource.query(
      `SELECT 1 FROM hala.users u
       WHERE u.id=$1 AND u.is_active=true AND EXISTS (
         SELECT 1 FROM hala.user_roles ur JOIN hala.roles r ON r.id=ur.role_id
         WHERE ur.user_id=u.id AND lower(r.name)=ANY($2::text[])
       ) LIMIT 1`,
      [actorId, ['admin', 'super_admin', 'administrator']],
    );
    if (!rows.length) fail('INVENTORY_ADMIN_REQUIRED', 403);
  }

  async healthSnapshot(actorId?: string) {
    if (actorId) await this.requireAdmin(actorId);
    const rows = await this.dataSource.query(
      `SELECT COUNT(*) FILTER (WHERE status='HELD')::int AS held,
              COUNT(*) FILTER (WHERE status='ACTIVE')::int AS active,
              COUNT(*) FILTER (WHERE status='EXPIRED')::int AS expired,
              COUNT(*) FILTER (WHERE status='SOLD')::int AS sold,
              COUNT(*) FILTER (WHERE status='RELEASED')::int AS released
       FROM hala.inventory_reservations`,
    );
    return { inventoryReservations: rows[0] ?? { held: 0, active: 0, expired: 0, sold: 0, released: 0 } };
  }
}
