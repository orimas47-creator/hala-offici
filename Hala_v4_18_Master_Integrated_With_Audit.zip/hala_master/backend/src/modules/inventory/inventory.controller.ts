import { Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ActorContext } from '../../common/decorators/actor.decorator.js';
import { RequireActorGuard } from '../../common/guards/hala-auth.guard.js';
import type { AuthRequestContext } from '../auth/auth.types.js';
import { HalaAuthGuard } from '../../common/guards/hala-auth.guard.js';
import { InventoryService } from './inventory.service.js';

@Controller('api/v1/admin/inventory')
@UseGuards(HalaAuthGuard, RequireActorGuard)
export class InventoryController {
  constructor(private readonly inventory: InventoryService) {}

  @Get('health')
  health(@ActorContext() ctx: AuthRequestContext) {
    return this.inventory.healthSnapshot(ctx.actorId ?? undefined);
  }

  @Post('reservations/:bookingId/activate')
  activate(@Param('bookingId') bookingId: string, @ActorContext() ctx: AuthRequestContext) {
    return this.inventory.activateBookingInventory(bookingId, ctx.actorId ?? undefined);
  }

  @Post('reservations/:bookingId/release')
  release(@Param('bookingId') bookingId: string, @ActorContext() ctx: AuthRequestContext) {
    return this.inventory.releaseBookingInventory(bookingId, 'CANCELLED', ctx.actorId ?? undefined);
  }

  @Post('reservations/expire')
  expire(@ActorContext() ctx: AuthRequestContext) {
    return this.inventory.expireInventoryReservations(ctx.actorId ?? undefined);
  }
}
