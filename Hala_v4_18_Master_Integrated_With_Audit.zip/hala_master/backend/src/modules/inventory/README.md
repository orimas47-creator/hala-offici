# Stage 18F — InventoryModule

Inventory is the atomic bridge between availability, listings/services, bookings and later payments/escrow.

## Invariants
- Reservations are created inside a DB transaction.
- Booking row and inventory source are locked before allocation.
- PostgreSQL advisory transaction locks serialize competing allocations for the same source.
- Physical/service units are locked with `FOR UPDATE`.
- Existing active reservations are idempotently reused for the same booking/source.
- BUY reservations block overlapping inventory permanently until SOLD/RELEASED; RENT uses time overlap.
- Maintenance blocks are respected for legacy service units.
- Universal listing identity is not returned by public catalog inventory endpoints.
- The transaction method is exported for the future BookingsModule so booking state + inventory can commit atomically.

## Runtime status
Static/contract validation can run without PostgreSQL. Real runtime verification requires PostgreSQL/PostGIS and installed npm dependencies.
