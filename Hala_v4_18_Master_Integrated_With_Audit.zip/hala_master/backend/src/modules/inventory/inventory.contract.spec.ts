import { readFileSync } from 'node:fs';
import { join } from 'node:path';

describe('InventoryModule contract', () => {
  const root = join(process.cwd(), 'src', 'modules', 'inventory');
  const service = readFileSync(join(root, 'inventory.service.ts'), 'utf8');
  const controller = readFileSync(join(root, 'inventory.controller.ts'), 'utf8');
  const app = readFileSync(join(process.cwd(), 'src', 'app.module.ts'), 'utf8');

  it('uses database locking and atomic reservation state', () => {
    expect(service).toContain('pg_advisory_xact_lock');
    expect(service).toContain('FOR UPDATE');
    expect(service).toContain("status IN ('HELD','ACTIVE','SOLD')");
    expect(service).toContain("status='HELD'");
    expect(service).toContain("status='ACTIVE'");
    expect(service).toContain("status='RELEASED'");
    expect(service).toContain("status='EXPIRED'");
  });

  it('supports both universal listings and legacy service offers', () => {
    expect(service).toContain('universal_listing_id');
    expect(service).toContain('service_id');
    expect(service).toContain('listing_units');
    expect(service).toContain('service_units');
  });

  it('does not expose provider identity through inventory endpoints', () => {
    expect(controller).not.toContain('provider');
    expect(controller).not.toContain('businessName');
  });

  it('is registered in the Nest application', () => {
    expect(app).toContain("./modules/inventory/inventory.module.js");
    expect(app).toContain('InventoryModule');
  });
});
