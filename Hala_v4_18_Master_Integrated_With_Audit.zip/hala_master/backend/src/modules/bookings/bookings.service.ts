import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { DataSource, QueryRunner } from 'typeorm';
import { InventoryService } from '../inventory/inventory.service.js';
import type { AuthRequestContext } from '../auth/auth.types.js';
import type { CreateBookingDto } from './dto/booking.dto.js';

const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const TRANSITIONS:Record<string,string[]>={DRAFT:['PAYMENT_PENDING','CANCELLED'],PAYMENT_PENDING:['PROVIDER_PENDING','FAILED','CANCELLED'],PROVIDER_PENDING:['CONFIRMED','FAILED','CANCELLED'],CONFIRMED:['IN_PROGRESS','CANCELLED','DISPUTED','FORCE_MAJEURE'],IN_PROGRESS:['RETURN_PENDING','DISPUTED','FORCE_MAJEURE'],RETURN_PENDING:['INSPECTION','DISPUTED'],INSPECTION:['COMPLETED','DISPUTED'],COMPLETED:[],CANCELLED:[],FAILED:[],DISPUTED:['RESOLVED'],FORCE_MAJEURE:['RESOLVED'],RESOLVED:[]};

function fail(code:string,status=400):never { if(status===404) throw new NotFoundException(code); if(status===403) throw new ForbiddenException(code); if(status===409) throw new ConflictException(code); throw new BadRequestException(code); }
function uuid(v:string,code:string){if(!UUID.test(v))fail(code,400);}

@Injectable()
export class BookingsService {
  constructor(private readonly dataSource:DataSource, private readonly inventory:InventoryService) {}
  private actor(id:string|null){if(!id)throw new UnauthorizedException('ACTOR_REQUIRED');uuid(id,'ACTOR_INVALID');}
  private async tx<T>(fn:(q:QueryRunner)=>Promise<T>){const q=this.dataSource.createQueryRunner();await q.connect();await q.startTransaction();try{const out=await fn(q);await q.commitTransaction();return out;}catch(e){if(q.isTransactionActive)await q.rollbackTransaction();throw e;}finally{await q.release();}}

  async create(actorId:string|null,dto:CreateBookingDto,ctx:AuthRequestContext){
    this.actor(actorId);
    if(dto.wishes.length<1||dto.wishes.length>3)fail('WISHES_MUST_BE_1_TO_3');
    const ranks=dto.wishes.map(w=>Number(w.rank));
    if(new Set(ranks).size!==ranks.length||!ranks.includes(1))fail('INVALID_WISH_RANKS');
    if(Boolean(dto.listingId)===Boolean(dto.serviceId))fail('EXACTLY_ONE_BOOKING_SOURCE_REQUIRED');
    const start=new Date(dto.eventStart),end=new Date(dto.eventEnd);
    if(!Number.isFinite(start.getTime())||!Number.isFinite(end.getTime())||end<=start)fail('INVALID_BOOKING_DATES');
    return this.tx(async q=>{
      if(ctx.idempotencyKey){const old=await q.query(`SELECT response_body FROM hala.idempotency_records WHERE actor_user_id=$1 AND idempotency_key=$2 AND route='POST /api/v1/bookings'`,[actorId,ctx.idempotencyKey]);if(old.length)return old[0].response_body;}
      let marketId:string,serviceId:string|null=null,listingId:string|null=null,currency='YER',subtotal=0,insurance=0;
      const primary=dto.wishes.find(w=>Number(w.rank)===1)!;
      const days=Math.max(1,Math.ceil((end.getTime()-start.getTime())/86400000));
      if(dto.listingId){
        uuid(dto.listingId,'INVALID_LISTING_ID'); listingId=dto.listingId;
        const lr=await q.query(`SELECT ul.*,m.status market_status,m.is_deleted,p.status provider_status FROM hala.universal_listings ul JOIN hala.markets m ON m.id=ul.market_id JOIN hala.providers p ON p.id=ul.provider_id JOIN hala.market_provider_memberships mm ON mm.market_id=ul.market_id AND mm.provider_id=ul.provider_id AND mm.status='ACTIVE' WHERE ul.id=$1 AND ul.listing_status='PUBLISHED' AND m.status='ACTIVE' AND m.is_deleted=false AND p.status='active' AND p.insurance_confirmed=true AND p.subscription_expires_at>now() FOR SHARE`,[listingId]);
        if(!lr.length)fail('LISTING_NOT_BOOKABLE',409); const l=lr[0]; marketId=l.market_id;currency=l.base_currency||'YER';
        const compatible=dto.operationType==='BUY'?['SALE','SALE_RENTAL'].includes(l.listing_kind):['RENTAL','SALE_RENTAL'].includes(l.listing_kind);if(!compatible)fail('OPERATION_NOT_SUPPORTED_BY_LISTING',409);
        const op=await q.query(`SELECT 1 FROM hala.market_operation_configs WHERE market_id=$1 AND operation_code=$2 AND enabled=true ORDER BY version DESC LIMIT 1`,[marketId,dto.operationType]);if(!op.length)fail('OPERATION_NOT_ENABLED',409);
        const prices=await q.query(`SELECT price_type,amount,minimum_quantity,maximum_quantity,minimum_duration FROM hala.listing_prices WHERE listing_id=$1 AND enabled=true AND (valid_from IS NULL OR valid_from<=now()) AND (valid_to IS NULL OR valid_to>=now())`,[listingId]);
        const sale=prices.find((x:any)=>x.price_type==='SALE'),rent=prices.find((x:any)=>x.price_type==='RENTAL'),ins=prices.find((x:any)=>x.price_type==='INSURANCE');
        const price=dto.operationType==='BUY'?sale:rent;if(!price||Number(price.amount)<=0)fail(dto.operationType==='BUY'?'SALE_PRICE_REQUIRED':'RENTAL_PRICE_REQUIRED',409);
        if(dto.operationType==='RENT'&&(!ins||Number(ins.amount)<0))fail('RENTAL_INSURANCE_REQUIRED',409);
        if(price.minimum_quantity!=null&&dto.quantity<Number(price.minimum_quantity))fail('MINIMUM_QUANTITY_NOT_MET',409);if(price.maximum_quantity!=null&&dto.quantity>Number(price.maximum_quantity))fail('MAXIMUM_QUANTITY_EXCEEDED',409);if(dto.operationType==='RENT'&&price.minimum_duration!=null&&days<Number(price.minimum_duration))fail('MINIMUM_RENTAL_DURATION_NOT_MET',409);
        subtotal=dto.operationType==='BUY'?Number(price.amount)*dto.quantity:Number(price.amount)*dto.quantity*days;insurance=dto.operationType==='RENT'?Number(ins?.amount||0)*dto.quantity:0;
        for(const w of dto.wishes){if(!w.listingId)fail('UNIVERSAL_WISH_LISTING_REQUIRED');uuid(w.listingId,'INVALID_WISH_LISTING_ID');const wr=await q.query(`SELECT ul.id FROM hala.universal_listings ul JOIN hala.market_provider_memberships mm ON mm.market_id=ul.market_id AND mm.provider_id=ul.provider_id AND mm.status='ACTIVE' JOIN hala.providers p ON p.id=ul.provider_id WHERE ul.id=$1 AND ul.market_id=$2 AND ul.listing_status='PUBLISHED' AND p.status='active'`,[w.listingId,marketId]);if(!wr.length)fail('WISH_LISTING_NOT_BOOKABLE',409);}
        if(String(primary.listingId)!==listingId)fail('PRIMARY_WISH_MISMATCH');
      } else {
        uuid(dto.serviceId!,'INVALID_SERVICE_ID');serviceId=dto.serviceId!;
        if(!primary.offerId)fail('PRIMARY_OFFER_REQUIRED');uuid(primary.offerId,'INVALID_PRIMARY_OFFER_ID');
        const or=await q.query(`SELECT so.*,p.id provider_id,p.status provider_status,s.market_id FROM hala.service_offers so JOIN hala.providers p ON p.id=so.provider_id JOIN hala.services s ON s.id=so.service_id WHERE so.id=$1 AND so.service_id=$2 AND so.status IN ('approved','published') AND p.status='active' FOR SHARE`,[primary.offerId,serviceId]);if(!or.length)fail('PRIMARY_OFFER_NOT_BOOKABLE',409);const o=or[0];marketId=o.market_id;
        const membership=await q.query(`SELECT 1 FROM hala.market_provider_memberships WHERE market_id=$1 AND provider_id=$2 AND status='ACTIVE'`,[marketId,o.provider_id]);if(!membership.length)fail('PROVIDER_NOT_ACTIVE_IN_MARKET',409);
        const lt=String(o.listing_type).toLowerCase();if((dto.operationType==='BUY'&&lt!=='sale')||(dto.operationType==='RENT'&&lt!=='rental'))fail('OPERATION_NOT_SUPPORTED_BY_OFFER',409);
        const unitPrice=dto.operationType==='BUY'?Number(o.sale_price):Number(o.rental_price);if(!(unitPrice>0))fail('OFFER_PRICE_UNAVAILABLE',409);if(dto.operationType==='RENT'&&!(Number(o.insurance_price)>=0))fail('RENTAL_INSURANCE_REQUIRED',409);subtotal=dto.operationType==='BUY'?unitPrice*dto.quantity:unitPrice*dto.quantity*days;insurance=dto.operationType==='RENT'?Number(o.insurance_price||0)*dto.quantity:0;
        for(const w of dto.wishes){if(!w.offerId)fail('LEGACY_WISH_OFFER_REQUIRED');uuid(w.offerId,'INVALID_WISH_OFFER_ID');const wr=await q.query(`SELECT so.id FROM hala.service_offers so JOIN hala.providers p ON p.id=so.provider_id WHERE so.id=$1 AND so.service_id=$2 AND so.status IN ('approved','published') AND p.status='active'`,[w.offerId,serviceId]);if(!wr.length)fail('WISH_OFFER_NOT_BOOKABLE',409);}
      }
      const total=subtotal+insurance;
      const b=(await q.query(`INSERT INTO hala.bookings(customer_id,service_id,market_id,universal_listing_id,operation_type,status,event_start,event_end,quantity,subtotal,insurance_amount,extras_amount,total_amount,currency_code,notes,request_id,idempotency_key,lifecycle_status) VALUES($1,$2,$3,$4,$5,'draft',$6,$7,$8,$9,$10,0,$11,$12,$13,$14,$15,'DRAFT') RETURNING *`,[actorId,serviceId,marketId,listingId,dto.operationType,dto.eventStart,dto.eventEnd,dto.quantity,subtotal,insurance,total,currency,dto.notes??null,ctx.requestId??null,ctx.idempotencyKey??null]))[0];
      for(const w of dto.wishes){await q.query(`INSERT INTO hala.booking_wishes(booking_id,wish_rank,offer_id,listing_id,unit_id,status,deposit_required) VALUES($1,$2,$3,$4,$5,$6,$7)`,[b.id,w.rank,serviceId?w.offerId:null,listingId?w.listingId:null,w.unitId??null,Number(w.rank)===1?'pending':'available',Number(w.depositRequired||0)]);}
      await q.query(`INSERT INTO hala.escrow_accounts(booking_id,held_amount,status) VALUES($1,0,'holding') ON CONFLICT(booking_id) DO NOTHING`,[b.id]);
      await q.query(`INSERT INTO hala.booking_lifecycle_history(booking_id,to_status,actor_user_id,request_id,reason) VALUES($1,'DRAFT',$2,$3,'booking.created')`,[b.id,actorId,ctx.requestId??null]);
      await q.query(`INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,after_data,request_id,result) VALUES($1,'BOOKING_CREATE','booking',$2,$3::jsonb,$4,'SUCCESS')`,[actorId,b.id,JSON.stringify({marketId,serviceId,listingId,total}),ctx.requestId??null]);
      if(ctx.idempotencyKey)await q.query(`INSERT INTO hala.idempotency_records(actor_user_id,idempotency_key,route,request_hash,response_status,response_body) VALUES($1,$2,'POST /api/v1/bookings',$3,201,$4::jsonb)`,[actorId,ctx.idempotencyKey,JSON.stringify(dto),JSON.stringify(b)]);
      return b;
    });
  }

  async get(actorId:string|null,id:string){this.actor(actorId);uuid(id,'INVALID_BOOKING_ID');const rows=await this.dataSource.query(`SELECT b.* FROM hala.bookings b LEFT JOIN LATERAL(SELECT COALESCE(p1.user_id,p2.user_id) provider_user_id FROM hala.booking_wishes bw LEFT JOIN hala.service_offers so ON so.id=bw.offer_id LEFT JOIN hala.universal_listings ul ON ul.id=bw.listing_id LEFT JOIN hala.providers p1 ON p1.id=so.provider_id LEFT JOIN hala.providers p2 ON p2.id=ul.provider_id WHERE bw.booking_id=b.id ORDER BY bw.wish_rank LIMIT 1) pr ON true WHERE b.id=$1 AND (b.customer_id=$2 OR pr.provider_user_id=$2 OR EXISTS(SELECT 1 FROM hala.user_roles ur JOIN hala.roles rr ON rr.id=ur.role_id WHERE ur.user_id=$2 AND lower(rr.name) IN ('admin','finance','agent','super_admin','administrator')))`,[id,actorId]);if(!rows.length)fail('BOOKING_NOT_FOUND',404);return rows[0];}

  private async scheduleTimers(q:QueryRunner,b:any){
    const start=new Date(b.event_start).getTime(), end=new Date(b.event_end).getTime();
    const timers=[
      ['PAYMENT_DEADLINE',start-12*3600000],
      ['MILESTONE_24H',start-24*3600000],
      ['MILESTONE_18H',start-18*3600000],
      ['MILESTONE_12H',start-12*3600000],
      ['MILESTONE_6H',start-6*3600000],
      ['AUTO_COMPLETE',end+24*3600000],
      ['INSURANCE_REFUND',end+24*3600000],
    ];
    for(const [type,ms] of timers){ if(!Number.isFinite(ms)) continue; await q.query(`INSERT INTO hala.booking_timers(booking_id,timer_type,scheduled_at,metadata) VALUES($1,$2,to_timestamp($3/1000),$4::jsonb) ON CONFLICT(booking_id,timer_type) DO NOTHING`,[b.id,type,ms,JSON.stringify({source:'BookingsModule',version:1})]); }
  }

  async transition(actorId:string|null,id:string,to:string,reason:string|undefined,ctx:AuthRequestContext){this.actor(actorId);uuid(id,'INVALID_BOOKING_ID');const target=String(to).toUpperCase();return this.tx(async q=>{
    const rows=await q.query(`SELECT b.*,COALESCE(p1.user_id,p2.user_id) provider_user_id FROM hala.bookings b LEFT JOIN hala.booking_wishes bw ON bw.booking_id=b.id AND bw.wish_rank=1 LEFT JOIN hala.service_offers so ON so.id=bw.offer_id LEFT JOIN hala.universal_listings ul ON ul.id=bw.listing_id LEFT JOIN hala.providers p1 ON p1.id=so.provider_id LEFT JOIN hala.providers p2 ON p2.id=ul.provider_id WHERE b.id=$1 FOR UPDATE`,[id]);if(!rows.length)fail('BOOKING_NOT_FOUND',404);const b=rows[0];const privileged=(await q.query(`SELECT 1 FROM hala.user_roles ur JOIN hala.roles rr ON rr.id=ur.role_id WHERE ur.user_id=$1 AND lower(rr.name) IN ('admin','finance','agent','super_admin','administrator')`,[actorId])).length>0;if(b.customer_id!==actorId&&b.provider_user_id!==actorId&&!privileged)fail('FORBIDDEN_BOOKING',403);
    const from=String(b.lifecycle_status);if(!(TRANSITIONS[from]||[]).includes(target))fail(`INVALID_BOOKING_TRANSITION_${from}_TO_${target}`,409);
    if(target==='PAYMENT_PENDING'){ await this.inventory.reserveBookingInventoryInTransaction(q,id); await this.scheduleTimers(q,b); }
    if(['PROVIDER_PENDING','CONFIRMED','IN_PROGRESS','RETURN_PENDING','INSPECTION'].includes(target)) await this.inventory.activateBookingInventoryInTransaction(q,id);
    if(['CANCELLED','FAILED','COMPLETED'].includes(target)) await this.inventory.releaseBookingInventoryInTransaction(q,id,target);
    const nextVersion=Number(b.lifecycle_version||1)+1;const updated=(await q.query(`UPDATE hala.bookings SET lifecycle_status=$2,lifecycle_version=$3,updated_at=now() WHERE id=$1 AND lifecycle_status=$4 AND lifecycle_version=$5 RETURNING *`,[id,target,nextVersion,from,b.lifecycle_version||1]))[0];if(!updated)fail('BOOKING_CONCURRENT_MODIFICATION',409);
    await q.query(`INSERT INTO hala.booking_lifecycle_history(booking_id,from_status,to_status,actor_user_id,request_id,reason) VALUES($1,$2,$3,$4,$5,$6)`,[id,from,target,actorId,ctx.requestId??null,reason??null]);
    await q.query(`INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,before_data,after_data,request_id,result) VALUES($1,'BOOKING_STATUS_CHANGE','booking',$2,$3::jsonb,$4::jsonb,$5,'SUCCESS')`,[actorId,id,JSON.stringify({lifecycle_status:from,lifecycle_version:b.lifecycle_version}),JSON.stringify({lifecycle_status:target,lifecycle_version:nextVersion}),ctx.requestId??null]);
    return updated;
  });}
}
