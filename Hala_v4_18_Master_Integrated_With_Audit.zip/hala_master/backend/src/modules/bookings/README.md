# BookingsModule — Stage 18G

Bookings is the transaction boundary between catalog selection, availability, inventory and the later payment/escrow pipeline.

## Guarantees implemented
- Authenticated actor required; provider identity is resolved server-side.
- Exactly one source per booking: legacy service/offer or universal listing.
- Maximum three wishes with unique ranks and mandatory primary wish.
- Server-side price calculation; client totals are never trusted.
- Market, provider membership, subscription and compliance checks before booking.
- Inventory reservation is executed in the same database transaction as the `PAYMENT_PENDING` lifecycle transition.
- Inventory activation/release is executed in the same transaction as its lifecycle transition.
- Optimistic lifecycle version check prevents lost concurrent state transitions.
- Row locking protects the booking while its lifecycle is changed.
- Idempotency is checked before creating a second booking.
- Lifecycle history and audit log are written transactionally.
- Booking timers are created transactionally and uniquely by `(booking_id,timer_type)`.
- Provider/customer/admin/finance/agent access is restricted server-side.

## Routes
- `POST /api/v1/bookings`
- `GET /api/v1/bookings/:id`
- `POST /api/v1/bookings/:id/transition`

## Deliberate boundary
Payments, escrow settlement, notifications and timer execution are separate modules. This module only creates the timer records and lifecycle facts; it does not move money.

## Verification status
Static TypeScript transpilation and the existing 82-test Node contract suite pass in the current environment. PostgreSQL/PostGIS integration, concurrency, payment-provider sandbox and production security/load testing remain environment-gated until those dependencies are available.
