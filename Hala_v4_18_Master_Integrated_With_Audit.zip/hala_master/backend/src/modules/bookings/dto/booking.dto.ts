import { Type } from 'class-transformer';
import { IsArray, IsIn, IsNotEmpty, IsOptional, IsString, IsUUID, Max, Min, ValidateNested, IsNumber, IsDateString } from 'class-validator';

export class BookingWishDto {
  @Type(() => Number) @IsNumber() @Min(1) @Max(3)
  rank!: number;
  @IsOptional() @IsUUID() listingId?: string;
  @IsOptional() @IsUUID() offerId?: string;
  @IsOptional() @IsUUID() unitId?: string;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(0) depositRequired?: number;
}

export class CreateBookingDto {
  @IsOptional() @IsUUID() serviceId?: string;
  @IsOptional() @IsUUID() listingId?: string;
  @IsIn(['BUY','RENT']) operationType!: 'BUY' | 'RENT';
  @IsDateString() eventStart!: string;
  @IsDateString() eventEnd!: string;
  @Type(() => Number) @IsNumber() @Min(0.0001) @Max(100000) quantity!: number;
  @IsArray() @ValidateNested({ each: true }) @Type(() => BookingWishDto)
  wishes!: BookingWishDto[];
  @IsOptional() @IsString() @IsNotEmpty() notes?: string;
}

export class TransitionBookingDto {
  @IsIn(['PAYMENT_PENDING','PROVIDER_PENDING','CONFIRMED','IN_PROGRESS','RETURN_PENDING','INSPECTION','COMPLETED','CANCELLED','FAILED','DISPUTED','FORCE_MAJEURE','RESOLVED'])
  toStatus!: string;
  @IsOptional() @IsString() reason?: string;
}
