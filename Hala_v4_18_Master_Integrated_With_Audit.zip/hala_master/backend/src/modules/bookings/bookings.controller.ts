import { Body, Controller, Get, Headers, Param, Post, UseGuards } from '@nestjs/common';
import { ActorContext } from '../../common/decorators/actor.decorator.js';
import { HalaAuthGuard, RequireActorGuard } from '../../common/guards/hala-auth.guard.js';
import type { AuthRequestContext } from '../auth/auth.types.js';
import { CreateBookingDto, TransitionBookingDto } from './dto/booking.dto.js';
import { BookingsService } from './bookings.service.js';

@Controller('api/v1/bookings')
@UseGuards(HalaAuthGuard, RequireActorGuard)
export class BookingsController {
  constructor(private readonly bookings: BookingsService) {}

  @Post()
  create(@Body() dto: CreateBookingDto, @ActorContext() ctx: AuthRequestContext, @Headers('idempotency-key') idempotencyKey?: string) {
    return this.bookings.create(ctx.actorId, dto, { ...ctx, idempotencyKey });
  }

  @Get(':id')
  get(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.bookings.get(ctx.actorId, id);
  }

  @Post(':id/transition')
  transition(@Param('id') id: string, @Body() dto: TransitionBookingDto, @ActorContext() ctx: AuthRequestContext) {
    return this.bookings.transition(ctx.actorId, id, dto.toStatus, dto.reason, ctx);
  }
}
