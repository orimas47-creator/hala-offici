import { CreateBookingDto, BookingWishDto } from './dto/booking.dto.js';

describe('BookingsModule contract', () => {
  it('keeps the universal booking surface explicit', () => {
    const dto = new CreateBookingDto();
    dto.operationType = 'RENT';
    dto.wishes = [Object.assign(new BookingWishDto(), { rank: 1, listingId: '00000000-0000-4000-8000-000000000001' })];
    expect(dto.operationType).toBe('RENT');
    expect(dto.wishes).toHaveLength(1);
  });
});
