import { IsNotEmpty, IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';

export class CreateLocationDto {
  @IsUUID()
  @IsOptional()
  parentId?: string;

  @IsUUID()
  levelId!: string;

  @IsString()
  @IsNotEmpty()
  @MaxLength(200)
  nameAr!: string;

  @IsString()
  @IsOptional()
  @MaxLength(200)
  nameEn?: string;

  @IsString()
  @IsOptional()
  @MaxLength(80)
  code?: string;
}
