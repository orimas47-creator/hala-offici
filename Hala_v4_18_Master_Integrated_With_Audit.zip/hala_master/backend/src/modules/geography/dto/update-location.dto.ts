import { IsBoolean, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateLocationDto {
  @IsString()
  @IsNotEmpty()
  @IsOptional()
  @MaxLength(200)
  nameAr?: string;

  @IsString()
  @IsOptional()
  @MaxLength(200)
  nameEn?: string;

  @IsString()
  @IsOptional()
  @MaxLength(80)
  code?: string;

  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}
