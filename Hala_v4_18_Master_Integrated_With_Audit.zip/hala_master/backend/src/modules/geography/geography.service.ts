import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { DataSource } from 'typeorm';
import type { AuthRequestContext } from '../auth/auth.types.js';
import { CreateLocationDto } from './dto/create-location.dto.js';
import { UpdateLocationDto } from './dto/update-location.dto.js';

const ADMIN_ROLES = ['admin', 'super_admin', 'administrator'];
const LEVELS = new Set(['country', 'governorate', 'directorate', 'uzla', 'village', 'neighborhood', 'alley']);
const CHILD_RULES: Record<string, string[]> = {
  country: ['governorate', 'directorate'],
  governorate: ['directorate'],
  directorate: ['uzla', 'neighborhood'],
  uzla: ['village'],
  neighborhood: ['alley'],
};

@Injectable()
export class GeographyService {
  constructor(private readonly dataSource: DataSource) {}

  private requireActor(actorId: string | null): asserts actorId is string {
    if (!actorId) throw new UnauthorizedException('ACTOR_REQUIRED');
  }

  private async isAdmin(actorId: string): Promise<boolean> {
    const rows = await this.dataSource.query(
      `SELECT 1 FROM hala.user_roles ur
       JOIN hala.roles r ON r.id=ur.role_id
       WHERE ur.user_id=$1 AND lower(r.name)=ANY($2::text[]) LIMIT 1`,
      [actorId, ADMIN_ROLES],
    );
    return rows.length > 0;
  }

  private assertAdmin(isAdmin: boolean): void {
    if (!isAdmin) throw new ForbiddenException('ADMIN_REQUIRED');
  }

  async listLevels() {
    return this.dataSource.query(
      `SELECT id,code,name_ar,name_en,parent_level_id,is_active
       FROM hala.geographic_levels WHERE is_active=true ORDER BY code`,
    );
  }

  async listChildren(parentId?: string) {
    if (!parentId) {
      return this.dataSource.query(
        `SELECT l.id,l.parent_id,l.level_id,gl.code AS level_code,l.name_ar,l.name_en,l.code,l.is_active
         FROM hala.locations l JOIN hala.geographic_levels gl ON gl.id=l.level_id
         WHERE l.parent_id IS NULL AND l.is_active=true ORDER BY l.name_ar`,
      );
    }
    const rows = await this.dataSource.query(`SELECT id FROM hala.locations WHERE id=$1 AND is_active=true`, [parentId]);
    if (!rows.length) throw new NotFoundException('LOCATION_NOT_FOUND');
    return this.dataSource.query(
      `SELECT l.id,l.parent_id,l.level_id,gl.code AS level_code,l.name_ar,l.name_en,l.code,l.is_active
       FROM hala.locations l JOIN hala.geographic_levels gl ON gl.id=l.level_id
       WHERE l.parent_id=$1 AND l.is_active=true ORDER BY l.name_ar`,
      [parentId],
    );
  }

  async getLocation(id: string) {
    const rows = await this.dataSource.query(
      `SELECT l.id,l.parent_id,l.level_id,gl.code AS level_code,l.name_ar,l.name_en,l.code,l.is_active,
              p.name_ar AS parent_name_ar
       FROM hala.locations l
       JOIN hala.geographic_levels gl ON gl.id=l.level_id
       LEFT JOIN hala.locations p ON p.id=l.parent_id
       WHERE l.id=$1 LIMIT 1`,
      [id],
    );
    if (!rows.length) throw new NotFoundException('LOCATION_NOT_FOUND');
    return rows[0];
  }

  async createLocation(actorId: string | null, dto: CreateLocationDto) {
    this.requireActor(actorId);
    this.assertAdmin(await this.isAdmin(actorId));

    const levelRows = await this.dataSource.query(
      `SELECT id,code FROM hala.geographic_levels WHERE id=$1 AND is_active=true LIMIT 1`,
      [dto.levelId],
    );
    if (!levelRows.length) throw new BadRequestException('INVALID_LEVEL');
    const levelCode = String(levelRows[0].code);
    if (!LEVELS.has(levelCode)) throw new BadRequestException('UNSUPPORTED_LEVEL');

    let parent: any = null;
    if (dto.parentId) {
      const parentRows = await this.dataSource.query(
        `SELECT l.id,gl.code AS level_code FROM hala.locations l
         JOIN hala.geographic_levels gl ON gl.id=l.level_id
         WHERE l.id=$1 AND l.is_active=true LIMIT 1`,
        [dto.parentId],
      );
      if (!parentRows.length) throw new NotFoundException('PARENT_LOCATION_NOT_FOUND');
      parent = parentRows[0];
      if (!(CHILD_RULES[parent.level_code] ?? []).includes(levelCode)) {
        throw new BadRequestException('INVALID_GEOGRAPHIC_PARENT');
      }
    } else if (!['country', 'governorate', 'directorate'].includes(levelCode)) {
      throw new BadRequestException('PARENT_REQUIRED');
    }

    const duplicate = await this.dataSource.query(
      `SELECT 1 FROM hala.locations
       WHERE level_id=$1 AND parent_id IS NOT DISTINCT FROM $2 AND lower(name_ar)=lower($3)
       LIMIT 1`,
      [dto.levelId, dto.parentId ?? null, dto.nameAr.trim()],
    );
    if (duplicate.length) throw new BadRequestException('LOCATION_ALREADY_EXISTS');

    const rows = await this.dataSource.query(
      `INSERT INTO hala.locations(parent_id,level_id,name_ar,name_en,code,is_active)
       VALUES($1,$2,$3,$4,$5,true)
       RETURNING id,parent_id,level_id,name_ar,name_en,code,is_active,created_at,updated_at`,
      [dto.parentId ?? null, dto.levelId, dto.nameAr.trim(), dto.nameEn?.trim() || null, dto.code?.trim() || null],
    );

    await this.dataSource.query(
      `INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,after_data,result)
       VALUES($1,'GEOGRAPHY_LOCATION_CREATED','location',$2,$3::jsonb,'SUCCESS')`,
      [actorId, rows[0].id, JSON.stringify(rows[0])],
    );
    return rows[0];
  }

  async updateLocation(actorId: string | null, id: string, dto: UpdateLocationDto) {
    this.requireActor(actorId);
    this.assertAdmin(await this.isAdmin(actorId));
    const current = await this.getLocation(id);
    const rows = await this.dataSource.query(
      `UPDATE hala.locations SET
         name_ar=COALESCE($2,name_ar), name_en=COALESCE($3,name_en), code=COALESCE($4,code),
         is_active=COALESCE($5,is_active), updated_at=now()
       WHERE id=$1
       RETURNING id,parent_id,level_id,name_ar,name_en,code,is_active,created_at,updated_at`,
      [id, dto.nameAr?.trim() || null, dto.nameEn?.trim() || null, dto.code?.trim() || null, dto.isActive ?? null],
    );
    if (!rows.length) throw new NotFoundException('LOCATION_NOT_FOUND');
    await this.dataSource.query(
      `INSERT INTO hala.audit_logs(actor_user_id,action,entity_type,entity_id,before_data,after_data,result)
       VALUES($1,'GEOGRAPHY_LOCATION_UPDATED','location',$2,$3::jsonb,$4::jsonb,'SUCCESS')`,
      [actorId, id, JSON.stringify(current), JSON.stringify(rows[0])],
    );
    return rows[0];
  }

  async resolveDirectorate(id: string): Promise<string> {
    const rows = await this.dataSource.query(
      `WITH RECURSIVE chain AS (
         SELECT l.id,l.parent_id,gl.code FROM hala.locations l
         JOIN hala.geographic_levels gl ON gl.id=l.level_id WHERE l.id=$1
         UNION ALL
         SELECT p.id,p.parent_id,gl.code FROM hala.locations p
         JOIN chain c ON c.parent_id=p.id JOIN hala.geographic_levels gl ON gl.id=p.level_id
       ) SELECT id FROM chain WHERE code='directorate' LIMIT 1`,
      [id],
    );
    if (!rows.length) throw new NotFoundException('DIRECTORATE_NOT_FOUND');
    return String(rows[0].id);
  }

  async authorizeAgentScope(ctx: AuthRequestContext, locationId: string): Promise<boolean> {
    this.requireActor(ctx.actorId);
    const directorateId = await this.resolveDirectorate(locationId);
    const rows = await this.dataSource.query(
      `SELECT 1 FROM hala.agents a
       JOIN hala.market_agent_assignments maa ON maa.agent_id=a.id
       WHERE a.user_id=$1 AND a.status='ACTIVE' AND maa.status='ACTIVE'
         AND maa.directorate_location_id=$2 LIMIT 1`,
      [ctx.actorId, directorateId],
    );
    return rows.length > 0;
  }
}
