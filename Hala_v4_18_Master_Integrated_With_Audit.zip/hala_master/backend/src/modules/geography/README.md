# GeographyModule — Hala v4.18

طبقة جغرافية فعلية فوق `hala.locations` و`hala.geographic_levels`.

## القاعدة
- أمانة العاصمة: مديرية → حي → حارة.
- المحافظة: محافظة → مديرية → عزلة → قرية.
- لا يسمح النظام بعلاقة أب/ابن مخالفة لهذا التسلسل.
- عمليات الإنشاء والتعديل إدارية وتُسجل في Audit Log.
- `resolveDirectorate()` تستخدمها الوحدات التي تحتاج نطاق الوكيل.

## المسارات
- GET `/api/v1/geography/levels`
- GET `/api/v1/geography/locations?parentId=...`
- GET `/api/v1/geography/locations/:id`
- POST `/api/v1/geography/locations`
- PATCH `/api/v1/geography/locations/:id`

هذه الوحدة لا تنشئ سياسة جغرافية جديدة؛ بل تطبق الهيكل المعتمد في مواصفات هلا.
