import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ActorContext } from '../../common/decorators/actor.decorator.js';
import { HalaAuthGuard, RequireActorGuard } from '../../common/guards/hala-auth.guard.js';
import type { AuthRequestContext } from '../auth/auth.types.js';
import { CreateLocationDto } from './dto/create-location.dto.js';
import { UpdateLocationDto } from './dto/update-location.dto.js';
import { GeographyService } from './geography.service.js';

@Controller('api/v1/geography')
@UseGuards(HalaAuthGuard, RequireActorGuard)
export class GeographyController {
  constructor(private readonly geography: GeographyService) {}

  @Get('levels') listLevels() { return this.geography.listLevels(); }

  @Get('locations') listLocations(@Query('parentId') parentId?: string) {
    return this.geography.listChildren(parentId);
  }

  @Get('locations/:id') getLocation(@Param('id') id: string) {
    return this.geography.getLocation(id);
  }

  @Post('locations') createLocation(@Body() dto: CreateLocationDto, @ActorContext() ctx: AuthRequestContext) {
    return this.geography.createLocation(ctx.actorId, dto);
  }

  @Patch('locations/:id') updateLocation(
    @Param('id') id: string,
    @Body() dto: UpdateLocationDto,
    @ActorContext() ctx: AuthRequestContext,
  ) {
    return this.geography.updateLocation(ctx.actorId, id, dto);
  }
}
