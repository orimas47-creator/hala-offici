import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataSource, QueryRunner } from 'typeorm';
import { InventoryService } from '../inventory/inventory.service.js';

const ACTIVE_RESERVATION = `status IN ('HELD','ACTIVE','SOLD')`;

function assertWindow(start: string, end: string): void {
  const s = new Date(start).getTime();
  const e = new Date(end).getTime();
  if (!Number.isFinite(s) || !Number.isFinite(e) || e <= s) {
    throw new BadRequestException('INVALID_AVAILABILITY_WINDOW');
  }
}

function clampLimit(value: unknown, fallback = 100): number {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(500, Math.max(1, Math.trunc(n)));
}

@Injectable()
export class AvailabilityService {
  constructor(private readonly dataSource: DataSource, private readonly inventory: InventoryService) {}

  async serviceOfferAvailability(offerId: string, start: string, end: string) {
    assertWindow(start, end);
    return this.dataSource.query(
      `SELECT u.id,u.unit_code,u.quantity
       FROM hala.service_units u
       JOIN hala.service_offers o ON o.id=u.offer_id
       WHERE o.id=$1 AND o.status='published' AND u.unit_status='available'
       AND NOT EXISTS (
         SELECT 1 FROM hala.maintenance_blocks m
         WHERE m.unit_id=u.id AND m.start_at < $3 AND m.end_at > $2
       )
       AND NOT EXISTS (
         SELECT 1 FROM hala.holds h
         WHERE h.unit_id=u.id AND h.status='active'
           AND h.start_at < $3 AND h.end_at > $2 AND h.expires_at > now()
       )
       AND NOT EXISTS (
         SELECT 1 FROM hala.inventory_reservations ir
         WHERE ir.service_unit_id=u.id AND ${ACTIVE_RESERVATION}
           AND (ir.operation_type='BUY' OR (ir.starts_at < $3 AND ir.ends_at > $2))
       )
       AND NOT EXISTS (
         SELECT 1
         FROM hala.bookings b
         JOIN hala.booking_wishes w ON w.booking_id=b.id
         WHERE w.unit_id=u.id
           AND w.status IN ('pending','active','confirmed')
           AND b.event_start < $3 AND b.event_end > $2
           AND b.lifecycle_status NOT IN ('CANCELLED','FAILED','COMPLETED')
       )
       ORDER BY u.unit_code`,
      [offerId, start, end],
    );
  }

  async universalListingAvailability(
    listingId: string,
    start: string,
    end: string,
    operation: 'BUY' | 'RENT' = 'RENT',
  ) {
    assertWindow(start, end);
    const rows = await this.dataSource.query(
      `SELECT lu.id,lu.unit_code,lu.quantity,lu.unit_type,lu.status,
        GREATEST(
          lu.quantity-COALESCE((
            SELECT SUM(ir.quantity)
            FROM hala.inventory_reservations ir
            WHERE ir.listing_unit_id=lu.id AND ${ACTIVE_RESERVATION}
              AND (ir.operation_type='BUY' OR $4='BUY' OR (ir.starts_at<$3 AND ir.ends_at>$2))
          ),0),0
        )::numeric AS available_quantity
       FROM hala.listing_units lu
       JOIN hala.universal_listings ul ON ul.id=lu.listing_id
       JOIN hala.markets m ON m.id=ul.market_id
       WHERE lu.listing_id=$1
         AND ul.listing_status='PUBLISHED'
         AND m.status='ACTIVE' AND m.is_deleted=false
         AND lu.status='AVAILABLE'
       ORDER BY lu.id`,
      [listingId, start, end, operation],
    );
    return rows.filter((row: { available_quantity: string | number }) => Number(row.available_quantity) > 0);
  }

  async reservePreview(
    runner: QueryRunner,
    listingId: string,
    start: string,
    end: string,
    operation: 'BUY' | 'RENT',
    requestedQuantity: number,
  ) {
    return this.inventory.previewListingAllocation(runner, listingId, start, end, operation, requestedQuantity);
  }

  async healthSnapshot() {
    const rows = await this.dataSource.query(
      `SELECT
         COUNT(*) FILTER (WHERE status='HELD')::int AS held,
         COUNT(*) FILTER (WHERE status='ACTIVE')::int AS active,
         COUNT(*) FILTER (WHERE status='EXPIRED')::int AS expired
       FROM hala.inventory_reservations`,
    );
    return { inventoryReservations: rows[0] ?? { held: 0, active: 0, expired: 0 } };
  }

  normalizeLimit(value?: string) {
    return clampLimit(value, 100);
  }
}
