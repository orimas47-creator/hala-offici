import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from '@jest/globals';

describe('AvailabilityModule contract', () => {
  const root = join(process.cwd(), 'src', 'modules', 'availability');
  it('exposes both legacy service and universal listing availability routes', () => {
    const controller = readFileSync(join(root, 'availability.controller.ts'), 'utf8');
    expect(controller).toContain("@Get('services/:id/availability')");
    expect(controller).toContain("@Get('listings/:id/availability')");
  });
  it('checks maintenance, holds, inventory reservations and active booking wishes', () => {
    const service = readFileSync(join(root, 'availability.service.ts'), 'utf8');
    for (const token of ['maintenance_blocks', 'holds', 'inventory_reservations', 'booking_wishes']) {
      expect(service).toContain(token);
    }
    expect(service).toContain('pg_advisory_xact_lock');
  });
  it('does not create reservations during a read-only availability request', () => {
    const controller = readFileSync(join(root, 'availability.controller.ts'), 'utf8');
    expect(controller).not.toContain('INSERT INTO hala.inventory_reservations');
  });
});
