# AvailabilityModule — Stage 18E

محرك التوفر الموحد في NestJS.

## مسؤولياته
- قراءة توفر `service_units` للعروض القديمة.
- قراءة توفر `listing_units` للعروض الموحدة.
- استبعاد الصيانة والحجوزات المؤقتة والحجوزات/المخزون المتداخل.
- احترام عملية BUY/RENT.
- استخدام transaction advisory lock عند معاينة تخصيص مخزون السوق الموحد.
- عدم إنشاء حجز فعلي هنا؛ إنشاء الحجز وتثبيت المخزون يبقى مسؤولية Bookings/Inventory عند هجرتهما إلى NestJS.

## ملاحظة تشغيلية
الـSQL يعتمد على مخطط Hala v4.17 الموجود في `database/schema_v4_17.sql`.
لا يوجد ادعاء باختبار PostgreSQL فعلي في بيئة التطوير الحالية لعدم توفر PostgreSQL/node_modules.
