import { IsIn, IsISO8601, IsOptional } from 'class-validator';

export class AvailabilityQueryDto {
  @IsISO8601()
  start!: string;

  @IsISO8601()
  end!: string;

  @IsOptional()
  @IsIn(['BUY', 'RENT'])
  operation?: 'BUY' | 'RENT';
}
