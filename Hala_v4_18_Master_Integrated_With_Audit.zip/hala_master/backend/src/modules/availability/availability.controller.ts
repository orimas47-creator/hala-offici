import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { HalaAuthGuard } from '../../common/guards/hala-auth.guard.js';
import { AvailabilityQueryDto } from './dto/availability-query.dto.js';
import { AvailabilityService } from './availability.service.js';

@Controller('api/v1')
@UseGuards(HalaAuthGuard)
export class AvailabilityController {
  constructor(private readonly availability: AvailabilityService) {}

  @Get('services/:id/availability')
  serviceAvailability(@Param('id') id: string, @Query() query: AvailabilityQueryDto) {
    return this.availability.serviceOfferAvailability(id, query.start, query.end);
  }

  @Get('listings/:id/availability')
  listingAvailability(@Param('id') id: string, @Query() query: AvailabilityQueryDto) {
    return this.availability.universalListingAvailability(id, query.start, query.end, query.operation ?? 'RENT');
  }
}
