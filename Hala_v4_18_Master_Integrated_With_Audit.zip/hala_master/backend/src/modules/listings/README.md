# ListingsModule — Stage 18D

Migrates the universal listing/demand engine into NestJS while preserving the v4.17 invariants:

- provider must be active, insured, subscribed and an active member of the market;
- market operation must be enabled by market configuration;
- listings enter `AI_REVIEW`, never directly `PUBLISHED`;
- rental listings require rental price and insurance;
- sale listings require sale price;
- assets are metadata-only and storage keys reject traversal/absolute paths;
- idempotency is preserved for listing and demand creation;
- customer-facing listing queries never expose provider identity;
- demand matching is explainable through stored factors and scores;
- all financial settlement remains outside this module.

The legacy universal-market service remains during migration for compatibility with `server.mjs`.
