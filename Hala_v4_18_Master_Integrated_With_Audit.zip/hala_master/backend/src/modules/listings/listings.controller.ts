import { Body, Controller, Get, Headers, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ActorContext } from '../../common/decorators/actor.decorator.js';
import { HalaAuthGuard, RequireActorGuard } from '../../common/guards/hala-auth.guard.js';
import type { AuthRequestContext } from '../auth/auth.types.js';
import { CreateDemandDto, CreateListingDto } from './dto/listing.dto.js';
import { ListingsService } from './listings.service.js';

@Controller('api/v1')
@UseGuards(HalaAuthGuard)
export class ListingsController {
  constructor(private readonly listings: ListingsService) {}

  @Get(['catalog/markets/:marketKey/listings','markets/:marketKey/listings'])
  list(@Param('marketKey') marketKey: string, @Query('limit') limit?: string) {
    return this.listings.listMarketListings(marketKey, { limit });
  }

  @UseGuards(RequireActorGuard)
  @Post('listings')
  create(@Body() dto: CreateListingDto, @ActorContext() ctx: AuthRequestContext, @Headers('idempotency-key') idempotencyKey?: string) {
    return this.listings.createListing(ctx.actorId, dto, { ...ctx, idempotencyKey });
  }

  @UseGuards(RequireActorGuard)
  @Post('demands')
  createDemand(@Body() dto: CreateDemandDto, @ActorContext() ctx: AuthRequestContext, @Headers('idempotency-key') idempotencyKey?: string) {
    return this.listings.createDemand(ctx.actorId, dto, { ...ctx, idempotencyKey });
  }

  @UseGuards(RequireActorGuard)
  @Post('demands/:id/match')
  match(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.listings.matchDemand(ctx.actorId, id);
  }

  @UseGuards(RequireActorGuard)
  @Get('demands/:id/matches')
  matches(@Param('id') id: string, @ActorContext() ctx: AuthRequestContext) {
    return this.listings.getDemandMatches(ctx.actorId, id);
  }
}
