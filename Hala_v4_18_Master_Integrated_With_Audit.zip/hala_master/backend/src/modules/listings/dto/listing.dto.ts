import { IsArray, IsIn, IsInt, IsNumber, IsObject, IsOptional, IsString, IsUUID, Length, Min, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

const OPS = ['BUY','RENT','BUY_OR_RENT','SERVICE','QUOTE'] as const;

export class ListingAssetDto {
  @IsOptional() @IsString() @Length(1,60) assetType?: string;
  @IsString() @Length(1,1000) storageKey!: string;
  @IsOptional() @IsString() @Length(1,160) mimeType?: string;
  @IsOptional() @IsInt() @Min(0) fileSizeBytes?: number;
  @IsOptional() @IsString() @Length(1,128) contentHash?: string;
  @IsOptional() @IsString() @Length(1,16) languageCode?: string;
  @IsOptional() @IsString() @Length(1,500) title?: string;
  @IsOptional() @IsObject() metadata?: Record<string, unknown>;
}

export class CreateListingDto {
  @IsUUID() marketId!: string;
  @IsOptional() @IsUUID() sectionId?: string;
  @IsOptional() @IsUUID() categoryId?: string;
  @IsIn(OPS) operationType!: typeof OPS[number];
  @IsString() @Length(2,500) title!: string;
  @IsOptional() @IsString() @Length(0,10000) shortDescription?: string;
  @IsOptional() @IsString() @Length(0,30000) longDescription?: string;
  @IsOptional() @IsString() @Length(0,250) brand?: string;
  @IsOptional() @IsString() @Length(0,300) manufacturerName?: string;
  @IsOptional() @IsString() @Length(0,300) modelName?: string;
  @IsOptional() @IsInt() modelYear?: number;
  @IsOptional() @IsString() @Length(0,60) conditionCode?: string;
  @IsOptional() @IsString() @Length(2,3) countryOfOrigin?: string;
  @IsOptional() @IsNumber() @Min(0) quantity?: number;
  @IsOptional() @IsString() @Length(1,40) unitCode?: string;
  @IsOptional() @IsNumber() @Min(0) minOrderQuantity?: number;
  @IsOptional() @IsNumber() @Min(0) maxOrderQuantity?: number;
  @IsOptional() @IsString() @Length(3,3) currencyCode?: string;
  @IsOptional() @IsNumber() @Min(0) basePrice?: number;
  @IsOptional() @IsString() @Length(1,60) pricingModel?: string;
  @IsOptional() @IsNumber() @Min(0) salePrice?: number;
  @IsOptional() @IsNumber() @Min(0) rentalPrice?: number;
  @IsOptional() @IsNumber() @Min(0) insurancePrice?: number;
  @IsOptional() @IsString() @Length(1,60) billingUnit?: string;
  @IsOptional() @IsNumber() @Min(0) minimumDuration?: number;
  @IsOptional() @IsArray() @IsString({ each: true }) tags?: string[];
  @IsOptional() @IsObject() attributes?: Record<string, unknown>;
  @IsOptional() @IsObject() specifications?: Record<string, unknown>;
  @IsOptional() @IsObject() usageConstraints?: Record<string, unknown>;
  @IsOptional() @IsObject() serviceCapabilities?: Record<string, unknown>;
  @IsOptional() @IsObject() compatibility?: Record<string, unknown>;
  @IsOptional() @IsArray() @ValidateNested({ each: true }) @Type(() => ListingAssetDto) assets?: ListingAssetDto[];
}

export class CreateDemandDto {
  @IsUUID() marketId!: string;
  @IsOptional() @IsUUID() sectionId?: string;
  @IsOptional() @IsUUID() categoryId?: string;
  @IsIn(OPS) operationType!: typeof OPS[number];
  @IsString() @Length(2,500) title!: string;
  @IsOptional() @IsString() @Length(0,10000) description?: string;
  @IsOptional() @IsObject() requestedAttributes?: Record<string, unknown>;
  @IsOptional() @IsNumber() @Min(0) quantity?: number;
  @IsOptional() @IsString() @Length(1,40) unitCode?: string;
  @IsOptional() @IsNumber() @Min(0) budgetMin?: number;
  @IsOptional() @IsNumber() @Min(0) budgetMax?: number;
  @IsOptional() @IsString() @Length(3,3) currencyCode?: string;
  @IsOptional() @IsString() neededFrom?: string;
  @IsOptional() @IsString() neededTo?: string;
  @IsOptional() @IsUUID() locationId?: string;
  @IsOptional() @IsObject() locationRequirements?: Record<string, unknown>;
  @IsOptional() @IsIn(['MATCHED_PROVIDERS','PUBLIC','PRIVATE']) visibility?: string;
  @IsOptional() @IsString() expiresAt?: string;
}
