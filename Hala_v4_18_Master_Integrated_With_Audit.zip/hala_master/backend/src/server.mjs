import http from 'node:http';
import { json, readJson, requestContext, allowedOrigin } from './common/http.mjs';
import { pingDb } from './common/db.mjs';
import { getBooking, createBooking, transitionBooking } from './modules/bookings/service.mjs';
import { listServices, getService } from './modules/catalog/service.mjs';
import { requestOtp, verifyOtp, authenticate, requireRoles, revokeSession } from './modules/auth/service.mjs';
import { wallet } from './modules/wallet/service.mjs';
import { userNotifications } from './modules/notifications/service.mjs';
import { openDispute } from './modules/disputes/service.mjs';
import { availability, universalAvailability } from './modules/availability/service.mjs';
import { createPayment, verifyPayment } from './modules/payments/service.mjs';
import { receivePaymentWebhook } from './modules/payments/webhook.mjs';
import { dashboard as adminDashboard } from './modules/admin/service.mjs';
import { getUser, updateUser } from './modules/users/service.mjs';
import { getProvider, requestProviderApplication, listProviderApplications, approveProviderApplication, rejectProviderApplication, updateProvider } from './modules/providers/service.mjs';
import { getEscrow, releaseEscrow, refundEscrow } from './modules/escrow/service.mjs';
import { accountBalance, createBalancedEntry } from './modules/ledger/service.mjs';
import { createListing, createDemand, matchDemand, getDemandMatches, listMarketListings } from './modules/universal-market/service.mjs';
import { getGlobalPortal, listPortalRails, upsertPortalRail, createPortalAd } from './modules/global-portal/service.mjs';
import { listMarkets, getMarket, createMarket, updateMarket, activateMarket, pauseMarket, archiveMarket, softDeleteMarket, restoreMarket, setReferenceTemplate, createSection, createAttribute, upsertOperation, createUiConfig, getPublicMarketConfig, updateSection, archiveSection, updateAttribute, archiveAttribute, updateUiConfig, archiveUiConfig, publishUiConfig, addProvider, suspendProvider } from './modules/market-builder/service.mjs';

const port=Number(process.env.PORT||8080);
if(process.env.NODE_ENV==='production' && process.env.HALA_ALLOW_DEV_ACTOR_HEADER==='true') throw new Error('HALA_ALLOW_DEV_ACTOR_HEADER must be false in production');
async function handler(req,res){
  const rawCtx=requestContext(req); let ctx=rawCtx; const url=new URL(req.url,`http://${req.headers.host||'localhost'}`); const path=url.pathname;
  try {
    if(req.method==='OPTIONS'){ const origin=allowedOrigin(req); return json(res,204,null, origin ? {'access-control-allow-origin':origin} : {}); }
    if(req.method==='GET' && path==='/health') return json(res,200,{ok:true,service:'hala-backend',version:'4.18.0'});
    if(req.method==='GET' && path==='/ready'){ await pingDb(); return json(res,200,{ok:true,ready:true,database:true}); }
    const wh=path.match(/^\/api\/v1\/webhooks\/payments\/([A-Za-z0-9_-]+)$/);
    if(req.method==='POST' && wh){ const raw=await new Promise((resolve,reject)=>{let bufs=[],n=0;req.on('data',c=>{n+=c.length;if(n>1048576){reject(Object.assign(new Error('PAYLOAD_TOO_LARGE'),{status:413}));req.destroy();return;}bufs.push(c)});req.on('end',()=>resolve(Buffer.concat(bufs).toString('utf8')));req.on('error',reject);}); return json(res,202,await receivePaymentWebhook(wh[1],raw,req.headers),{'x-request-id':rawCtx.requestId}); }
    ctx=await authenticate(rawCtx); ctx.origin=allowedOrigin(req); res._halaOrigin=ctx.origin;
    if(req.method==='GET' && path==='/api/v1/portal'){ return json(res,200,await getGlobalPortal()); }
    if(req.method==='GET' && path==='/api/v1/admin/portal/rails'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); await requireRoles(ctx.actorId,['admin','super_admin','administrator']); return json(res,200,await listPortalRails(ctx.actorId)); }
    if(req.method==='POST' && path==='/api/v1/admin/portal/rails'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); await requireRoles(ctx.actorId,['admin','super_admin','administrator']); return json(res,201,await upsertPortalRail(ctx.actorId,await readJson(req))); }
    if(req.method==='POST' && path==='/api/v1/admin/portal/ads'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); await requireRoles(ctx.actorId,['admin','super_admin','administrator']); return json(res,201,await createPortalAd(ctx.actorId,await readJson(req))); }
    if(req.method==='GET' && path==='/api/v1/ai/supervisor/status'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); await requireRoles(ctx.actorId,['admin','super_admin','administrator']); const {globalAiStatus}=await import('./modules/ai/supervisor.mjs'); return json(res,200,await globalAiStatus()); }
    if(req.method==='POST' && path==='/api/v1/auth/logout'){ const bearer=String(rawCtx.authorization||'').match(/^Bearer\s+([A-Za-z0-9._~-]{40,160})$/i)?.[1]||null; if(!ctx.actorId || !bearer) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); await revokeSession(ctx.actorId,bearer); return json(res,200,{loggedOut:true}); }
    if(req.method==='POST' && path==='/api/v1/auth/request-otp'){ const b=await readJson(req); return json(res,200,await requestOtp(b.phone,b.purpose||'login',ctx)); }
    if(req.method==='POST' && path==='/api/v1/auth/verify-otp'){ const b=await readJson(req); return json(res,200,await verifyOtp(b.phone,b.code,b.purpose||'login',ctx)); }
    if(req.method==='GET' && path==='/api/v1/admin/dashboard'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await adminDashboard(ctx.actorId)); }
    const ur=path.match(/^\/api\/v1\/users\/([0-9a-f-]+)$/i);
    if(ur && req.method==='GET'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await getUser(ctx.actorId,ur[1])); }
    if(ur && req.method==='PATCH'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await updateUser(ctx.actorId,ur[1],await readJson(req))); }
    if(req.method==='POST' && path==='/api/v1/provider-applications'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,201,await requestProviderApplication(ctx.actorId,await readJson(req),ctx)); }
    if(req.method==='GET' && path==='/api/v1/admin/provider-applications'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await listProviderApplications(ctx.actorId,{status:url.searchParams.get('status')})); }
    const apa=path.match(/^\/api\/v1\/admin\/provider-applications\/([0-9a-f-]+)\/(approve|reject)$/i);
    if(apa && req.method==='POST'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); const b=await readJson(req); return json(res,200,apa[2]==='approve'?await approveProviderApplication(ctx.actorId,apa[1],b):await rejectProviderApplication(ctx.actorId,apa[1],b.reason||null),{'x-request-id':ctx.requestId}); }
    const pr=path.match(/^\/api\/v1\/providers\/([0-9a-f-]+)$/i);
    if(pr && req.method==='GET'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await getProvider(ctx.actorId,pr[1])); }
    if(pr && req.method==='PATCH'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await updateProvider(ctx.actorId,pr[1],await readJson(req))); }
    if(req.method==='GET' && /^\/api\/v1\/markets\/[^/]+\/config$/.test(path)){ return json(res,200,await getPublicMarketConfig(path.split('/')[4])); }
    if(req.method==='GET' && /^\/api\/v1\/markets\/[^/]+\/listings$/.test(path)){ return json(res,200,{items:await listMarketListings(path.split('/')[4],{limit:url.searchParams.get('limit')})}); }
    if(req.method==='GET' && path==='/api/v1/catalog/services'){ return json(res,200,await listServices()); }
    if(req.method==='GET' && /^\/api\/v1\/services\/[^/]+\/availability$/.test(path)){ const id=path.split('/')[4]; return json(res,200,await availability(id,url.searchParams.get('start'),url.searchParams.get('end'))); }
    if(req.method==='GET' && /^\/api\/v1\/listings\/[^/]+\/availability$/.test(path)){ const id=path.split('/')[4]; return json(res,200,await universalAvailability(id,url.searchParams.get('start'),url.searchParams.get('end'),url.searchParams.get('operation')||'RENT')); }
    if(req.method==='GET' && /^\/api\/v1\/services\/[^/]+$/.test(path)){ return json(res,200,await getService(path.split('/').pop())); }
    if(req.method==='GET' && path==='/api/v1/notifications'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await userNotifications(ctx.actorId)); }
    if(req.method==='GET' && path==='/api/v1/wallet'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await wallet(ctx.actorId,url.searchParams.get('currency'))); }
    const pm=path.match(/^\/api\/v1\/bookings\/([0-9a-f-]+)\/payment$/i);
    if(req.method==='POST' && pm){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); const b=await readJson(req); return json(res,201,await createPayment(ctx.actorId,pm[1],b,ctx),{'x-request-id':ctx.requestId}); }
    const pv=path.match(/^\/api\/v1\/bookings\/([0-9a-f-]+)\/payment\/([^/]+)\/verify$/i);
    if(req.method==='POST' && pv){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); await requireRoles(ctx.actorId,['admin','finance']); const b=await readJson(req); return json(res,200,await verifyPayment(ctx.actorId,pv[1],pv[2],b.outcome||'verified',ctx),{'x-request-id':ctx.requestId}); }
    if(req.method==='POST' && path==='/api/v1/listings'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,201,await createListing(ctx.actorId,await readJson(req),ctx),{'x-request-id':ctx.requestId}); }
    if(req.method==='POST' && path==='/api/v1/demands'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,201,await createDemand(ctx.actorId,await readJson(req),ctx),{'x-request-id':ctx.requestId}); }
    const dm=path.match(/^\/api\/v1\/demands\/([0-9a-f-]+)\/match$/i);
    if(req.method==='POST' && dm){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await matchDemand(ctx.actorId,dm[1]),{'x-request-id':ctx.requestId}); }
    const dmm=path.match(/^\/api\/v1\/demands\/([0-9a-f-]+)\/matches$/i);
    if(req.method==='GET' && dmm){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await getDemandMatches(ctx.actorId,dmm[1])); }
    if(req.method==='GET' && path==='/api/v1/admin/markets'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await listMarkets(ctx.actorId,ctx)); }
    if(req.method==='POST' && path==='/api/v1/admin/markets'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); const b=await readJson(req); return json(res,201,await createMarket(ctx.actorId,b,ctx),{'x-request-id':ctx.requestId}); }
    const am=path.match(/^\/api\/v1\/admin\/markets\/([0-9a-f-]+)$/i);
    if(req.method==='GET' && am){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await getMarket(ctx.actorId,am[1])); }
    if(req.method==='PATCH' && am){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); const b=await readJson(req); return json(res,200,await updateMarket(ctx.actorId,am[1],b,ctx),{'x-request-id':ctx.requestId}); }
    const as=path.match(/^\/api\/v1\/admin\/markets\/([0-9a-f-]+)\/(activate|pause|archive|restore|delete|reference|sections|attributes|operations|ui-configs)$/i);
    const asc=path.match(/^\/api\/v1\/admin\/market-sections\/([0-9a-f-]+)$/i);
    if(asc && req.method==='PATCH'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await updateSection(ctx.actorId,asc[1],await readJson(req),ctx)); }
    if(asc && req.method==='DELETE'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await archiveSection(ctx.actorId,asc[1],ctx)); }
    const aac=path.match(/^\/api\/v1\/admin\/market-attributes\/([0-9a-f-]+)$/i);
    if(aac && req.method==='PATCH'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await updateAttribute(ctx.actorId,aac[1],await readJson(req),ctx)); }
    if(aac && req.method==='DELETE'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await archiveAttribute(ctx.actorId,aac[1],ctx)); }
    const aup=path.match(/^\/api\/v1\/admin\/market-ui-configs\/([0-9a-f-]+)\/publish$/i);
    if(aup && req.method==='POST'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await publishUiConfig(ctx.actorId,aup[1],ctx)); }
    const au=path.match(/^\/api\/v1\/admin\/market-ui-configs\/([0-9a-f-]+)$/i);
    if(au && req.method==='PATCH'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await updateUiConfig(ctx.actorId,au[1],await readJson(req),ctx)); }
    if(au && req.method==='DELETE'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await archiveUiConfig(ctx.actorId,au[1],ctx)); }
    const amp=path.match(/^\/api\/v1\/admin\/markets\/([0-9a-f-]+)\/providers$/i);
    if(amp && req.method==='POST'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); const b=await readJson(req); return json(res,201,await addProvider(ctx.actorId,amp[1],b.providerId,ctx)); }
    const ams=path.match(/^\/api\/v1\/admin\/market-provider-memberships\/([0-9a-f-]+)\/suspend$/i);
    if(ams && req.method==='POST'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await suspendProvider(ctx.actorId,ams[1],ctx)); }
    if(as){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); const id=as[1], action=as[2];
      if(req.method==='POST' && action==='reference') return json(res,200,await setReferenceTemplate(ctx.actorId,id,ctx));
      if(req.method==='POST' && action==='activate') return json(res,200,await activateMarket(ctx.actorId,id,ctx));
      if(req.method==='POST' && action==='pause') return json(res,200,await pauseMarket(ctx.actorId,id,ctx));
      if(req.method==='POST' && action==='archive') return json(res,200,await archiveMarket(ctx.actorId,id,ctx));
      if(req.method==='POST' && action==='restore') return json(res,200,await restoreMarket(ctx.actorId,id,ctx));
      if(req.method==='DELETE' && action==='delete') return json(res,200,await softDeleteMarket(ctx.actorId,id,ctx));
      if(req.method==='POST' && ['sections','attributes','operations','ui-configs'].includes(action)){ const b=await readJson(req); const fn={sections:createSection,attributes:createAttribute,operations:upsertOperation,'ui-configs':createUiConfig}[action]; return json(res,201,await fn(ctx.actorId,id,b,ctx)); }
    }
    if(req.method==='POST' && path==='/api/v1/disputes'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); const b=await readJson(req); return json(res,201,await openDispute(ctx.actorId,b.bookingId,b.reason)); }
    if(req.method==='GET' && /^\/api\/v1\/bookings\/[0-9a-f-]+$/i.test(path)){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); const b=await getBooking(ctx.actorId,path.split('/').pop()); return json(res,200,b); }
    if(req.method==='POST' && path==='/api/v1/bookings'){ const body=await readJson(req); const out=await createBooking(ctx.actorId,body,ctx); return json(res,201,out,{'x-request-id':ctx.requestId}); }
    const m=path.match(/^\/api\/v1\/bookings\/([0-9a-f-]+)\/transition$/i);
    if(req.method==='POST' && m){ const body=await readJson(req); const out=await transitionBooking(ctx.actorId,m[1],String(body.to||''),body.reason,ctx); return json(res,200,out,{'x-request-id':ctx.requestId}); }
    const ep=path.match(/^\/api\/v1\/bookings\/([0-9a-f-]+)\/escrow$/i);
    if(ep && req.method==='GET'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await getEscrow(ctx.actorId,ep[1])); }
    if(ep && req.method==='POST'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); await requireRoles(ctx.actorId,['admin','finance']); const b=await readJson(req); return json(res,200,await releaseEscrow(ctx.actorId,ep[1],b.amount,ctx)); }
    const er=path.match(/^\/api\/v1\/bookings\/([0-9a-f-]+)\/escrow\/refund$/i);
    if(er && req.method==='POST'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); await requireRoles(ctx.actorId,['admin','finance']); const b=await readJson(req); return json(res,200,await refundEscrow(ctx.actorId,er[1],b.amount,ctx)); }
    const la=path.match(/^\/api\/v1\/ledger\/accounts\/([0-9a-f-]+)\/balance$/i);
    if(la && req.method==='GET'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,200,await accountBalance(ctx.actorId,la[1])); }
    if(req.method==='POST' && path==='/api/v1/ledger/entries'){ if(!ctx.actorId) throw Object.assign(new Error('ACTOR_REQUIRED'),{status:401}); return json(res,201,await createBalancedEntry(ctx.actorId,await readJson(req))); }
    return json(res,404,{error:'NOT_FOUND',requestId:ctx.requestId});
  } catch(e){ return json(res,e.status||500,{error:e.code||e.message||'INTERNAL_ERROR',requestId:ctx.requestId}); }
}
const server=http.createServer(handler); server.requestTimeout=30000; server.headersTimeout=10000; server.keepAliveTimeout=5000; server.listen(port,()=>console.log(`Hala Backend v4.18 listening on :${port}`));
