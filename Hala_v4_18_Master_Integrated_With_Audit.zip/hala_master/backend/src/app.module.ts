import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { validateEnv } from './config/env.validation.js';
import { DatabaseModule } from './database/database.module.js';
import { HealthModule } from './modules/health/health.module.js';
import { AuthModule } from './modules/auth/auth.module.js';
import { UsersModule } from './modules/users/users.module.js';
import { ProvidersModule } from './modules/providers/providers.module.js';
import { GeographyModule } from './modules/geography/geography.module.js';
import { AvailabilityModule } from './modules/availability/availability.module.js';
import { MarketsModule } from './modules/markets/markets.module.js';
import { ListingsModule } from './modules/listings/listings.module.js';
import { InventoryModule } from './modules/inventory/inventory.module.js';
import { BookingsModule } from './modules/bookings/bookings.module.js';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      validate: validateEnv,
      cache: true,
    }),
    DatabaseModule,
    ThrottlerModule.forRoot([
      {
        ttl: 60_000,
        limit: 120,
      },
    ]),
    HealthModule,
    AuthModule,
    UsersModule,
    ProvidersModule,
    GeographyModule,
    AvailabilityModule,
    MarketsModule,
    ListingsModule,
    InventoryModule,
    BookingsModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule {}
