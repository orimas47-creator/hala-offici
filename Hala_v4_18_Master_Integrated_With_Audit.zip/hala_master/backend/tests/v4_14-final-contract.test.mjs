import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..','..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('v4.16 release metadata is synchronized',()=>{
  assert.equal(JSON.parse(read('backend/package.json')).version,'4.18.0');
  assert.match(read('backend/src/server.mjs'),/version:'4.18.0'/);
  assert.match(read('backend/openapi/openapi.yaml'),/4\.18/);
});

test('production compose still has no pilot seed and pins production behavior',()=>{
 const c=read('infra/docker/docker-compose.yml');
 assert.doesNotMatch(c,/003_pilot_seed/);
 assert.match(c,/NODE_ENV: production/);
 assert.match(c,/HALA_DEV_OTP: "false"/);
 assert.match(c,/HALA_ALLOW_DEV_ACTOR_HEADER: "false"/);
});

test('universal booking does not trust client total amount',()=>{
 const s=read('backend/src/modules/bookings/service.mjs');
 assert.match(s,/total=subtotal\+insurance/);
 assert.doesNotMatch(s,/body\.totalAmount/);
});

test('universal booking prevents duplicate wishes',()=>{
 const s=read('backend/src/modules/bookings/service.mjs');
 assert.match(s,/DUPLICATE_WISH_LISTING/);
});
