#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

fail=0
check_cmd() {
  local c="$1"
  if command -v "$c" >/dev/null 2>&1; then
    echo "[OK] $c: $(command -v "$c")"
  else
    echo "[BLOCKED] $c غير متوفر"
    fail=1
  fi
}

check_cmd docker
if command -v docker >/dev/null 2>&1; then
  docker --version
  if docker compose version >/dev/null 2>&1; then
    echo "[OK] docker compose"
    docker compose version
  else
    echo "[BLOCKED] docker compose غير متوفر"
    fail=1
  fi
fi

check_cmd node
check_cmd npm

if [[ ! -f infra/docker/.env ]]; then
  echo "[BLOCKED] infra/docker/.env غير موجود. أنشئه من .env.example ثم ضع الأسرار الحقيقية."
  fail=1
else
  if grep -q 'CHANGE_ME' infra/docker/.env; then
    echo "[BLOCKED] ما زالت قيم CHANGE_ME موجودة في .env"
    fail=1
  else
    echo "[OK] production env does not contain CHANGE_ME placeholders"
  fi
fi

if [[ "$fail" -ne 0 ]]; then
  echo
  echo "REAL-DB PREFLIGHT: BLOCKED — لا تبدأ تشغيل الإنتاج قبل معالجة العناصر أعلاه."
  exit 2
fi

echo "REAL-DB PREFLIGHT: PASS"
