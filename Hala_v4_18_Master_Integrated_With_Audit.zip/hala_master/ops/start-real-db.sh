#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

[[ -f infra/docker/.env ]] || { echo "Missing infra/docker/.env"; exit 2; }

echo "[1/3] Starting production-shaped stack from an empty volume..."
docker compose --env-file infra/docker/.env -f infra/docker/docker-compose.yml down --remove-orphans >/dev/null 2>&1 || true
# Fresh DB is mandatory for this stage.
docker compose --env-file infra/docker/.env -f infra/docker/docker-compose.yml down -v --remove-orphans >/dev/null 2>&1 || true

echo "[2/3] Building and starting..."
docker compose --env-file infra/docker/.env -f infra/docker/docker-compose.yml up -d --build

echo "[3/3] Waiting for readiness..."
for i in $(seq 1 60); do
  if docker compose --env-file infra/docker/.env -f infra/docker/docker-compose.yml ps --format json | grep -q 'healthy'; then
    if curl -fsS http://127.0.0.1:8088/ >/dev/null 2>&1 && curl -fsS http://127.0.0.1:8089/ >/dev/null 2>&1; then
      echo "Stack is responding."
      exit 0
    fi
  fi
  sleep 2
done

echo "Startup timeout. Showing service status/logs."
docker compose --env-file infra/docker/.env -f infra/docker/docker-compose.yml ps || true
docker compose --env-file infra/docker/.env -f infra/docker/docker-compose.yml logs --tail=120 db backend || true
exit 1
