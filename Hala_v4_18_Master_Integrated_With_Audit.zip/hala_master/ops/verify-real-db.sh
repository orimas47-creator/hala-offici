#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
COMPOSE=(docker compose --env-file infra/docker/.env -f infra/docker/docker-compose.yml)

run_sql() {
  "${COMPOSE[@]}" exec -T db psql -U "${POSTGRES_USER:-hala}" -d "${POSTGRES_DB:-hala}" -v ON_ERROR_STOP=1 -Atqc "$1"
}

fail=0

ready="$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:8080/ready 2>/dev/null || true)"
# backend is internal, so test through customer nginx health proxy only if available; direct 8080 is expected to be unreachable.
customer="$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:8088/ 2>/dev/null || true)"
admin="$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:8089/ 2>/dev/null || true)"
[[ "$customer" == "200" ]] || { echo "[FAIL] customer UI HTTP=$customer"; fail=1; }
[[ "$admin" == "200" ]] || { echo "[FAIL] admin UI HTTP=$admin"; fail=1; }

tables="$(run_sql "select count(*) from information_schema.tables where table_schema='public';")"
postgis="$(run_sql "select installed_version from pg_available_extensions where name='postgis' and installed_version is not null limit 1;")"

printf '[INFO] public tables=%s\n' "$tables"
printf '[INFO] postgis=%s\n' "${postgis:-NOT_INSTALLED}"

[[ -n "$postgis" ]] || { echo "[FAIL] PostGIS extension is not installed"; fail=1; }

for t in markets universal_listings bookings booking_wishes payments escrow_accounts ledger_accounts inventory_reservations financial_settlements webhook_inbox ai_supervisor_events platform_health_snapshots; do
  n="$(run_sql "select count(*) from information_schema.tables where table_schema='public' and table_name='$t';")"
  if [[ "$n" == "1" ]]; then echo "[OK] table $t"; else echo "[FAIL] missing table $t"; fail=1; fi
done

begin_count="$(run_sql "select count(*) from pg_proc where proname='pg_advisory_xact_lock';")"
[[ "$begin_count" -gt 0 ]] || { echo "[FAIL] pg_advisory_xact_lock unavailable"; fail=1; }

echo "[INFO] advisory lock function rows=$begin_count"

if [[ "$fail" -ne 0 ]]; then
  echo "REAL-DB VERIFY: FAIL"
  exit 1
fi

echo "REAL-DB VERIFY: PASS"
