#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "This gate intentionally refuses to claim E2E success without a live PostgreSQL/PostGIS stack."
./ops/preflight-real-db.sh
./ops/verify-real-db.sh

echo "E2E gate is READY. The next test runner must execute authenticated customer/provider/admin flows, three-wish booking, inventory hold, payment idempotency, signed webhook, Escrow release/refund, double-entry settlement, and timer expiration against the live DB."
