window.HalaAPI=(()=>{
 const base=window.HALA_API_BASE||'/api/v1';
 const rid=()=>crypto.randomUUID();
 const token=()=>localStorage.getItem('hala_access_token');
 async function request(path,opts={}){const headers={'Content-Type':'application/json','X-Request-Id':rid(),...(opts.headers||{})}; const t=token(); if(t) headers.Authorization='Bearer '+t; const r=await fetch(base+path,{...opts,headers}); const data=await r.json().catch(()=>({})); if(!r.ok)throw new Error(data.error||`HTTP_${r.status}`); return data;}
 return {
  saveToken:(t)=>localStorage.setItem('hala_access_token',t),
  logout:()=>localStorage.removeItem('hala_access_token'),
  requestOtp:(phone,purpose='login')=>request('/auth/request-otp',{method:'POST',body:JSON.stringify({phone,purpose})}),
  verifyOtp:async(phone,code,purpose='login')=>{const x=await request('/auth/verify-otp',{method:'POST',body:JSON.stringify({phone,code,purpose})});if(x.accessToken) localStorage.setItem('hala_access_token',x.accessToken);return x;},
  portal:()=>request('/portal'),
  services:()=>request('/catalog/services'),
  marketConfig:(marketKey)=>request('/markets/'+encodeURIComponent(marketKey)+'/config'),
  marketListings:(marketKey,limit=60)=>request('/markets/'+encodeURIComponent(marketKey)+'/listings?limit='+encodeURIComponent(limit)),
  adminMarkets:()=>request('/admin/markets'),
  createMarket:(payload)=>request('/admin/markets',{method:'POST',body:JSON.stringify(payload)}),
  updateMarket:(id,payload)=>request('/admin/markets/'+id,{method:'PATCH',body:JSON.stringify(payload)}),
  marketAction:(id,action)=>request(`/admin/markets/${id}/${action}`,{method:'POST'}),
  setReference:(id)=>request(`/admin/markets/${id}/reference`,{method:'POST'}),
  addSection:(id,payload)=>request(`/admin/markets/${id}/sections`,{method:'POST',body:JSON.stringify(payload)}),
  addAttribute:(id,payload)=>request(`/admin/markets/${id}/attributes`,{method:'POST',body:JSON.stringify(payload)}),
  addOperation:(id,payload)=>request(`/admin/markets/${id}/operations`,{method:'POST',body:JSON.stringify(payload)}),
  addUiConfig:(id,payload)=>request(`/admin/markets/${id}/ui-configs`,{method:'POST',body:JSON.stringify(payload)}),
  booking:(payload)=>request('/bookings',{method:'POST',headers:{'Idempotency-Key':payload.idempotencyKey||rid()},body:JSON.stringify(payload)}),
  createPayment:(bookingId,payload)=>request('/bookings/'+encodeURIComponent(bookingId)+'/payment',{method:'POST',headers:{'Idempotency-Key':payload?.idempotencyKey||rid()},body:JSON.stringify(payload||{})}),
  getBooking:(id)=>request('/bookings/'+id),
  transition:(id,to,reason)=>request(`/bookings/${id}/transition`,{method:'POST',body:JSON.stringify({to,reason})})
 };
})();
