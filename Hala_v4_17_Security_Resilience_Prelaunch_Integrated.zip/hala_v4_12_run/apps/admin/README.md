# Hala Admin — Market Builder v4.9

لوحة الإدارة التجريبية لمنشئ الأسواق الموحد. تستخدم نفس محرك Hala، ولا تنشئ صفحات أو قاعدة مستقلة للسوق.

المسار: `apps/admin/index.html`

الإنتاج يستخدم Bearer session بعد OTP. لا تُقبل X-Actor-Id كهوية موثوقة في الإنتاج.
