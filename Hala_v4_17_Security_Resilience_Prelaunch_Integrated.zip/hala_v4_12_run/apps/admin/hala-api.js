window.HalaAPI=(()=>{
 const base=window.HALA_API_BASE||'/api/v1'; const rid=()=>crypto.randomUUID(); const token=()=>localStorage.getItem('hala_access_token');
 async function request(path,opts={}){const headers={'Content-Type':'application/json','X-Request-Id':rid(),...(opts.headers||{})};const t=token();if(t)headers.Authorization='Bearer '+t;const r=await fetch(base+path,{...opts,headers});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error||`HTTP_${r.status}`);return data;}
 const payload=(a,b)=>b===undefined?a:b;
 return {
  saveToken:t=>localStorage.setItem('hala_access_token',t), logout:()=>localStorage.removeItem('hala_access_token'),
  portal:()=>request('/portal'),
  adminMarkets:(a)=>request('/admin/markets'),
  getMarket:(id)=>request('/admin/markets/'+id),
  createMarket:(a,b)=>request('/admin/markets',{method:'POST',body:JSON.stringify(payload(a,b))}),
  updateMarket:(a,b,c)=>request('/admin/markets/'+b,{method:'PATCH',body:JSON.stringify(payload(c,undefined))}),
  marketAction:(a,b,c)=>request(`/admin/markets/${b}/${c}`,{method:'POST'}),
  addSection:(a,b,c)=>request(`/admin/markets/${b}/sections`,{method:'POST',body:JSON.stringify(payload(c,undefined))}),
  addAttribute:(a,b,c)=>request(`/admin/markets/${b}/attributes`,{method:'POST',body:JSON.stringify(payload(c,undefined))}),
  addOperation:(a,b,c)=>request(`/admin/markets/${b}/operations`,{method:'POST',body:JSON.stringify(payload(c,undefined))}),
  addUiConfig:(a,b,c)=>request(`/admin/markets/${b}/ui-configs`,{method:'POST',body:JSON.stringify(payload(c,undefined))}),
  adminRails:(a)=>request('/admin/portal/rails'),
  upsertRail:(a,b)=>request('/admin/portal/rails',{method:'POST',body:JSON.stringify(payload(a,b))}),
  addAd:(a,b)=>request('/admin/portal/ads',{method:'POST',body:JSON.stringify(payload(a,b))})
 };
})();
